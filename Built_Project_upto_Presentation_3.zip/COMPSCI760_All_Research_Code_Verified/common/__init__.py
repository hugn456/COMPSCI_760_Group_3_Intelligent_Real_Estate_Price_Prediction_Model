"""Shared read-only data access helpers for COMPSCI 760."""
