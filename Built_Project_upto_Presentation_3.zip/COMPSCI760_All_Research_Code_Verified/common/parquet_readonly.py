"""Read-only Parquet V1 dictionary/RLE/SNAPPY decoder for this exact uploaded DVRS file.

Fallback used because pyarrow/fastparquet unavailable in the execution environment.
Supports flat nullable dictionary-encoded scalar pages only; fails closed otherwise.
Does not mutate source file or teammate notebook.
"""
from __future__ import annotations
import ctypes, struct
from pathlib import Path
import numpy as np
import pandas as pd
from thrift.protocol import TCompactProtocol
from thrift.transport import TTransport
from thrift.Thrift import TType

so=ctypes.CDLL('libsnappy.so.1')
so.snappy_uncompressed_length.argtypes=[ctypes.c_void_p,ctypes.c_size_t,ctypes.POINTER(ctypes.c_size_t)]
so.snappy_uncompressed_length.restype=ctypes.c_int
so.snappy_uncompress.argtypes=[ctypes.c_void_p,ctypes.c_size_t,ctypes.c_void_p,ctypes.POINTER(ctypes.c_size_t)]
so.snappy_uncompress.restype=ctypes.c_int

def snappy(buf:bytes) -> bytes:
    src=ctypes.create_string_buffer(buf)
    n=ctypes.c_size_t()
    if so.snappy_uncompressed_length(src,len(buf),ctypes.byref(n))!=0: raise ValueError('Bad SNAPPY input')
    dest=ctypes.create_string_buffer(n.value)
    if so.snappy_uncompress(src,len(buf),dest,ctypes.byref(n))!=0:raise ValueError('SNAPPY decompression failed')
    return dest.raw[:n.value]

class Decoder:
    def __init__(self, transport):self.p=TCompactProtocol.TCompactProtocol(transport)
    def val(self,t):
        p=self.p
        if t==TType.STRUCT:return self.st()
        if t==TType.LIST:
            et,n=p.readListBegin();a=[self.val(et) for _ in range(n)];p.readListEnd();return a
        if t==TType.SET:
            et,n=p.readSetBegin();a=[self.val(et) for _ in range(n)];p.readSetEnd();return a
        if t==TType.MAP:
            kt,vt,n=p.readMapBegin();a={self.val(kt):self.val(vt) for _ in range(n)};p.readMapEnd();return a
        if t==TType.STRING:return p.readBinary()
        if t==TType.I16:return p.readI16()
        if t==TType.I32:return p.readI32()
        if t==TType.I64:return p.readI64()
        if t==TType.BOOL:return p.readBool()
        if t==TType.DOUBLE:return p.readDouble()
        if t==TType.BYTE:return p.readByte()
        raise ValueError(f'Unsupported thrift type {t}')
    def st(self):
        p=self.p;data={};p.readStructBegin()
        while True:
            _,t,k=p.readFieldBegin()
            if t==TType.STOP:break
            data[k]=self.val(t);p.readFieldEnd()
        p.readStructEnd();return data

def varint(b,i):
    result=0;shift=0
    while True:
        x=b[i];i+=1
        result|=(x&127)<<shift
        if not x&128:return result,i
        shift+=7
        if shift>63:raise ValueError('Varint exceeds 64 bits')

def hybrid(data:bytes,bits:int,count:int):
    """Decode Parquet RLE/bitpack hybrid stream of integer indexes."""
    out=np.empty(count,dtype=np.int64)
    at=0; pos=0
    if bits==0:
        out.fill(0);return out
    size=(bits+7)//8
    while at<count:
        h,pos=varint(data,pos)
        if (h&1)==0: # RLE run
            repeat=h>>1
            value=int.from_bytes(data[pos:pos+size],'little');pos+=size
            n=min(repeat,count-at)
            out[at:at+n]=value;at+=n
        else: # bit packed run: h>>1 groups of 8
            repeat=(h>>1)*8
            n=min(repeat,count-at)
            bytecount=(repeat*bits+7)//8
            chunk=data[pos:pos+bytecount];pos+=bytecount
            v=int.from_bytes(chunk,'little')
            mask=(1<<bits)-1
            for j in range(n):out[at+j]=(v>>(j*bits))&mask
            at+=n
    return out

def plain(buf:bytes, typ:int, count:int):
    if typ==6: # BYTE_ARRAY
        out=[];i=0
        for _ in range(count):
            n=struct.unpack_from('<I',buf,i)[0];i+=4
            out.append(buf[i:i+n].decode('utf8','replace'));i+=n
        return out
    if typ in (1,2,3,4,5):
        dtype={1:'<i4',2:'<i8',3:'<i4',4:'<f4',5:'<f8'}[typ]
        return np.frombuffer(buf,dtype=dtype,count=count)
    if typ==0: # BOOLEAN bit-packed in PLAIN
        return [bool((buf[i//8]>>(i%8))&1) for i in range(count)]
    raise NotImplementedError(f'Plain physical type={typ}')

def pages_from(buf:bytes, start:int, total:int, column_meta:dict, schema:dict):
    """Decompress and decode dictionary and data pages into flat row values."""
    p=start; nd=0; decoded=[]; dictvals=None
    dtype=column_meta[1]
    optional=schema.get(3,0)!=0 # Parquet field repetition_type 1=OPTIONAL; 0=REQUIRED
    while nd<total:
        # Header is Thrift COMPACT and has no length prefix
        transport=TTransport.TMemoryBuffer(buf[p:])
        header=Decoder(transport).st()
        consumed=transport._buffer.tell();p+=consumed
        page_type=header[1]; compressed_size=header[3]; raw_size=header[2]
        page=buf[p:p+compressed_size];p+=compressed_size
        if page_type==2: # dictionary page
            body=snappy(page) if column_meta[4]==1 else page
            if len(body)!=raw_size:raise ValueError('dictionary page size mismatch')
            h=header[7];dictvals=plain(body,dtype,h[1]);continue
        if page_type not in (0,3):raise NotImplementedError(f'page {page_type}')
        if page_type==3:raise NotImplementedError('data page V2 unsupported')
        body=snappy(page) if column_meta[4]==1 else page
        if len(body)!=raw_size:raise ValueError('data page size mismatch')
        h=header[5];n=h[1]; enc=h[2]
        ix=0
        if optional:
            # Optional maximum definition level=1; RLE byte-length prefixed.
            size=struct.unpack_from('<I',body,ix)[0];ix+=4
            defs=hybrid(body[ix:ix+size],1,n);ix+=size
            nnz=int((defs==1).sum())
        else:
            defs=None;nnz=n
        if enc in (8,2):
            width=body[ix];ix+=1
            indices=hybrid(body[ix:],width,nnz)
            if dictvals is None:raise ValueError('No dictionary page before indexes')
            vals=np.asarray(dictvals,dtype=object)[indices]
        elif enc==0:vals=plain(body[ix:],dtype,nnz)
        else:raise NotImplementedError(f'encoding={enc}')
        if optional:
            out=np.empty(n,dtype=object);out[:]=None
            out[defs==1]=vals
            decoded.extend(out.tolist())
        else:
            decoded.extend(vals.tolist())
        nd+=n
    if nd!=total:raise ValueError(f'data rows expected={total}, obtained={nd}')
    return decoded


def read_parquet(path:str|Path, columns:list[str]|None=None):
    b=Path(path).read_bytes()
    if b[:4]!=b'PAR1' or b[-4:]!=b'PAR1':raise ValueError('Parquet magic missing')
    footer_size=struct.unpack_from('<I',b,len(b)-8)[0]
    m=Decoder(TTransport.TMemoryBuffer(b[len(b)-8-footer_size:-8])).st()
    assert len(m[4])==1, 'Only single rowgroup source supported'
    schema={x.get(4,b'').decode('utf8','replace'):x for x in m[2][1:]}
    sources=m[4][0][1]
    fields={x[3][3][0].decode('utf8','replace'):x[3] for x in sources}
    selected=list(schema) if columns is None else columns
    missing=[c for c in selected if c not in fields]
    if missing:raise ValueError(f'Parquet source missing: {missing}')
    result={}
    for col in selected:
        md=fields[col]
        offset=md.get(11,md[9])
        value=pages_from(b,offset,m[3],md,schema[col])
        assert len(value)==m[3],col
        result[col]=value
        print(f'decoded {col} ({len(value):,} values)',flush=True)
    return pd.DataFrame(result)
