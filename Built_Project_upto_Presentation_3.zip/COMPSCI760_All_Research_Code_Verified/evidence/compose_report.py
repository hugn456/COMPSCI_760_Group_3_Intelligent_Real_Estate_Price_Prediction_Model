"""Build a cohesive team report with code-generated, source-traceable charts.

Requires evidence/build_evidence.py run first. Keeps analytical narrative intact,
adds 12 figures to main body and 6 complementary figures to the appendix.
"""
from __future__ import annotations
import json
import re
from pathlib import Path
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.style import WD_STYLE_TYPE
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

ROOT=Path(__file__).resolve().parents[1]
REPORT=ROOT/'report'
BASE=ROOT/'evidence'/'base_report.md'
PROV=ROOT/'evidence'/'FIGURE_PROVENANCE.json'
MAIN={
 1:['S01_eligibility_counts.png','S01_missingness.png','S01_monthly_coverage.png'],
 2:['S02_model_comparison.png','S02_feature_ablation.png','S02_boosters_by_price_band.png'],
 3:['S03_monthly_medians.png','S03_test_forecasts.png','S03_seasonal_errors_by_month.png'],
 4:['S04_price_band_mae.png','S04_price_band_bias.png','S04_overprediction_rates.png'],
 5:['S05_original_xgb_features.png','S05_shap_groups.png','S05_shap_vs_ablation.png'],
 6:['S06_hedonic_comparison.png','S06_spatial_holdout.png','S06_hedonic_fold_errors.png']
}
SUP=['S01_sale_prices.png','S01_annual_price_spread.png',
'S02_fold_mae.png','S02_mae_rmse_tradeoff.png',
'S03_forecast_methods.png','S03_monthly_sale_counts.png','S03_rf_historical_ablation.png',
'S04_calibration.png','S04_property_type_relative_error.png',
'S05_shap_bootstrap_intervals.png',
'S06_repeat_properties.png','S06_test_scope.png','S06_council_reference_folds.png','S06_price_screening_by_fold.png']

CAPTIONS={
'S01_eligibility_counts.png':'Transaction counts after each source eligibility rule (full dataset audit).',
'S01_missingness.png':'Observed missingness among the eligible sales; two mostly administrative identifier fields omitted from this chart.',
'S01_sale_prices.png':'Empirical sale-price distribution for eligible transactions valued at up to NZ$5 million; larger values are omitted from this display only.',
'S02_model_comparison.png':'Five-fold pooled MAE by model. XGBoost is the original notebook result; other results are independently fitted and not verified as paired row-level comparisons.',
'S02_feature_ablation.png':'Property-only versus augmented-feature prediction errors for three boosting models (five-fold MAE).',
'S02_fold_mae.png':'Five-fold errors for the original XGBoost and two comparison models; descriptive comparison only.',
'S03_monthly_medians.png':'Recorded monthly median sale prices, with six-month validation and test periods shaded.',
'S03_test_forecasts.png':'Actual and seasonal-naive forecasts for the six held-out months; one-month-ahead predictions.',
'S03_forecast_methods.png':'Out-of-sample MAE for the eight eligible monthly forecasting methods; the seasonal naive method was selected using validation.',
'S04_price_band_mae.png':'Mean absolute error by observed price band for Random Forest and LightGBM, evaluated on held-out sales.',
'S04_price_band_bias.png':'Signed prediction bias by price band (prediction minus actual): positive is overestimation.',
'S04_calibration.png':'Mean predicted and actual prices across LightGBM prediction deciles, with the perfect-calibration reference.',
'S05_original_xgb_features.png':'Highest external-feature SHAP magnitudes recorded in the original XGBoost notebook.',
'S05_shap_groups.png':'SHAP attribution share by feature group: source-reported XGBoost, separate LightGBM and exploratory Random Forest.',
'S06_hedonic_comparison.png':'Hedonic linear and regularised baselines compared with the original reported XGBoost accuracy.',
'S06_spatial_holdout.png':'LightGBM error in withheld geographic blocks versus other areas in the final test fold.',
'S06_repeat_properties.png':'LightGBM error according to whether the property identifier appeared in an earlier training fold.',
'S06_test_scope.png':'LightGBM final-fold sensitivity to price-screened versus all eligible test transactions.',
'S01_monthly_coverage.png':'Monthly sale coverage from the real transaction data; sparse July–August 2026 records are excluded from forecasting.',
'S01_annual_price_spread.png':'Observed distribution by sale year (values up to NZ$5m). The 2026 sample covers only recorded months; no property-mix adjustment.',
'S02_boosters_by_price_band.png':'Actual sale-price band MAE for three separately trained boosting methods (not original XGBoost per-sale predictions).',
'S02_mae_rmse_tradeoff.png':'Reported MAE and RMSE for nine models. The original XGBoost result and companion benchmarks do not form a paired row-level comparison.',
'S03_monthly_sale_counts.png':'Number of eligible transactions contributing to each observed monthly median.',
'S03_seasonal_errors_by_month.png':'Recorded absolute monthly errors for seasonal naive across the validation and test months.',
'S03_rf_historical_ablation.png':'Past-only monthly features do not improve the separate Random Forest property-level experiment on the evaluation periods shown.',
'S04_overprediction_rates.png':'Overprediction frequencies in price bands. The dashed 50% line indicates an even split, not a fairness target.',
'S04_property_type_relative_error.png':'LightGBM mean absolute percentage error for observed property-type codes; sample sizes vary substantially.',
'S05_shap_vs_ablation.png':'Original XGBoost attribution compared with reported RMSE change when external features are omitted; SHAP and ablation measure different things.',
'S05_shap_bootstrap_intervals.png':'Bootstrap intervals for LightGBM SHAP shares across 320 sampled explanations only; they are not population confidence intervals.',
'S06_hedonic_fold_errors.png':'Regularised hedonic-model errors across the five chronological folds.',
'S06_council_reference_folds.png':'Retrospective error of Council capital values. Availability before sale has not been verified.',
'S06_price_screening_by_fold.png':'Number of held-out sales kept or excluded by the study’s price-based evaluation screen.'

}

def source_short(item):
 arr=[v['path'] for v in item['inputs']]
 stems=[Path(s).name for s in arr]
 if any('XGBoost.ipynb'==s for s in stems):return 'Original XGBoost notebook and saved numerical results'
 if any(s.endswith('.parquet') for s in stems):return 'Shared Parquet transactions and six source filters'
 if any(s.endswith('dataset_audit.json') for s in stems):return 'Full source-data audit'
 return 'Saved experiment result table(s)'

def build():
 provenance=json.loads(PROV.read_text())
 evidence={Path(d['figure']).name:d for d in provenance['figures']}
 names=sum(MAIN.values(),[])+SUP
 assert len(names)==32 and len(set(names))==32 and set(names)==set(evidence)
 for name in names:
  if not (REPORT/'evidence_figures'/name).is_file():raise FileNotFoundError(name)
  if evidence[name].get('synthetic_data') is not False:raise AssertionError('Synthetic figure prohibited')
 raw=BASE.read_text(encoding='utf8')
 raw=re.sub(r'^!\[.*?\]\(assets/[^)]+\)\s*$', '', raw,flags=re.M)
 lines=raw.splitlines()
 result=[]; current=None; fig_id=0
 for line in lines:
  stage_match=re.match(r'^## \d+\. Stage (\d+)\b',line)
  new_stage=int(stage_match.group(1)) if stage_match else None
  if new_stage is not None and current is not None and new_stage!=current:
   for name in MAIN[current]:
    fig_id+=1
    result.append(f'![Figure {fig_id}. {CAPTIONS[name]}](evidence_figures/{name})')
    result.append(f'*Evidence source: {source_short(evidence[name])}.*')
    result.append('')
   current=None
  if line.startswith('## 8. Discussion and Conclusion') and current is not None:
   for name in MAIN[current]:
    fig_id+=1
    result.append(f'![Figure {fig_id}. {CAPTIONS[name]}](evidence_figures/{name})')
    result.append(f'*Evidence source: {source_short(evidence[name])}.*')
    result.append('')
   current=None
  result.append(line)
  if new_stage is not None:current=new_stage
 if current is not None:
  for name in MAIN[current]:
   fig_id+=1
   result += [f'![Figure {fig_id}. {CAPTIONS[name]}](evidence_figures/{name})',f'*Evidence source: {source_short(evidence[name])}.*','']
 result += ['', '## Appendix A. Additional Experiment Evidence','',
 'The supporting plots below show source observations, sample-size checks, model diagnostics and sensitivity analyses. Figures based on saved aggregates reproduce the visual evidence without implying that model fitting was rerun.','']
 for name in SUP:
  fig_id+=1
  result.extend([f'![Figure A{fig_id-18}. {CAPTIONS[name]}](evidence_figures/{name})',f'*Evidence source: {source_short(evidence[name])}.*',''])
 result+=['## Appendix B. Figure Provenance and Reproduction','',
 'All 32 figures were generated by `evidence/build_evidence.py`. The script verifies the original dataset and notebook SHA-256 fingerprints before processing their data or previously saved results. No synthetic observations, simulated prediction errors, or image-generation tools were used.','',
 'Stage 1 includes figures regenerated directly from source Parquet transactions. All other figures are plotted from the saved tables created by the project experiments. Replotting these results does not mean the original XGBoost or the comparison models have been retrained. Subgroup and robustness figures relate to the specific named models, not necessarily to XGBoost.','',
 'The file `evidence/FIGURE_PROVENANCE.json` lists each figure, the exact input filenames and SHA-256 fingerprints, data population, and plot methodology. The original transaction dataset and XGBoost notebook are required for a full rebuild but are intentionally excluded from the shareable package.','',
 'A full academic reference list should be added when this draft is integrated with the group’s literature-review section.','']
 md='\n'.join(result)+'\n'
 (REPORT/'COMPSCI760_Team_Report.md').write_text(md,encoding='utf8')

 doc=Document()
 sect=doc.sections[0]
 sect.page_width=Inches(8.27);sect.page_height=Inches(11.69)
 sect.top_margin=Inches(.75);sect.bottom_margin=Inches(.72)
 sect.left_margin=Inches(.88);sect.right_margin=Inches(.88)
 styles=doc.styles
 normal=styles['Normal'];normal.font.name='Aptos';normal.font.size=Pt(9.5)
 normal.paragraph_format.space_after=Pt(5)
 normal.paragraph_format.line_spacing=1.13
 for nm,size in [('Title',17),('Heading 1',12.2),('Heading 2',10.3)]:
  s=styles[nm];s.font.name='Aptos Display' if nm=='Title' else 'Aptos';s.font.size=Pt(size);s.font.color.rgb=RGBColor(29,58,82)
  if nm!='Title':s.paragraph_format.space_before=Pt(10);s.paragraph_format.space_after=Pt(5);s.paragraph_format.keep_with_next=True
 if 'Evidence Caption' not in styles:
  cs=styles.add_style('Evidence Caption',WD_STYLE_TYPE.PARAGRAPH)
 else:cs=styles['Evidence Caption']
 cs.font.name='Aptos';cs.font.size=Pt(8);cs.font.color.rgb=RGBColor(65,82,95)
 cs.paragraph_format.space_before=Pt(1);cs.paragraph_format.space_after=Pt(5)
 cs.paragraph_format.keep_together=True

 def add_formatted(p,s):
  parts=re.split(r'(\*\*.*?\*\*|\*[^*]+\*|`[^`]+`)',s)
  for part in parts:
   if part.startswith('**') and part.endswith('**'):p.add_run(part[2:-2]).bold=True
   elif part.startswith('*') and part.endswith('*'):p.add_run(part[1:-1]).italic=True
   elif part.startswith('`') and part.endswith('`'):
    rr=p.add_run(part[1:-1]);rr.font.name='Consolas';rr.font.size=Pt(8.5)
   else:p.add_run(part)

 img_count=0;last_caption=None
 for line in md.splitlines():
  if not line.strip():continue
  if line.startswith('# '):
   p=doc.add_paragraph(style='Title');add_formatted(p,line[2:]);continue
  if line.startswith('## '):
   text=line[3:]
   if text.startswith('Appendix A'):
    doc.add_page_break()
   p=doc.add_paragraph(style='Heading 1');add_formatted(p,text);continue
  img=re.match(r'^!\[([^]]+)\]\(([^)]+)\)$',line)
  if img:
   cap,name=img.group(1),img.group(2)
   assert 'evidence_figures/' in name
   pp=doc.add_paragraph();pp.alignment=WD_ALIGN_PARAGRAPH.CENTER
   pp.paragraph_format.space_before=Pt(3);pp.paragraph_format.space_after=Pt(2)
   pp.paragraph_format.keep_with_next=True
   pic=pp.add_run().add_picture(str(REPORT/name),width=Inches(5.47))
   cap_p=doc.add_paragraph(style='Evidence Caption')
   cap_p.alignment=WD_ALIGN_PARAGRAPH.CENTER
   add_formatted(cap_p,cap)
   img_count+=1
   last_caption=cap_p
   continue
  if line.startswith('*Evidence source:'):
   if last_caption is not None:
    add_formatted(last_caption,'  '+line.strip('*'))
    last_caption=None
   continue
  p=doc.add_paragraph();add_formatted(p,line)

 assert img_count==32, f'Unexpected figures {img_count}'
 header=sect.header.paragraphs[0];header.alignment=WD_ALIGN_PARAGRAPH.RIGHT
 r=header.add_run('COMPSCI 760 · Group Research Report');r.font.size=Pt(8);r.font.color.rgb=RGBColor(100,112,122)
 foot=sect.footer.paragraphs[0];foot.alignment=WD_ALIGN_PARAGRAPH.CENTER
 r=foot.add_run('COMPSCI 760 · Evidence derived from recorded data and experiment outputs');r.font.size=Pt(7.4);r.font.color.rgb=RGBColor(125,132,140)
 props=doc.core_properties;props.title='Modelling Auckland Property Prices with Explainable AI';props.subject='Unified team research report with verified experimental figures';props.author='COMPSCI 760 Research Group'
 path=REPORT/'COMPSCI760_Team_Report.docx'
 doc.save(path)
 print(f'Authored {path}, {img_count} code-generated charts')

if __name__=='__main__':build()
