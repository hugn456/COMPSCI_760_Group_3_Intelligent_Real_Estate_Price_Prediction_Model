"""Fourteen additional evidence-only plots from genuine saved research outputs.

Called by build_evidence.py after the eighteen original figures have been generated.
The saved experiment outputs are aggregate tables, not invented transaction predictions.
"""
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

BLUE='#294C73'; TEAL='#087E80'; SLATE='#697D91'; ORANGE='#C97825'; RED='#AA4D45'; PURPLE='#70609A'

def add_figures(stages:Path, eligible:pd.DataFrame, dataset:Path, save):
    # Stage 1 - inspect original transactions rather than model outputs
    series_file=stages/'03_time_series/results/monthly_median_series.csv'
    dates=eligible['sale_date_parsed']  # exact parsing in existing Stage 3 core
    sales=dates.dt.to_period('M').value_counts().sort_index()
    sales=sales[(sales.index>=pd.Period('2024-01'))&(sales.index<=pd.Period('2026-08'))]
    assert int(sales[pd.Period('2026-07')])==490 and int(sales[pd.Period('2026-08')])==27
    fig,ax=plt.subplots(figsize=(8.1,3.4))
    values=sales.to_numpy()
    colors=[TEAL if x<=pd.Period('2026-06') else ORANGE for x in sales.index]
    ax.bar(np.arange(len(sales)),values,color=colors,width=.8)
    ax.axvline(len(sales)-2-.5,color=RED,ls='--',lw=1.3)
    ax.set_xticks(np.arange(0,len(sales),3),[str(sales.index[i]) for i in range(0,len(sales),3)],rotation=30,ha='right',fontsize=8)
    ax.set_ylabel('Eligible transactions');ax.set_title('Recorded sale volume and incomplete late-month coverage')
    ax.text(len(sales)-2,510,'July 490',ha='center',fontsize=8,color=RED)
    ax.text(len(sales)-1,105,'August 27',ha='center',fontsize=8,color=RED)
    ax.spines[['top','right']].set_visible(False)
    save(fig,'S01_monthly_coverage.png',1,'Real transaction volumes and coverage cutoff',[dataset,series_file],'Eligible sales recorded January 2024–August 2026','Count real source transactions by sale month; mark excluded July–August 2026 as coverage-limited')

    prices=pd.to_numeric(eligible['sale_price_gross'],errors='coerce')
    mask=prices.between(1,5_000_000)&dates.dt.year.isin([2024,2025,2026])
    price_df=pd.DataFrame({'year':dates[mask].dt.year.to_numpy(),'price':prices[mask].to_numpy()/1e6})
    gr=[price_df[price_df.year==y].price.values for y in [2024,2025,2026]]
    assert all(len(x)>0 for x in gr)
    fig,ax=plt.subplots(figsize=(7.5,3.45))
    bp=ax.boxplot(gr,showfliers=False,patch_artist=True,widths=.47,medianprops={'color':ORANGE,'lw':1.7})
    for patch in bp['boxes']:patch.set_facecolor(TEAL);patch.set_alpha(.55)
    ax.set_xticks([1,2,3],[f'{y} (n={len(z):,})' for y,z in zip([2024,2025,2026],gr)])
    ax.set_ylabel('Sale price (NZ$ million)');ax.set_title('Observed sale-price spread by calendar year (up to NZ$5m)')
    ax.spines[['top','right']].set_visible(False)
    save(fig,'S01_annual_price_spread.png',1,'Empirical price distribution by sale year',[dataset],'Eligible sales up to NZ$5m by recorded sale year; 2026 is partial','Non-parametric box plots on actual transactions; >NZ$5m excluded from plot only, no quality or mix adjustment')

    # Stage 2 - comparing saved model output summaries, not recreating individual predictions
    dfile=stages/'02_property_prediction/results/benchmark_price_bands.csv'
    d=pd.read_csv(dfile)
    order=['<=750k','750k-1m','1m-1.5m','1.5m-2m','>2m'];models=['LightGBM','CatBoost','HistGradientBoosting']
    fig,ax=plt.subplots(figsize=(8.1,3.7));xx=np.arange(5)
    for i,model in enumerate(models):
        sub=d[d.model==model].set_index('price_group').reindex(order)
        assert len(sub)==5 and sub.model_MAE.notna().all(),model
        ax.plot(xx,sub.model_MAE/1000,'o-',lw=1.8,ms=5,label=('Histogram GB' if model=='HistGradientBoosting' else model),color=[BLUE,TEAL,ORANGE][i])
    ax.set_xticks(xx,['≤$750k','$750k–1m','$1m–1.5m','$1.5m–2m','>$2m'],fontsize=8)
    ax.set_ylabel('MAE (NZ$ thousand)');ax.set_title('Independent boosting models: error by actual sale-price band')
    ax.legend(frameon=False,fontsize=8);ax.spines[['top','right']].set_visible(False)
    save(fig,'S02_boosters_by_price_band.png',2,'Boosting-model errors across observed price bands',[dfile],'Separately trained boosting experiments; five held-out sale-price groups','Plot stored five-fold subgroup MAE; no original-XGBoost per-sale predictions or unverified paired claims')

    mfile=stages/'02_property_prediction/results/all_models_augmented_comparison.csv';mm=pd.read_csv(mfile)
    fig,ax=plt.subplots(figsize=(7.5,4.0))
    for row in mm.itertuples():
        original='XGBoost' in row.model
        ax.scatter(row.MAE/1000,row.RMSE/1000,c=TEAL if original else BLUE,s=90 if original else 43,zorder=3)
        label=row.model.replace(' — teammate original','').replace('HistGradientBoosting','Histogram GB').replace('Larger Random Forest','Large RF').replace('Random Forest','RF')
        if label=='Median baseline': label='Median'
        ax.annotate(label,(row.MAE/1000,row.RMSE/1000),xytext=(5,3),textcoords='offset points',fontsize=7.3)
    ax.set_xlabel('Pooled MAE (NZ$ thousand)');ax.set_ylabel('Pooled RMSE (NZ$ thousand)')
    ax.set_title('Accuracy across MAE and RMSE (nine reported models)')
    ax.spines[['top','right']].set_visible(False)
    save(fig,'S02_mae_rmse_tradeoff.png',2,'MAE–RMSE performance comparison across models',[mfile],'Nine reported model results over price-screened test observations','Scatter of published paired summary metrics per model; original XGBoost summary not a row-matched paired experiment')

    # Stage 3 - number of test transactions, absolute forecast errors, and independent RF feature sensitivity
    ss=pd.read_csv(series_file);ss['month']=pd.to_datetime(ss.month)
    fig,ax=plt.subplots(figsize=(8.1,3.45))
    c=np.where(ss.month>=pd.Timestamp('2026-01-01'),ORANGE,np.where(ss.month>=pd.Timestamp('2025-07-01'),TEAL,BLUE))
    ax.bar(ss.month,ss.n_sales,width=22,color=c)
    ax.set_title('Transaction counts underlying each monthly median')
    ax.set_ylabel('Eligible sales per month');ax.tick_params(axis='x',labelrotation=25)
    ax.spines[['top','right']].set_visible(False)
    save(fig,'S03_monthly_sale_counts.png',3,'Monthly sample size underpinning time-series observations',[series_file],'30 complete months and 59,281 sales','Plot source-derived counts for each monthly median; month-by-month sample sizes are not assumed constant')

    wfile=stages/'03_time_series/results/walk_forward_one_step_forecasts.csv';wf=pd.read_csv(wfile)
    sel=wf[wf.model=='Seasonal naive (12m)'].sort_values('month')
    assert len(sel)==12 and set(sel.phase)=={'validation','test'}
    fig,ax=plt.subplots(figsize=(8.1,3.4));xs=np.arange(12)
    ax.bar(xs,sel.absolute_error_nzd/1000,color=np.where(sel.phase=='test',ORANGE,TEAL))
    ax.axvline(5.5,color=SLATE,ls='--',lw=1)
    ax.set_xticks(xs,pd.to_datetime(sel.month).dt.strftime('%b %y'),rotation=35,ha='right',fontsize=8)
    ax.set_ylabel('Absolute forecast error (NZ$ thousand)')
    ax.set_title('Seasonal-naive error by validation and test month')
    ax.spines[['top','right']].set_visible(False)
    save(fig,'S03_seasonal_errors_by_month.png',3,'Monthly forecast residual magnitudes',[wfile],'Six validation and six test months, rolling one-step forecasts','Read saved absolute errors and check all 12 months; validation and test distinguished')

    rf_file=stages/'03_time_series/results/rf_historical_feature_pilot_summary.csv';rf=pd.read_csv(rf_file)
    sub=rf[rf.evaluation_scope=='all_sales'];phases=['validation','test'];labels=['Without historical features','With past-only features']
    fig,ax=plt.subplots(figsize=(7.5,3.3));xs=np.arange(2);wd=.33
    for i,feat in enumerate(['original_augmented','original_augmented_plus_past_market']):
        vals=[float(sub[(sub.phase==phase)&(sub.feature_set==feat)].weighted_MAE_nzd.iloc[0])/1000 for phase in phases]
        ax.bar(xs+(i-.5)*wd,vals,width=wd,color=[BLUE,ORANGE][i],label=labels[i])
        for x,v in zip(xs+(i-.5)*wd,vals):ax.text(x,v+1.0,f'{v:.1f}',ha='center',fontsize=8)
    ax.set_xticks(xs,['Validation (3 months)','Test (6 months)'])
    ax.set_ylabel('Weighted sale-level MAE (NZ$ thousand)');ax.set_ylim(0,215)
    ax.set_title('Past-only market features: RF property-prediction pilot')
    ax.legend(frameon=False,fontsize=8,loc='upper center');ax.spines[['top','right']].set_visible(False)
    save(fig,'S03_rf_historical_ablation.png',3,'Historical-feature predictive sensitivity',[rf_file],'Separate Random Forest monthly pilot on all eligible evaluation sales','Weighted aggregation as saved; no model retraining nor changes to original XGBoost')

    # Stage 4 - show directional error and property-type disparity without demographics claims
    a=stages/'04_fairness/results/Companion_RandomForest_subgroup_metrics.csv';b=stages/'04_fairness/results/Companion_LightGBM_subgroup_metrics.csv'
    ra=pd.read_csv(a);lb=pd.read_csv(b)
    order=['<750k','750k–1m','1m–1.5m','1.5m–2m','>=2m'];xx=np.arange(5)
    fig,ax=plt.subplots(figsize=(8.1,3.5))
    for d,name,color,marker in [(ra,'Random Forest',BLUE,'o'),(lb,'LightGBM',TEAL,'s')]:
        sub=d[d.dimension=='price_band'].set_index('group').loc[order]
        ax.plot(xx,sub.overprediction_pct,'-'+marker,color=color,label=name,lw=1.7)
    ax.axhline(50,color=SLATE,ls='--',lw=1)
    ax.set_xticks(xx,['<$750k','$750k–1m','$1m–1.5m','$1.5m–2m','≥$2m'],fontsize=8)
    ax.set_ylabel('Overpredicted sales (%)');ax.set_ylim(0,100)
    ax.set_title('Direction of error across observed price bands')
    ax.legend(frameon=False,fontsize=8);ax.spines[['top','right']].set_visible(False)
    save(fig,'S04_overprediction_rates.png',4,'Overprediction frequency by realised sale-price group',[a,b],'48,848 screened out-of-fold sales, both independently fitted models','Percentage of test sales where prediction exceeds observed price, by actual sale-price band')

    groups=lb[lb.dimension=='property_type_group'].copy().sort_values('n',ascending=False)
    fig,ax=plt.subplots(figsize=(7.7,3.3));xx=np.arange(len(groups))
    ax.bar(xx,groups.mean_APE_pct,color=[TEAL,BLUE,SLATE],width=.55)
    for j,row in enumerate(groups.itertuples()):ax.text(j,row.mean_APE_pct+0.5,f'n={row.n:,}',ha='center',fontsize=8)
    ax.set_xticks(xx,[str(x) for x in groups.group]);ax.set_ylim(0,max(groups.mean_APE_pct)*1.26)
    ax.set_ylabel('Mean absolute percentage error (%)')
    ax.set_title('LightGBM relative error by recorded property-type code')
    ax.spines[['top','right']].set_visible(False)
    save(fig,'S04_property_type_relative_error.png',4,'Relative errors by recorded property-type codes',[b],'Recorded property-type categories; one category has 119 sales','Saved group mean absolute percentage error; source category codes retained, and unequal group sizes displayed')

    # Stage 5 - nuanced explanation of attribution and predictive necessity
    sv=stages/'05_shap/results/team_original_shap_vs_drop_one.csv';sh=pd.read_csv(sv)
    fig,ax=plt.subplots(figsize=(8.1,3.9))
    for r in sh.itertuples():
        col=TEAL if r.feature in ['latitude','longitude'] else BLUE
        ax.scatter(r.reported_mean_absolute_SHAP_NZD/1000,r.teammate_drop_one_RMSE_delta_NZD/1000,c=col,s=45 if col==TEAL else 27,zorder=3)
    for nm in ['latitude','longitude','sa2_new_dwellings_consented_12m','in_noise_overlay']:
        row=sh[sh.feature==nm].iloc[0]
        ax.annotate(nm.replace('_',' '),(row.reported_mean_absolute_SHAP_NZD/1000,row.teammate_drop_one_RMSE_delta_NZD/1000),xytext=(4,4),textcoords='offset points',fontsize=7)
    ax.axhline(0,color=SLATE,ls='--',lw=1)
    ax.set_xlabel('Mean absolute SHAP contribution (NZ$ thousand)')
    ax.set_ylabel('RMSE change on feature removal (NZ$ thousand)')
    ax.set_title('Original XGBoost: attribution is not the same as ablation benefit')
    ax.spines[['top','right']].set_visible(False)
    save(fig,'S05_shap_vs_ablation.png',5,'Original XGBoost SHAP versus reported drop-one tests',[sv],'Thirteen original external features; separate source-reported drop-one experiment','Plot original notebook-reported feature attribution and RMSE delta; no causal or matched-fold inference')

    ci_file=stages/'05_shap/results/lightgbm_sample_group_share_bootstrap.csv';ci=pd.read_csv(ci_file)
    ci=ci.set_index('feature_group').loc[['Property and basic attributes','Coordinates','Other external']].reset_index()
    fig,ax=plt.subplots(figsize=(7.6,3.35));yy=np.arange(3)
    p=ci.point_pct.to_numpy();lo=p-ci.boot_p025_pct.to_numpy();hi=ci.boot_p975_pct.to_numpy()-p
    ax.barh(yy,p,color=[BLUE,TEAL,ORANGE],height=.5)
    ax.errorbar(p,yy,xerr=np.vstack([lo,hi]),fmt='none',ecolor='#222222',capsize=4,lw=1.1)
    ax.set_yticks(yy,['Property + basic','Coordinates','Other external']);ax.invert_yaxis()
    ax.set_xlabel('Share of mean absolute SHAP (%)')
    ax.set_title('LightGBM feature-group shares: sampled-explanation uncertainty')
    ax.spines[['top','right']].set_visible(False)
    save(fig,'S05_shap_bootstrap_intervals.png',5,'Bootstrap uncertainty in LightGBM sampled SHAP shares',[ci_file],'320 sampled test explanations; sample-conditional bootstrap intervals','Plot saved 2.5/97.5 bootstrap intervals; NOT uncertainty of the full property population or fit')

    # Stage 6 - check how modelling choices differ across folds and historical references
    ffile=stages/'06_hedonic_robustness/results/hedonic_fold_metrics.csv';fo=pd.read_csv(ffile)
    sub=fo[fo.scope=='trimmed'];fig,ax=plt.subplots(figsize=(8.1,3.3))
    for name,col in [('Hedonic Ridge (compact)',SLATE),('Hedonic Ridge (augmented)',TEAL)]:
        z=sub[sub.model==name].sort_values('fold');assert len(z)==5
        ax.plot(z.fold,z.MAE/1000,'o-',label=name.replace('Hedonic Ridge','Ridge'),color=col,lw=1.8)
    ax.set_xticks(range(1,6));ax.set_xlabel('Chronological fold');ax.set_ylabel('MAE (NZ$ thousand)')
    ax.set_title('Hedonic Ridge errors across five chronological folds');ax.legend(frameon=False,fontsize=8)
    ax.spines[['top','right']].set_visible(False)
    save(fig,'S06_hedonic_fold_errors.png',6,'Regularised hedonic stability across evaluation folds',[ffile],'Five expanding chronological, price-screened test folds','Visualise saved compact versus augmented Ridge fold MAE')

    cv=stages/'06_hedonic_robustness/results/council_value_reference_by_fold.csv';c=pd.read_csv(cv)
    c=c[c.subset=='all_positive_cv'].sort_values('fold');assert len(c)==5
    fig,ax=plt.subplots(figsize=(7.6,3.2));ax.plot(c.fold,c.MAE/1000,'o-',lw=1.8,color=PURPLE)
    ax.set_xticks(range(1,6));ax.set_ylabel('Absolute difference to sale (NZ$ thousand)')
    ax.set_title('Council capital value: retrospective error by evaluation fold')
    ax.text(.98,.95,'Publication availability before sale not verified',transform=ax.transAxes,ha='right',va='top',fontsize=7.5,color=RED)
    ax.spines[['top','right']].set_visible(False)
    save(fig,'S06_council_reference_folds.png',6,'Retrospective Council capital-value reference',[cv],'Price-screened held-out sales across five folds','Absolute deviation between sale and capital value; not an authenticated pre-sale predictor or live online valuation')

    rg=stages/'06_hedonic_robustness/results/fold_registry_summary.csv';reg=pd.read_csv(rg);assert len(reg)==5
    fig,ax=plt.subplots(figsize=(8.1,3.2));idx=np.arange(5)
    ax.bar(idx,reg.n_test_trimmed,label='Evaluated after screening',color=TEAL)
    ax.bar(idx,reg.n_test-reg.n_test_trimmed,bottom=reg.n_test_trimmed,label='Excluded by price screen',color=ORANGE)
    for j,r in enumerate(reg.itertuples()):ax.text(j,r.n_test+100,f'{r.n_test-r.n_test_trimmed:,} excluded',ha='center',fontsize=7.7)
    ax.set_xticks(idx,[f'Fold {i}' for i in reg.fold]);ax.set_ylim(0,11500)
    ax.set_ylabel('Held-out sale count');ax.set_title('Evaluation sample screening across chronological folds')
    ax.legend(frameon=False,fontsize=8,loc='lower right');ax.spines[['top','right']].set_visible(False)
    save(fig,'S06_price_screening_by_fold.png',6,'Test transactions included and excluded by price screening',[rg],'Five test blocks of 9,966 sales each','Read saved fold registry; height equals total held-out sales, not total pre-screen training sales')
