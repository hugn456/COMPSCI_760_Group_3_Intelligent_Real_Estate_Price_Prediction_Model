"""Aggregate evidence plot/document checks; run pytest evidence/test_evidence.py"""
import json,hashlib,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def test_manifest_32_real_figures():
 d=json.loads((ROOT/'evidence'/'FIGURE_PROVENANCE.json').read_text())
 assert len(d['figures'])==32 and d['figure_count']==32
 assert sorted(set(i['stage'] for i in d['figures']))==[1,2,3,4,5,6]
 assert all(i['synthetic_data'] is False for i in d['figures'])

def test_image_sha256_and_sources():
 d=json.loads((ROOT/'evidence'/'FIGURE_PROVENANCE.json').read_text())
 for f in d['figures']:
  p=ROOT/f['figure'];assert p.is_file() and digest(p)==f['figure_sha256']
  assert len(f['inputs'])>0
  for source in f['inputs']:
   p=ROOT/source['path']
   if p.is_file():assert digest(p)==source['sha256']
   else:assert p.name in ('newest_dvrs_with_team_external.parquet','XGBoost.ipynb')

def test_word_embeds_all_figures():
 p=ROOT/'report'/'COMPSCI760_Team_Report.docx'
 with zipfile.ZipFile(p) as z:
  media=[x for x in z.namelist() if x.startswith('word/media/')]
  assert len(media)==32

def test_markdown_figure_count():
 t=(ROOT/'report'/'COMPSCI760_Team_Report.md').read_text()
 assert t.count('](evidence_figures/')==32
 assert 'Appendix B. Figure Provenance' in t

def test_no_source_data_leaked():
 for x in ROOT.rglob('*'):
  if not x.is_file():continue
  if 'private' in x.name.lower():assert x.suffix in ('.py','.md')
  assert x.suffix.lower() not in ('.parquet','.ipynb')


def test_fourteen_new_figures_and_balanced_stages():
 d=json.loads((ROOT/'evidence'/'FIGURE_PROVENANCE.json').read_text())
 counts={s:sum(f['stage']==s for f in d['figures']) for s in range(1,7)}
 assert counts=={1:5,2:5,3:6,4:5,5:4,6:7}
 assert len({Path(f['figure']).name for f in d['figures']})==32
 assert not any('fake' in f['method'].lower() for f in d['figures'])


def test_key_saved_results_are_used_not_invented():
 import pandas as pd
 st=ROOT/'stages'
 s=pd.read_csv(st/'03_time_series/results/monthly_median_series.csv')
 assert len(s)==30 and int(s.n_sales.sum())==59281
 fc=pd.read_csv(st/'03_time_series/results/walk_forward_one_step_forecasts.csv')
 chosen=fc[(fc.phase=='test')&(fc.model=='Seasonal naive (12m)')]
 assert len(chosen)==6 and round(chosen.absolute_error_nzd.mean())==9500
 rf=pd.read_csv(st/'03_time_series/results/rf_historical_feature_pilot_summary.csv')
 rf=rf[(rf.phase=='test')&(rf.evaluation_scope=='all_sales')]
 before=float(rf[rf.feature_set=='original_augmented'].weighted_MAE_nzd.iloc[0])
 after=float(rf[rf.feature_set=='original_augmented_plus_past_market'].weighted_MAE_nzd.iloc[0])
 assert 160000<before<161000 and after>before


def test_original_xgb_was_not_replayed_and_core_scopes_distinct():
 import pandas as pd
 st=ROOT/'stages'
 m=pd.read_csv(st/'02_property_prediction/results/all_models_augmented_comparison.csv')
 assert len(m)==9 and m.model.str.contains('XGBoost').sum()==1
 team=m[m.model.str.contains('XGBoost')].iloc[0]
 assert round(team.MAE)==131243
 groups=pd.read_csv(st/'04_fairness/results/Companion_LightGBM_subgroup_metrics.csv')
 assert set(['price_band','property_type_group','flood_plain_group']).issubset(set(groups.dimension))
 reg=pd.read_csv(st/'06_hedonic_robustness/results/fold_registry_summary.csv')
 assert len(reg)==5 and reg.n_test.sum()==49830
 assert reg.n_test_trimmed.sum()==48848
