# Evidence and figure provenance — COMPSCI 760

**32 figures, all generated from real research inputs.** Figures 1–18 are located in the six report stages; A1–A14 appear in the appendix.

The source transaction dataset and original XGBoost notebook are verified against SHA-256 fingerprints before the plotting script runs. Plots derived from previously saved experiment summaries are reproductions of the visuals, **not** claims of newly retrained models. No fabricated predictions or synthetic examples were introduced.

| Stage | Figure file | Source | Population / evidence scope |
|---:|---|---|---|
| 1 | `S01_annual_price_spread.png` | newest_dvrs_with_team_external.parquet | Eligible sales up to NZ$5m by recorded sale year; 2026 is partial |
| 1 | `S01_eligibility_counts.png` | stages/01_data_audit/results/dataset_audit.json | 92,010 raw / 59,798 eligible |
| 1 | `S01_missingness.png` | stages/01_data_audit/results/dataset_audit.json | 59,798 eligible sales |
| 1 | `S01_monthly_coverage.png` | newest_dvrs_with_team_external.parquet, stages/03_time_series/results/monthly_median_series.csv | Eligible sales recorded January 2024–August 2026 |
| 1 | `S01_sale_prices.png` | newest_dvrs_with_team_external.parquet, stages/01_data_audit/results/dataset_audit.json | 59,466 eligible sales up to NZ$5m |
| 2 | `S02_boosters_by_price_band.png` | stages/02_property_prediction/results/benchmark_price_bands.csv | Separately trained boosting experiments; five held-out sale-price groups |
| 2 | `S02_feature_ablation.png` | stages/02_property_prediction/results/non_xgb_feature_ablation.csv | Five-fold price-screened evaluation |
| 2 | `S02_fold_mae.png` | stages/02_property_prediction/results/fold_by_fold_comparison.csv | Five chronological folds |
| 2 | `S02_mae_rmse_tradeoff.png` | stages/02_property_prediction/results/all_models_augmented_comparison.csv | Nine reported model results over price-screened test observations |
| 2 | `S02_model_comparison.png` | stages/02_property_prediction/results/all_models_augmented_comparison.csv | 48,848 price-screened evaluation sales reported per model |
| 3 | `S03_forecast_methods.png` | stages/03_time_series/results/forecast_model_comparison.csv | Six test months; validation selected seasonal naive |
| 3 | `S03_monthly_medians.png` | stages/03_time_series/results/monthly_median_series.csv | 59,281 sales; 30 months |
| 3 | `S03_monthly_sale_counts.png` | stages/03_time_series/results/monthly_median_series.csv | 30 complete months and 59,281 sales |
| 3 | `S03_rf_historical_ablation.png` | stages/03_time_series/results/rf_historical_feature_pilot_summary.csv | Separate Random Forest monthly pilot on all eligible evaluation sales |
| 3 | `S03_seasonal_errors_by_month.png` | stages/03_time_series/results/walk_forward_one_step_forecasts.csv | Six validation and six test months, rolling one-step forecasts |
| 3 | `S03_test_forecasts.png` | stages/03_time_series/results/walk_forward_one_step_forecasts.csv | Six held-out test months (January–June 2026) |
| 4 | `S04_calibration.png` | stages/04_fairness/results/Companion_LightGBM_predicted_decile_calibration.csv | Ten equally sized prediction-decile groups of 48,848 test sales |
| 4 | `S04_overprediction_rates.png` | stages/04_fairness/results/Companion_RandomForest_subgroup_metrics.csv, stages/04_fairness/results/Companion_LightGBM_subgroup_metrics.csv | 48,848 screened out-of-fold sales, both independently fitted models |
| 4 | `S04_price_band_bias.png` | stages/04_fairness/results/Companion_RandomForest_subgroup_metrics.csv, stages/04_fairness/results/Companion_LightGBM_subgroup_metrics.csv | Same out-of-fold companion model test sales |
| 4 | `S04_price_band_mae.png` | stages/04_fairness/results/Companion_RandomForest_subgroup_metrics.csv, stages/04_fairness/results/Companion_LightGBM_subgroup_metrics.csv | 48,848 price-screened test sales across five chronological folds |
| 4 | `S04_property_type_relative_error.png` | stages/04_fairness/results/Companion_LightGBM_subgroup_metrics.csv | Recorded property-type categories; one category has 119 sales |
| 5 | `S05_original_xgb_features.png` | stages/05_shap/results/team_original_xgb_external_shap.csv, XGBoost.ipynb | Original notebook printed feature-level SHAP means |
| 5 | `S05_shap_bootstrap_intervals.png` | stages/05_shap/results/lightgbm_sample_group_share_bootstrap.csv | 320 sampled test explanations; sample-conditional bootstrap intervals |
| 5 | `S05_shap_groups.png` | stages/05_shap/results/team_original_xgb_external_shap.csv, stages/05_shap/results/companion_group_SHAP_importance.csv, XGBoost.ipynb | Original XGBoost values + 320 LightGBM / 16 exploratory RF test explanations |
| 5 | `S05_shap_vs_ablation.png` | stages/05_shap/results/team_original_shap_vs_drop_one.csv | Thirteen original external features; separate source-reported drop-one experiment |
| 6 | `S06_council_reference_folds.png` | stages/06_hedonic_robustness/results/council_value_reference_by_fold.csv | Price-screened held-out sales across five folds |
| 6 | `S06_hedonic_comparison.png` | stages/06_hedonic_robustness/results/hedonic_pooled_metrics.csv, stages/06_hedonic_robustness/results/ORIGINAL_TEAM_REPORTED_ONLY.json, stages/02_property_prediction/results/all_models_augmented_comparison.csv | Five-fold price-screened evaluation, source-reported original models and separately fitted Ridge |
| 6 | `S06_hedonic_fold_errors.png` | stages/06_hedonic_robustness/results/hedonic_fold_metrics.csv | Five expanding chronological, price-screened test folds |
| 6 | `S06_price_screening_by_fold.png` | stages/06_hedonic_robustness/results/fold_registry_summary.csv | Five test blocks of 9,966 sales each |
| 6 | `S06_repeat_properties.png` | stages/06_hedonic_robustness/results/repeat_property_pooled_lightgbm.csv | 48,848 price-screened test sales; original property identifiers |
| 6 | `S06_spatial_holdout.png` | stages/06_hedonic_robustness/results/robustness_holdout_experiments.csv | Final chronological test fold |
| 6 | `S06_test_scope.png` | stages/06_hedonic_robustness/results/robustness_holdout_experiments.csv | Last fold: 9,784 screened vs 9,966 all eligible |

## Verification and reproducibility

Rebuild all figures, their SHA-256 records and the Word report with:

```bash
python evidence/build_evidence.py --dataset /path/newest_dvrs_with_team_external.parquet --notebook /path/XGBoost.ipynb
python evidence/compose_report.py
python -m pytest -q evidence/test_evidence.py
```

Exact input file SHA-256 fingerprints, plotting methods and output checksums are in `evidence/FIGURE_PROVENANCE.json`. The source Parquet and XGBoost notebook are intentionally absent from the distributable ZIP.

**Interpretation boundary:** The original XGBoost per-sale predictions are unavailable. Any figure showing detailed held-out subgroup, spatial, or repeat-property errors comes from the named companion model. Council capital values are a retrospective comparison only, and environmental subgroup differences do not identify causal effects.
