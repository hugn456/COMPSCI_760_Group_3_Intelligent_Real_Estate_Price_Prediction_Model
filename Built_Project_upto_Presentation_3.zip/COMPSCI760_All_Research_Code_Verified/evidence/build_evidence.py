"""Generate authentic charts exclusively from verified COMPSCI 760 inputs.

Run from project root:
 python evidence/build_evidence.py --dataset /path/newest_dvrs_with_team_external.parquet --notebook /path/XGBoost.ipynb

No synthetic observations, simulated predictions, or image generation is used.
Source analysis CSVs are the saved results of the project experiments; some are
aggregated, so plotting them reproduces evidence VISUALISATIONS, not model fits.

All source SHA256 hashes are logged to evidence/FIGURE_PROVENANCE.json.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import re
import sys
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter

ROOT=Path(__file__).resolve().parents[1]
STAGES=ROOT/'stages'
FIGS=ROOT/'report'/'evidence_figures'
FIGS.mkdir(parents=True,exist_ok=True)
plt.rcParams.update({'figure.dpi':125,'savefig.dpi':190,'font.size':10,'axes.titlesize':12,'axes.labelsize':9,'figure.facecolor':'white','axes.grid':False})
BLUE='#294C73'; TEAL='#087E80'; SLATE='#697D91'; ORANGE='#C97825'; RED='#AA4D45'; PURPLE='#70609A'
PLOT_COLORS=[BLUE,TEAL,SLATE,ORANGE,PURPLE,RED]
records=[]

def h(path:Path):
 sh=hashlib.sha256()
 with open(path,'rb') as f:
  for b in iter(lambda:f.read(1<<20),b''): sh.update(b)
 return sh.hexdigest()

def sources(*paths):
 return [{'path':str(Path(p).resolve().relative_to(ROOT)) if Path(p).resolve().is_relative_to(ROOT) else Path(p).name,'sha256':h(Path(p))} for p in paths]

def save(fig,name,stage,title,inputs,scope,method):
 fig.tight_layout(pad=1.45)
 output=FIGS/name
 fig.savefig(output,bbox_inches='tight',facecolor='white')
 plt.close(fig)
 records.append({'figure':f'report/evidence_figures/{name}','stage':stage,'title':title,'inputs':sources(*inputs),'data_scope':scope,'method':method,'figure_sha256':h(output),'synthetic_data':False})
 print('generated',name,flush=True)


def plot_currency(y,pos):return f'${y/1000:,.0f}k'

def ensure(df,where,expected=None):
 if expected is not None and len(df)!=expected:raise AssertionError(f'{where}: unexpected n {len(df)} != {expected}')
 if df.empty:raise ValueError(f'{where}: empty table')


def build(dataset,notebook):
 source_manifest=json.loads((ROOT/'source_manifest.json').read_text())
 for kind,p in [('dataset',dataset),('original_xgboost_notebook',notebook)]:
  exp=source_manifest[kind]['sha256']
  if h(p)!=exp:raise ValueError(f'Original {kind} SHA-256 differs; stopping rather than plotting unverified sources')

 # STAGE 1: full dataset rows/real filters, and source audit
 a=STAGES/'01_data_audit'/'results'/'dataset_audit.json'
 stage1=json.loads(a.read_text())
 vals=stage1['eligibility_counts']
 assert vals['source']==92010 and vals['LINZ matched']==59798
 fig,ax=plt.subplots(figsize=(8.0,3.6))
 labels=['All sales','Zoning','Single unit','Freehold','Sale type S','Price/value rule','LINZ linked']
 n=list(vals.values())
 bars=ax.barh(range(len(n)),n,color=[BLUE]+[TEAL]*5+[ORANGE])
 ax.invert_yaxis();ax.set_yticks(range(len(n)),labels)
 for b,v in zip(bars,n): ax.text(v+700,b.get_y()+b.get_height()/2,f'{v:,}',va='center',fontsize=9)
 ax.set_xlim(0,max(n)*1.18);ax.set_xlabel('Transaction count')
 ax.set_title('Transaction selection under the six project rules')
 ax.spines[['top','right']].set_visible(False)
 save(fig,'S01_eligibility_counts.png',1,'Source-to-analysis cohort retention',[a],f'{n[0]:,} raw / {n[-1]:,} eligible','Plot verified transaction counts from full Parquet audit')

 miss=pd.Series(stage1['missing_values_by_column_eligible'],dtype=float)
 exclude=['valuation_number_suffix','additional_situation_number']
 selected=miss.drop(labels=exclude,errors='ignore').sort_values(ascending=False)
 selected=selected[selected>0].head(9)
 fig,ax=plt.subplots(figsize=(8.0,4.0))
 p=100*selected/stage1['eligible_rows']
 ax.barh(range(len(p)),p.to_numpy(),color=BLUE)
 ax.invert_yaxis();ax.set_yticks(range(len(p)),[x.replace('_',' ') for x in p.index],fontsize=8.4)
 ax.set_xlabel('Share missing among eligible sales (%)');ax.set_title('Missingness in selected modelling-related fields')
 for i,v in enumerate(p):ax.text(v+0.07,i,f'{v:.1f}%',va='center',fontsize=8)
 ax.set_xlim(0,max(p)*1.22);ax.spines[['top','right']].set_visible(False)
 save(fig,'S01_missingness.png',1,'Recorded missingness in selected fields',[a],f'{stage1["eligible_rows"]:,} eligible sales','Exact eligible-cohort missing counts / cohort size. Two mostly identifier fields excluded from plot but remain in audit.')

 # Stage 1 additional transaction price spread from actual Parquet (not imagined)
 sys.path.insert(0,str(ROOT))
 sys.path.insert(0,str(STAGES/'03_time_series'/'src'))
 from common.parquet_readonly import read_parquet
 from stage03_core import reproduce_teammate_eligibility
 raw=read_parquet(dataset,columns=['sale_date','sale_price_gross','zoning','units_of_use','sale_tenure','sale_type','price_value_relationship','linz_matched'])
 eligible,counts=reproduce_teammate_eligibility(raw)
 if counts!=vals:raise AssertionError('Source-data filters do not reproduce Stage1 audit counts')
 price=pd.to_numeric(eligible['sale_price_gross'],errors='coerce')
 price=price[(price>0)&(price<=5_000_000)]
 fig,ax=plt.subplots(figsize=(8.0,3.7))
 bins=np.arange(0,5_000_001,100_000)
 ax.hist(price.to_numpy()/1e6,bins=bins/1e6,color=TEAL,edgecolor='white',lw=.2)
 ax.axvline(price.median()/1e6,color=ORANGE,ls='--',lw=1.8,label=f'Median ${price.median()/1e6:.2f}m within plotted range')
 ax.set_title('Eligible sale-price distribution (up to NZ$5m)')
 ax.set_xlabel('Sale price (NZ$ million)');ax.set_ylabel('Number of sales')
 ax.legend(fontsize=8,loc='upper right');ax.spines[['top','right']].set_visible(False)
 save(fig,'S01_sale_prices.png',1,'Empirical eligible-sale price histogram',[dataset,a],f'{len(price):,} eligible sales up to NZ$5m','Read actual sale prices from source Parquet; six unchanged filters; values above NZ$5m omitted only from this display')

 # STAGE 2 saved aggregate prediction benchmarks and ablations
 R=STAGES/'02_property_prediction'/'results'
 m=R/'all_models_augmented_comparison.csv';d=pd.read_csv(m);ensure(d,'stage2',9)
 d=d.sort_values('MAE',ascending=True)
 fig,ax=plt.subplots(figsize=(8.1,4.7))
 names=d.model.astype(str).str.replace(' — teammate original',' (original)',regex=False).str.replace('HistGradientBoosting','Histogram GB',regex=False)
 b=ax.barh(range(len(d)),d.MAE/1000,color=[TEAL if 'XGBoost' in str(n) else BLUE for n in d.model])
 ax.invert_yaxis();ax.set_yticks(range(len(d)),names,fontsize=8)
 for i,v in enumerate(d.MAE):ax.text(v/1000+3,i,f'${v/1000:,.0f}k',va='center',fontsize=8)
 ax.set_xlim(0,d.MAE.max()/1000*1.19)
 ax.set_xlabel('Pooled mean absolute error (NZ$ thousand)');ax.set_title('Property-level prediction: model comparison')
 ax.spines[['top','right']].set_visible(False)
 save(fig,'S02_model_comparison.png',2,'Property-level model MAE comparison',[m],f'{int(d.n_test.iloc[0]):,} price-screened evaluation sales reported per model','XGBoost row is reported from immutable notebook; other rows are separately run experiments with protocol-aligned, not paired row-verified, results')

 x=R/'non_xgb_feature_ablation.csv';v=pd.read_csv(x);ensure(v,'stage2 ablation',3)
 fig,ax=plt.subplots(figsize=(8.0,3.45));xx=np.arange(len(v));w=.36
 a1=ax.bar(xx-w/2,v.property_only_MAE/1000,w,label='Property-only',color=SLATE)
 a2=ax.bar(xx+w/2,v.augmented_MAE/1000,w,label='Augmented',color=TEAL)
 for bars in (a1,a2):
  for bar in bars:ax.text(bar.get_x()+bar.get_width()/2,bar.get_height()+3,f'{bar.get_height():.0f}',ha='center',fontsize=8)
 ax.set_xticks(xx,v.model.str.replace('HistGradientBoosting','Histogram GB'),fontsize=9)
 ax.set_ylabel('MAE (NZ$ thousand)');ax.set_title('Impact of augmented features on separate boosting models')
 ax.legend(frameon=False,ncol=2,fontsize=9);ax.set_ylim(0,250);ax.spines[['top','right']].set_visible(False)
 save(fig,'S02_feature_ablation.png',2,'Feature-group ablation in independent boosting models',[x],'Five-fold price-screened evaluation','Property-only and augmented scores from model runs; not a causal isolation of hazard variables')

 # Stage 2 by-fold also provenance-backed supplemental
 folds=R/'fold_by_fold_comparison.csv';f=pd.read_csv(folds)
 keep=['XGBoost — teammate original','LightGBM','Random Forest']
 f=f[f.model.isin(keep)]
 if not f.empty:
  fig,ax=plt.subplots(figsize=(8.0,3.4))
  for i,(nm,sub) in enumerate(f.groupby('model',sort=False)):
   ax.plot(sub.fold,sub.MAE/1000,'o-',color=PLOT_COLORS[i],label=nm.replace(' — teammate original',' (original)'))
  ax.set_xticks([1,2,3,4,5]);ax.set_ylabel('Fold MAE (NZ$ thousand)');ax.set_xlabel('Chronological fold')
  ax.set_title('Fold-wise prediction error (reported, non-paired comparisons)')
  ax.legend(frameon=False,fontsize=8,ncol=2);ax.spines[['top','right']].set_visible(False)
  save(fig,'S02_fold_mae.png',2,'Fold-wise MAE, descriptive only',[folds],'Five chronological folds','Source XGBoost fold scores from original notebook; independent companions evaluated under related protocol')

 # STAGE 3: chronological observations and evaluated forecasts
 R=STAGES/'03_time_series'/'results';series=R/'monthly_median_series.csv';sf=pd.read_csv(series);ensure(sf,'stage3',30)
 sf.month=pd.to_datetime(sf.month)
 fig,ax=plt.subplots(figsize=(8.3,3.6))
 ax.plot(sf.month,sf.median_price_nzd/1e6,'o-',color=BLUE,ms=3,lw=1.5)
 ax.axvspan(pd.Timestamp('2025-07-01'),pd.Timestamp('2025-12-31'),color=TEAL,alpha=.12,label='Validation')
 ax.axvspan(pd.Timestamp('2026-01-01'),pd.Timestamp('2026-06-30'),color=ORANGE,alpha=.12,label='Test')
 ax.set_title('Monthly median sale price, January 2024–June 2026')
 ax.set_ylabel('Median sale price (NZ$ million)');ax.legend(fontsize=8,frameon=False,ncol=2);ax.spines[['top','right']].set_visible(False)
 save(fig,'S03_monthly_medians.png',3,'Empirical monthly median prices and evaluation periods',[series],f'{int(sf.n_sales.sum()):,} sales; 30 months','Plot recorded monthly medians aggregated from original Parquet; validation/test intervals given by experiment manifest')
 forecasts=R/'walk_forward_one_step_forecasts.csv';pr=pd.read_csv(forecasts)
 sel=pr[(pr.phase=='test')&(pr.model=='Seasonal naive (12m)')].sort_values('month')
 ensure(sel,'stage3 selected test forecasts',6)
 assert round(np.mean(abs(sel.forecast_nzd-sel.actual_nzd)))==9500
 fig,ax=plt.subplots(figsize=(8.1,3.55));xx=np.arange(len(sel))
 ax.plot(xx,sel.actual_nzd/1000,'o-',lw=2,color=BLUE,label='Actual monthly median')
 ax.plot(xx,sel.forecast_nzd/1000,'s--',lw=2,color=ORANGE,label='Seasonal naive forecast')
 ax.set_xticks(xx,pd.to_datetime(sel.month).dt.strftime('%b %Y'))
 ax.set_ylabel('Median sale price (NZ$ thousand)')
 ax.set_title('Six held-out monthly forecasts (test MAE NZ$9,500)')
 ax.legend(frameon=False,fontsize=8);ax.spines[['top','right']].set_visible(False)
 save(fig,'S03_test_forecasts.png',3,'Monthly forecast compared with observed prices',[forecasts],"Six held-out test months (January–June 2026)",'Plot actual versus saved past-only rolling one-step forecast; MAE recalculated in code')

 cmp=R/'forecast_model_comparison.csv';cm=pd.read_csv(cmp)
 test=cm[cm.phase=='test'].sort_values('MAE_nzd')
 fig,ax=plt.subplots(figsize=(8.2,3.9));names=test.model.str.replace('Seasonal naive (12m)','Seasonal naive',regex=False)
 ax.barh(names,test.MAE_nzd/1000,color=[TEAL if 'Seasonal' in s else SLATE for s in test.model]);ax.invert_yaxis()
 ax.set_xlabel('Test MAE (NZ$ thousand)');ax.set_title('Monthly forecasting accuracy on six test months');ax.spines[['top','right']].set_visible(False)
 save(fig,'S03_forecast_methods.png',3,'Test errors of forecasting models',[cmp],"Six test months; validation selected seasonal naive",'Compare held-out test MAE for all eligible approaches; selection was based on validation, not test')

 # STAGE 4: subgroup metrics and signed bias/calibration
 R=STAGES/'04_fairness'/'results';rff=R/'Companion_RandomForest_subgroup_metrics.csv';lff=R/'Companion_LightGBM_subgroup_metrics.csv'
 rf=pd.read_csv(rff);lgb=pd.read_csv(lff)
 a=rf[rf.dimension=='price_band'];b=lgb[lgb.dimension=='price_band'];ensure(a,'rf price bands',5);ensure(b,'lgb price bands',5)
 labels=['< $750k','$750k–$1m','$1m–$1.5m','$1.5m–$2m','$2m+']
 xx=np.arange(5);w=.36
 fig,ax=plt.subplots(figsize=(8.1,3.5))
 ax.bar(xx-w/2,a.MAE_NZD.to_numpy()/1000,w,label='Random Forest',color=SLATE)
 ax.bar(xx+w/2,b.MAE_NZD.to_numpy()/1000,w,label='LightGBM',color=TEAL)
 ax.set_xticks(xx,labels,fontsize=8)
 ax.set_ylabel('Subgroup MAE (NZ$ thousand)');ax.set_title('Price-band reliability across companion models')
 ax.legend(frameon=False,fontsize=9);ax.spines[['top','right']].set_visible(False)
 save(fig,'S04_price_band_mae.png',4,'Error magnitude by realised sale-price band',[rff,lff],'48,848 price-screened test sales across five chronological folds','Price-band aggregation of actual out-of-fold errors; separate models only, not XGBoost')
 fig,ax=plt.subplots(figsize=(8.1,3.6))
 ax.axhline(0,color='#444444',lw=.8)
 ax.plot(xx,a.signed_bias_NZD.to_numpy()/1000,'o-',color=SLATE,label='Random Forest')
 ax.plot(xx,b.signed_bias_NZD.to_numpy()/1000,'s-',color=TEAL,label='LightGBM')
 ax.set_xticks(xx,labels,fontsize=8);ax.set_ylabel('Mean (prediction − sale) (NZ$ thousand)')
 ax.set_title('Direction of prediction bias by observed sale-price band')
 ax.legend(frameon=False,fontsize=9);ax.spines[['top','right']].set_visible(False)
 save(fig,'S04_price_band_bias.png',4,'Signed error by property price band',[rff,lff],'Same out-of-fold companion model test sales','Mean predicted minus observed sale price per group')
 calfile=R/'Companion_LightGBM_predicted_decile_calibration.csv';cal=pd.read_csv(calfile)
 fig,ax=plt.subplots(figsize=(5.6,4.2));lo=min(cal.mean_actual_NZD.min(),cal.mean_predicted_NZD.min())/1e6;hi=max(cal.mean_actual_NZD.max(),cal.mean_predicted_NZD.max())/1e6
 ax.plot([lo,hi],[lo,hi],color=SLATE,ls='--',label='Perfect mean calibration')
 ax.plot(cal.mean_predicted_NZD/1e6,cal.mean_actual_NZD/1e6,'o-',color=BLUE,label='LightGBM decile means')
 ax.set_xlabel('Mean predicted price (NZ$m)');ax.set_ylabel('Mean observed sale price (NZ$m)')
 ax.set_title('LightGBM regression calibration by predicted decile')
 ax.legend(frameon=False,fontsize=8);ax.spines[['top','right']].set_visible(False)
 save(fig,'S04_calibration.png',4,'Decile-level mean prediction calibration',[calfile],'Ten equally sized prediction-decile groups of 48,848 test sales','Compare mean observed/predicted prices per decile; aggregate outcomes, not individual points')

 # STAGE 5 source-reported original XGB SHAP and independently fitted companions
 R=STAGES/'05_shap'/'results';team=R/'team_original_xgb_external_shap.csv';external=pd.read_csv(team)
 original_json=json.loads(notebook.read_text(encoding='utf-8'))
 outputs='\n'.join((''.join(o.get('text',[])) if isinstance(o.get('text',[]),list) else str(o.get('text',''))) + ('\n'+''.join(o.get('data',{}).get('text/plain',[])) if isinstance(o.get('data',{}).get('text/plain',[]),list) else str(o.get('data',{}).get('text/plain',''))) for c in original_json['cells'] for o in c.get('outputs',[]))
 if 'SHAP share of external features: 40.1%' not in outputs:raise AssertionError('Original notebook output lacks declared SHAP share')
 for v in external.reported_mean_absolute_SHAP_NZD.head(2):
  if f'{v:,.0f}' not in outputs and f'{v:.0f}' not in outputs:
   raise AssertionError('Original notebook missing SHAP top coordinate output')
 ext=external.sort_values('reported_mean_absolute_SHAP_NZD',ascending=False).head(8)
 fig,ax=plt.subplots(figsize=(8.0,4.0))
 yy=np.arange(len(ext));ax.barh(yy,ext.reported_mean_absolute_SHAP_NZD.to_numpy()/1000,color=[TEAL if nm in ['latitude','longitude'] else BLUE for nm in ext.feature])
 ax.set_yticks(yy,[s.replace('_',' ') for s in ext.feature],fontsize=8);ax.invert_yaxis()
 ax.set_xlabel('Mean |SHAP| (NZ$ thousand)');ax.set_title('Highest-attribution external features: original XGBoost')
 ax.spines[['top','right']].set_visible(False)
 save(fig,'S05_original_xgb_features.png',5,'Original-model feature attribution',[team,notebook],'Original notebook printed feature-level SHAP means','Read original saved notebook output, verified against extracted 13-feature table; not retrained XGBoost')
 groups=R/'companion_group_SHAP_importance.csv';g=pd.read_csv(groups)
 values={
 'XGBoost (original)':[59.9,40.1*(external[external.feature.isin(['latitude','longitude'])].reported_mean_absolute_SHAP_NZD.sum()/external.reported_mean_absolute_SHAP_NZD.sum()),40.1*(1-external[external.feature.isin(['latitude','longitude'])].reported_mean_absolute_SHAP_NZD.sum()/external.reported_mean_absolute_SHAP_NZD.sum())]
 }
 for nm in ['LightGBM','RandomForest']:
  sub=g[g.model==nm].set_index('feature_group')
  values[nm]=[sub.loc[k,'relative_individual_attribution_pct'] for k in ['Property and basic attributes','Coordinates','Other external']]
 fig,ax=plt.subplots(figsize=(8.0,3.25));inds=np.arange(len(values));left=np.zeros(len(values))
 for ci,(name,color) in enumerate(zip(['Property features','Coordinates','Other external'],[BLUE,TEAL,ORANGE])):
  widths=np.array([v[ci] for v in values.values()]);ax.barh(inds,widths,left=left,label=name,color=color)
  for i,val in enumerate(widths):
   if val>3.7:ax.text(left[i]+val/2,i,f'{val:.1f}%',ha='center',va='center',color='white',fontsize=9)
  left+=widths
 ax.set_yticks(inds,list(values));ax.invert_yaxis();ax.set_xlim(0,100)
 ax.set_xlabel('Share of summed mean absolute SHAP attribution (%)')
 ax.set_title('SHAP feature-group attribution: three distinct model fits')
 ax.legend(loc='lower center',bbox_to_anchor=(.5,-.45),ncol=3,frameon=False,fontsize=8)
 ax.spines[['top','right']].set_visible(False)
 save(fig,'S05_shap_groups.png',5,'Group-level SHAP attribution shares',[team,groups,notebook],'Original XGBoost values + 320 LightGBM / 16 exploratory RF test explanations','SHAP for original XGBoost calculated from reported notebook; other models from independent SHAP runs; sample sizes not matched')

 # STAGE 6 source estimates and held-out geospatial/property robustness
 R=STAGES/'06_hedonic_robustness'/'results';hed=R/'hedonic_pooled_metrics.csv';Hd=pd.read_csv(hed)
 original=R/'ORIGINAL_TEAM_REPORTED_ONLY.json';og=json.loads(original.read_text())
 compare=STAGES/'02_property_prediction'/'results'/'all_models_augmented_comparison.csv';comp=pd.read_csv(compare)
 selected=comp[comp.model.str.contains('XGBoost')].iloc[0]
 xgb=float(selected.MAE)
 ols=float(og['teammate_original_Hedonic_OLS']['MAE'])
 pairs=[('XGBoost (original)',xgb),('Hedonic OLS (original)',ols)]
 pairs += [(m.replace('Hedonic Ridge','Ridge hedonic'),float(v)) for m,v in zip(Hd.model,Hd.MAE)]
 fig,ax=plt.subplots(figsize=(8.1,3.1));xx=np.arange(len(pairs));ax.barh(xx,[v/1000 for _,v in pairs],color=[TEAL,SLATE,BLUE,BLUE]);ax.invert_yaxis();ax.set_yticks(xx,[x for x,_ in pairs],fontsize=9)
 for i,(_,v) in enumerate(pairs):ax.text(v/1000+3,i,f'${v/1000:,.0f}k',va='center',fontsize=8)
 ax.set_xlim(0,300);ax.set_xlabel('Pooled MAE (NZ$ thousand)');ax.set_title('Hedonic regression compared with the original XGBoost result')
 ax.spines[['top','right']].set_visible(False)
 save(fig,'S06_hedonic_comparison.png',6,'Hedonic and XGBoost comparative accuracy',[hed,original,compare],'Five-fold price-screened evaluation, source-reported original models and separately fitted Ridge','Original XGB and OLS notebook-reported values; Ridge fitted in Stage 6; no paired XGB significance test')
 rob=R/'robustness_holdout_experiments.csv';ro=pd.read_csv(rob)
 sp=ro[(ro.experiment=='withheld_geographic_blocks')&(ro.scope=='price_trimmed')&ro.subgroup.isin(['unseen_block','seen_or_other_block'])]
 assert len(sp)==2
 sp=sp.set_index('subgroup').loc[['seen_or_other_block','unseen_block']]
 fig,ax=plt.subplots(figsize=(7.6,2.95));xx=np.arange(2)
 ax.bar(xx,sp.MAE/1000,color=[SLATE,ORANGE],width=.6)
 ax.set_xticks(xx,['Other test blocks\n(n=7,405)','Withheld test blocks\n(n=2,379)'])
 ax.set_ylabel('MAE (NZ$ thousand)');ax.set_ylim(0,215)
 for i,v in enumerate(sp.MAE):ax.text(i,v/1000+3,f'${v/1000:,.0f}k',ha='center',fontsize=9)
 ax.set_title('Geographic generalisation: held-out blocks (LightGBM)');ax.spines[['top','right']].set_visible(False)
 save(fig,'S06_spatial_holdout.png',6,'LightGBM error in geographically held-out areas',[rob],'Final chronological test fold','Geographic block exclusion and same-fold MAE on withheld versus other test blocks; property mix may differ')
 rpfile=R/'repeat_property_pooled_lightgbm.csv';rp=pd.read_csv(rpfile).sort_values('property_previously_seen',ascending=False);assert len(rp)==2
 fig,ax=plt.subplots(figsize=(7.6,3.0));xx=np.arange(2)
 vals2=rp.MAE.to_numpy()/1000
 ax.bar(xx,vals2,color=[TEAL,SLATE],width=.6)
 ax.set_xticks(xx,[f'Previously seen\n(n={int(rp.iloc[0]["n"]):,})',f'Unseen property ID\n(n={int(rp.iloc[1]["n"]):,})'])
 for i,v in enumerate(vals2):ax.text(i,v+3,f'${v:,.0f}k',ha='center',fontsize=9)
 ax.set_ylabel('MAE (NZ$ thousand)');ax.set_ylim(0,175)
 ax.set_title('Repeat-property robustness in LightGBM');ax.spines[['top','right']].set_visible(False)
 save(fig,'S06_repeat_properties.png',6,'Seen versus unseen property-level reliability',[rpfile],'48,848 price-screened test sales; original property identifiers','Group held-out OOF predictions by property identifier seen in earlier training folds')
 tail=ro[(ro.experiment=='chronological_reference')&(ro.subgroup=='all')]
 fig,ax=plt.subplots(figsize=(7.5,2.95));tail=tail.set_index('scope').loc[['price_trimmed','all_test_sales']]
 vals3=tail.MAE.values/1000
 ax.bar([0,1],vals3,color=[TEAL,ORANGE],width=.6)
 ax.set_xticks([0,1],['Price-screened test sales\n(n=9,784)','All eligible test sales\n(n=9,966)'])
 for i,v in enumerate(vals3):ax.text(i,v+3,f'${v:,.0f}k',ha='center',fontsize=9)
 ax.set_ylim(0,185);ax.set_ylabel('MAE (NZ$ thousand)');ax.set_title('Evaluation-scope sensitivity: LightGBM, final fold')
 ax.spines[['top','right']].set_visible(False)
 save(fig,'S06_test_scope.png',6,'Effect of price-based test screening on error',[rob],'Last fold: 9,784 screened vs 9,966 all eligible','Compare independently evaluated LightGBM with and without price screening on target test observations')

 # Additional figures use only verified source sales and stored experiment tables.
 from build_more import add_figures
 add_figures(STAGES,eligible,dataset,save)

 manifest={
  'project':'COMPSCI760',
  'description':'Code-generated evidence only; no artificial examples or invented data.',
  'dataset_sha256':h(dataset),
  'original_notebook_sha256':h(notebook),
  'figures':records,
  'figure_count':len(records),
  'original_models_retrained':False,
  'precision_note':'Charts generated from stored aggregate metrics do not rerun models. Stage 1 empirical charts read original transactions directly; every figure has source hashes.',
  'confidentiality_note':'Figures use aggregate counts/metrics only; source dataset and individual property records not included.',
 }
 (ROOT/'evidence'/'FIGURE_PROVENANCE.json').write_text(json.dumps(manifest,indent=2)+'\n')
 print('Completed',len(records),'figures')

if __name__=='__main__':
 p=argparse.ArgumentParser()
 p.add_argument('--dataset',type=Path,required=True)
 p.add_argument('--notebook',type=Path,required=True)
 args=p.parse_args()
 build(args.dataset,args.notebook)
