# Verification record — 13 October 2026

Input SHA-256 fingerprints matched the project's source manifest:

- Dataset (not bundled): `07e5e22ea8c6f73b82477b023f5803961b7ba730f9a7474cbb55a27a2c0fb3b2`
- Original XGBoost notebook (bundled unchanged): `21d388340231d149109195ca0498533de28b33e692c73e6a965ce6a6c62d7057`

Automated unit/consistency tests: **42/42 passed** across six stages, called with:

```bash
python project.py check --dataset /mnt/data/newest_dvrs_with_team_external.parquet --notebook /mnt/data/XGBoost.ipynb
```

Stage tests: Stage 1 = 2 passed; Stage 2 = 6; Stage 3 = 10; Stage 4 = 8; Stage 5 = 9; Stage 6 = 7.

Directly executed against the actual shared Parquet source:

- `project.py run 1`: **92,010** source rows, **59,798** eligible rows.
- `project.py run 3`: **59,281** completed-month sales, **30 months**. Seasonal-naive (12m) was selected using validation **MAE NZ$6,625** and achieved final test **MAE NZ$9,500** and **RMSE NZ$13,054.37**.

Other stages passed tests but did **not** receive a complete fresh full-data model retrain during this verification. Saved aggregate results/figures have different provenance, documented in the original README files.

Dataset and any private predictions are omitted from this package; this prevents accidentally distributing restricted record-level information.
