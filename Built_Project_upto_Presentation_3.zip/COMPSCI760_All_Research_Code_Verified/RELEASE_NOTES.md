## v4 — Human-written academic narrative (11 October 2026)

Rewrote the integrated report for natural, cohesive team writing. All six stage findings and methodological qualifications remain intact; all 32 evidence images and modelling code are unchanged. Updated the Word and Markdown reports and the report source template. Word layout reviewed after full rendering (15 pages).

# Release and verification notes

- Unified six-stage folder structure and one group-voice report.
- Centralised five byte-identical Parquet readers into `common/parquet_readonly.py`; each stage keeps a lightweight compatibility import.
- Preserved modelling functions, experiment settings, saved aggregate metrics and figures; no XGBoost training or notebook changes.
- Added executable Stage 1 audit, project-wide test/reproduction entry point and concise stage documentation.
- Excluded private transaction records, private predictions, individual SHAP values, noisy working logs and obsolete intermediate packages.
- Stage 4 uses the available model-specific subgroup reports; no comprehensive XGBoost subgroup audit is required for this release.
- A passing unit-test suite checks code and saved outputs, but full retraining of every model was not performed for this packaging pass.

## Evidence-figure update (v2)

- Added 18 reproducible Matplotlib charts across six stages; 12 in main report and 6 in appendix.
- Added evidence plotting source, report composition source, and a per-figure SHA-256 provenance manifest.
- Charts are sourced from the actual Parquet data, unmodified original XGBoost saved output, or real experiment CSVs; no artificial images or fabricated individual predictions.
- The visualisation build does not constitute refitting all models; existing aggregate results are reused for accuracy and efficiency.
- Expanded integrated Word report to illustrate data audit, prediction, forecasting, reliability, SHAP and robustness.

## Expanded evidence update (v3)

- Added **14 further original code-generated figures**, for **32 figures total**: 18 integrated with the six stage findings and 14 supplementary diagnostics in Appendix A.
- New coverage: late-2026 source transaction volumes, annual price spread, model errors by price band, MAE/RMSE tradeoff, monthly forecast errors, past-only historical features, direction of subgroup errors, SHAP uncertainty and ablations, and fold-based hedonic/valuation sensitivity.
- Every new figure is generated from actual Parquet records or a saved experimental result table; original XGBoost prediction rows are not inferred or fabricated.
- The code and the report retain model-specific qualifications, and Council values remain explicitly retrospective.
- Updated source-file hashes and per-figure population/method descriptions in the provenance manifests.
