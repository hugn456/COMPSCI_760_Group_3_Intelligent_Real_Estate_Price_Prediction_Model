# All source code — file inventory

This list covers all **available** six-stage project source code and the separately supplied original XGBoost notebook. It does not claim to include unshared scripts from other teammates.

## Main entry points

- `project.py` — run checks and individual stages.
- `original_teammate_xgboost/XGBoost.ipynb` — byte-identical teammate notebook (read-only original).
- `evidence/build_evidence.py` — regenerate available code-based figures from real inputs and aggregate results.
- `evidence/compose_report.py` — rebuild the report from sources.

## Stage and utility code

- `common/__init__.py`
- `common/parquet_readonly.py`
- `evidence/build_evidence.py`
- `evidence/build_more.py`
- `evidence/compose_report.py`
- `evidence/test_evidence.py`
- `original_teammate_xgboost/XGBoost.ipynb`
- `project.py`
- `stages/01_data_audit/audit.py`
- `stages/01_data_audit/test_audit.py`
- `stages/02_property_prediction/generate_clean_report.py`
- `stages/02_property_prediction/run_additional_benchmarks.py`
- `stages/02_property_prediction/scripts/parquet_readonly.py`
- `stages/02_property_prediction/scripts/run_rf_and_baselines.py`
- `stages/02_property_prediction/tests/test_clean_package.py`
- `stages/03_time_series/render_stage03_report.py`
- `stages/03_time_series/run_exploratory_seasonal.py`
- `stages/03_time_series/run_historical_feature_pilot.py`
- `stages/03_time_series/run_stage03.py`
- `stages/03_time_series/src/companion_stage02_features.py`
- `stages/03_time_series/src/parquet_readonly.py`
- `stages/03_time_series/src/stage03_core.py`
- `stages/03_time_series/tests/test_stage03.py`
- `stages/04_fairness/plot_stage04.py`
- `stages/04_fairness/run_stage04.py`
- `stages/04_fairness/src/data_link.py`
- `stages/04_fairness/src/fairness_core.py`
- `stages/04_fairness/src/parquet_readonly.py`
- `stages/04_fairness/tests/test_fairness.py`
- `stages/04_fairness/write_report.py`
- `stages/05_shap/make_stage05_report.py`
- `stages/05_shap/run_stage05.py`
- `stages/05_shap/src/notebook_cohort_reference.py`
- `stages/05_shap/src/parquet_readonly.py`
- `stages/05_shap/src/source_xgboost_shap.py`
- `stages/05_shap/tests/test_stage05.py`
- `stages/06_hedonic_robustness/generate_private_lightgbm_oof.py`
- `stages/06_hedonic_robustness/make_stage06_report.py`
- `stages/06_hedonic_robustness/run_stage06.py`
- `stages/06_hedonic_robustness/src/parquet_readonly.py`
- `stages/06_hedonic_robustness/src/stage06_core.py`
- `stages/06_hedonic_robustness/src/teammate_cohort_adapter.py`
- `stages/06_hedonic_robustness/tests/test_stage06.py`
