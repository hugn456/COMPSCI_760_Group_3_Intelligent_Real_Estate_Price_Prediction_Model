# Modelling Auckland Property Prices with Explainable AI

*COMPSCI 760 — Group research report*

## Abstract

House prices depend on more than the characteristics of the house itself. In Auckland, location, local amenities and environmental conditions all form part of the picture, while market changes make prices difficult to predict consistently. This study examines how well these factors can be captured using machine learning and traditional valuation methods. From 92,010 transaction records, 59,798 sales met the study's eligibility criteria. XGBoost achieved the lowest reported property-level error among the models tested, with a mean absolute error (MAE) of NZ$131,243 and a root mean squared error (RMSE) of NZ$214,530. Much of the improvement from adding contextual features, however, was associated with latitude and longitude. A separate analysis of monthly sale prices found that a simple seasonal-naive forecast performed best on validation and achieved NZ$9,500 MAE over six test months. Subgroup analysis, SHAP explanations and robustness checks further showed where the models were less reliable. Together, these findings suggest that strong predictions are possible, but their usefulness depends on understanding the data, the evaluation setting and the limits of the model.

## 1. Introduction

Estimating the price of a property is not simply a matter of counting bedrooms or measuring floor area. Two otherwise similar homes can sell for different prices because they sit in different neighbourhoods, have different access to services or face different environmental risks. Auckland offers a useful setting for studying these relationships because property records can be linked with detailed geographic and contextual information.

Machine learning provides a way to capture relationships that may be difficult to express with a conventional regression equation. Yet a low prediction error is only part of a useful valuation system. We also need to know whether additional information genuinely helps, whether the model performs consistently across different types of properties, and how its predictions behave when market conditions or locations change.

This report brings these questions together in six stages. We begin by checking the dataset and evaluating individual property-price predictions. We then examine changes in the wider market, differences in model reliability, the explanations offered by SHAP, and the robustness of the results against traditional valuation methods and less familiar properties. Throughout the analysis, results are described in relation to the particular model and evaluation sample from which they were obtained.

## 2. Stage 1 — Data Cleaning and Audit

The starting dataset contains **92,010 Auckland property transactions**. To make the analysis consistent, we applied the six eligibility conditions used in the established modelling workflow: specified zoning categories, one unit of use, freehold tenure, sale type `S`, the required price–value relationship and a successful LINZ match. After these filters, **59,798 sales** remained. The audit reproduced each intermediate count, giving us a clear record of which transactions entered the study.

Checking the number of records is only the first part of assessing data quality. We also examined missing fields, unusual sale prices, transaction dates, repeated properties and the coverage of geographic and environmental variables. These checks matter because missing information can be easy to misinterpret. For example, a property without a mapped flood-risk value cannot automatically be treated as having no flood risk. Similarly, a Council valuation may appear in the dataset even if its availability at the time of sale is uncertain.

The date coverage also affects the analysis that follows. Sales recorded in July and August 2026 were much fewer than in the preceding months, so their observed medians may not represent complete monthly market activity. Rather than treating those months as comparable to earlier ones, we excluded them from the primary forecasting series. This audit therefore helps define both what the dataset can support and where caution is needed.

![Figure 1. Transaction counts after each source eligibility rule (full dataset audit).](evidence_figures/S01_eligibility_counts.png)
*Evidence source: Full source-data audit.*

![Figure 2. Observed missingness among the eligible sales; two mostly administrative identifier fields omitted from this chart.](evidence_figures/S01_missingness.png)
*Evidence source: Full source-data audit.*

![Figure 3. Monthly sale coverage from the real transaction data; sparse July–August 2026 records are excluded from forecasting.](evidence_figures/S01_monthly_coverage.png)
*Evidence source: Shared Parquet transactions and six source filters.*

## 3. Stage 2 — Property Price Prediction

We compared several approaches to predicting individual sale prices, using five expanding chronological folds so that training observations preceded the transactions being evaluated. The established XGBoost experiment compared **22 basic property features** with an expanded set of **35 features** that included geographic and contextual information. Across **48,848 price-screened held-out sales**, adding those features reduced XGBoost's MAE from **NZ$208,319 to NZ$131,243**, while RMSE fell from **NZ$317,631 to NZ$214,530**. Both changes point to a substantial improvement within the evaluation used in the study.

We placed these results alongside LightGBM, histogram gradient boosting, CatBoost, Random Forest, Extra Trees, Ridge regression and a median-price benchmark. Of the alternatives, LightGBM came closest, with **NZ$133,294 MAE** and **NZ$215,674 RMSE**, compared with **NZ$131,243 MAE** and **NZ$214,530 RMSE** for XGBoost. The difference in MAE is approximately **1.6%**. XGBoost therefore had the lowest *reported* error among the configurations tested, but the available XGBoost outputs did not support a transaction-by-transaction paired significance test against the other models.

The feature comparisons also reveal an important qualification. Although the expanded model performed much better than the property-only baseline, most of the gain associated with external information appears to come from **latitude and longitude**. In the recorded feature-ablation results, other environmental and neighbourhood variables did not show a clear further improvement once coordinates were present. Location is evidently informative, but this result alone does not establish a separate predictive benefit from each additional contextual feature.

![Figure 4. Five-fold pooled MAE by model. XGBoost is the original notebook result; other results are independently fitted and not verified as paired row-level comparisons.](evidence_figures/S02_model_comparison.png)
*Evidence source: Saved experiment result table(s).*

![Figure 5. Property-only versus augmented-feature prediction errors for three boosting models (five-fold MAE).](evidence_figures/S02_feature_ablation.png)
*Evidence source: Saved experiment result table(s).*

![Figure 6. Actual sale-price band MAE for three separately trained boosting methods (not original XGBoost per-sale predictions).](evidence_figures/S02_boosters_by_price_band.png)
*Evidence source: Saved experiment result table(s).*

## 4. Stage 3 — Time Series Forecasting

Individual sale-price prediction tells us how well a model values particular properties. We also wanted to understand whether historical transactions could help anticipate changes in the market as a whole. For that purpose, we calculated the **monthly median sale price** using the eligible transactions. Excluding the sparsely recorded months of July and August 2026 left **59,281 sales over 30 months**, from January 2024 to June 2026. Because the mix of homes sold can change from month to month, these medians should be read as observed transaction prices rather than a quality-adjusted housing index.

The forecasting experiment began with **18 training months**, followed by **six validation months** and **six final test months**. We compared previous-month and seasonal-naive predictions with exponential-smoothing and ARIMA approaches, evaluating forecasts in chronological order. The **seasonal-naive method**, which carries forward the median from the same month of the previous year, had the lowest validation MAE at **NZ$6,625**. On the January–June 2026 test period, it achieved **NZ$9,500 MAE** and approximately **NZ$13,054 RMSE**. A separate six-month fixed-origin forecast provided an additional check. The results are encouraging, particularly for such a simple method, but six held-out months are not enough to establish long-term forecasting superiority.

We then asked a related, but different, question: could recent market trends improve the prediction of individual property prices? We added past-only monthly medians, rolling measures and transaction counts to a separate Random Forest experiment. Its test MAE increased slightly, from **NZ$160,489 to NZ$161,496**. Historical information was useful in the monthly forecasting exercise, but these added features did not improve that particular property-level model. The two findings are compatible because forecasting an overall market median is not the same task as pricing an individual home.

![Figure 7. Recorded monthly median sale prices, with six-month validation and test periods shaded.](evidence_figures/S03_monthly_medians.png)
*Evidence source: Saved experiment result table(s).*

![Figure 8. Actual and seasonal-naive forecasts for the six held-out months; one-month-ahead predictions.](evidence_figures/S03_test_forecasts.png)
*Evidence source: Saved experiment result table(s).*

![Figure 9. Recorded absolute monthly errors for seasonal naive across the validation and test months.](evidence_figures/S03_seasonal_errors_by_month.png)
*Evidence source: Saved experiment result table(s).*

## 5. Stage 4 — Fairness and Prediction Reliability

A single overall error figure can hide quite different experiences across the housing market. A model may perform well on typical properties while making much larger mistakes on expensive homes or in less familiar areas. We therefore examined error by sale-price range, property type, location and environmental group. In this study, the term **fairness** refers to differences in predictive reliability across observable property groups. The available data do not support conclusions about discrimination involving protected demographic characteristics.

The reported XGBoost subgroup results illustrate why this matters. For **9,443 properties sold below NZ$750,000**, predictions were, on average, **NZ$70,700 too high**. Among **3,458 sales at NZ$2 million or more**, **72.5% were underestimated**, with an MAE of about **NZ$401,100**. Comparable patterns appeared in the Random Forest and LightGBM analyses. LightGBM's MAE, for example, rose from **NZ$91,886** for sales below NZ$750,000 to **NZ$400,321** for sales of NZ$2 million or more.

This pattern is consistent with predictions being drawn towards the middle of the price distribution. However, a large dollar error is not necessarily a large *proportional* error, so we also considered relative errors, signed bias and calibration. Differences across flood, noise and geographic groups were informative, but they cannot be attributed directly to those factors without accounting for differences in the properties within each group. The broader lesson is that reliability should be evaluated where a model will be used, not inferred from its overall MAE alone.

![Figure 10. Mean absolute error by observed price band for Random Forest and LightGBM, evaluated on held-out sales.](evidence_figures/S04_price_band_mae.png)
*Evidence source: Saved experiment result table(s).*

![Figure 11. Signed prediction bias by price band (prediction minus actual): positive is overestimation.](evidence_figures/S04_price_band_bias.png)
*Evidence source: Saved experiment result table(s).*

![Figure 12. Overprediction frequencies in price bands. The dashed 50% line indicates an even split, not a fairness target.](evidence_figures/S04_overprediction_rates.png)
*Evidence source: Saved experiment result table(s).*

## 6. Stage 5 — Explainable AI (SHAP)

Once we know which models predict well, the next question is what information they rely on. We used **SHAP** to describe how the fitted tree models distribute their predictions across features. These contributions help interpret model behaviour, although they are not evidence that changing a feature would cause a corresponding change in a property's sale price.

In the XGBoost explanations, the 13 external variables account for **40.1% of total mean absolute SHAP attribution**. That figure initially suggests a large role for contextual information, but it includes the two geographic coordinates. When we separate them, **latitude and longitude account for approximately 33.0% of total attribution**, leaving **7.1% for the other eleven external features**. Put another way, coordinates make up about **82.4% of the attribution within the external-feature group**.

The LightGBM explanations tell a similar story: coordinates account for **34.2%** of total attribution, compared with **6.0%** for the other external variables. An exploratory Random Forest explanation followed the same broad pattern, although its sample was much smaller. These findings help explain why the inclusion of geographic information improved prediction so markedly. They also highlight an important difference between SHAP and a feature-removal experiment: a feature may contribute strongly to fitted predictions without producing a comparable improvement in held-out accuracy when added to the model.

![Figure 13. Highest external-feature SHAP magnitudes recorded in the original XGBoost notebook.](evidence_figures/S05_original_xgb_features.png)
*Evidence source: Original XGBoost notebook and saved numerical results.*

![Figure 14. SHAP attribution share by feature group: source-reported XGBoost, separate LightGBM and exploratory Random Forest.](evidence_figures/S05_shap_groups.png)
*Evidence source: Original XGBoost notebook and saved numerical results.*

![Figure 15. Original XGBoost attribution compared with reported RMSE change when external features are omitted; SHAP and ablation measure different things.](evidence_figures/S05_shap_vs_ablation.png)
*Evidence source: Saved experiment result table(s).*

## 7. Stage 6 — Hedonic Regression and Robustness

A useful price model should do more than outperform a simple benchmark on a familiar test set. We therefore compared the machine-learning results with traditional **hedonic regression** and examined how well predictions held up under less favourable conditions. Hedonic ordinary least squares achieved **NZ$243,001 MAE**. A compact Ridge model produced **NZ$243,267 MAE**, while an augmented Ridge model improved to **NZ$224,749 MAE**. All three errors were higher than the reported XGBoost result. A separate matched comparison also favoured LightGBM over augmented Ridge, although this does not constitute a paired test against XGBoost.

The robustness checks show where the task becomes more difficult. In a LightGBM experiment that withheld selected geographic blocks from training, MAE reached **NZ$175,408** in those blocks, compared with **NZ$121,361** for other test areas. Properties already represented by an identifier in earlier training folds also had lower error (**NZ$100,397**) than properties not previously seen (**NZ$134,732**). Both results suggest that unfamiliar locations and properties pose additional challenges, although differences in housing characteristics may explain part of the gap.

The evaluation population itself made a noticeable difference. On the final chronological fold, LightGBM's MAE was **NZ$123,426** for the price-screened test sales but **NZ$146,370** when all eligible test transactions were included. We also considered Council capital values as a retrospective reference; these achieved approximately **NZ$92,956 MAE** on the screened final-fold subset. Because we could not verify whether every valuation was available before its corresponding sale, this figure should not be presented as a prospective forecast. A direct, timestamped comparison with online property-valuation services also remains unfinished.

![Figure 16. Hedonic linear and regularised baselines compared with the original reported XGBoost accuracy.](evidence_figures/S06_hedonic_comparison.png)
*Evidence source: Saved experiment result table(s).*

![Figure 17. LightGBM error in withheld geographic blocks versus other areas in the final test fold.](evidence_figures/S06_spatial_holdout.png)
*Evidence source: Saved experiment result table(s).*

![Figure 18. Regularised hedonic-model errors across the five chronological folds.](evidence_figures/S06_hedonic_fold_errors.png)
*Evidence source: Saved experiment result table(s).*

## 8. Discussion and Conclusion

Taken together, the results present a consistent picture. More flexible tree-based models predict Auckland property prices more accurately than the traditional hedonic baselines evaluated here, with XGBoost recording the lowest reported MAE and RMSE. Yet the feature-ablation and SHAP analyses suggest that **geographic position**, rather than the full set of environmental variables, explains much of the gain from contextual information. Strong overall accuracy also coexists with marked differences in errors across price bands, locations and property histories.

The monthly forecasting results add a useful distinction. A simple seasonal comparison worked well for anticipating the observed median of properties sold in the following month, while past monthly market indicators did not improve a separate Random Forest model for individual sales. More information is therefore not automatically better; its value depends on the prediction task and how it is introduced into the model.

Several limitations should shape the interpretation of these findings. The original property-level evaluation excludes sales outside price bounds derived from the training data, and the chronological folds can occasionally meet at the same calendar date. Historical availability could not be confirmed for every valuation or environmental field. The monthly series covers only 30 observations, the detailed geographic and subgroup stress tests concern specified additional models rather than XGBoost, and the planned comparison with contemporaneous online valuations is incomplete. Results from separate model runs should also not be mistaken for paired statistical evidence.

Within these boundaries, **XGBoost is the strongest reported property-price model among those tested**. More importantly, the study shows why a convincing valuation analysis needs more than a favourable accuracy score. Understanding the source data, examining the model's explanations and testing its reliability across different properties all help establish where predictions are useful—and where they should be treated with caution.

*All monetary values are in New Zealand dollars. The figures are drawn from the recorded experiments and the source XGBoost notebook; their individual inputs and checksums are documented in the evidence provenance files.*

## Appendix A. Additional Experiment Evidence

The supporting plots below show source observations, sample-size checks, model diagnostics and sensitivity analyses. Figures based on saved aggregates reproduce the visual evidence without implying that model fitting was rerun.

![Figure A1. Empirical sale-price distribution for eligible transactions valued at up to NZ$5 million; larger values are omitted from this display only.](evidence_figures/S01_sale_prices.png)
*Evidence source: Shared Parquet transactions and six source filters.*

![Figure A2. Observed distribution by sale year (values up to NZ$5m). The 2026 sample covers only recorded months; no property-mix adjustment.](evidence_figures/S01_annual_price_spread.png)
*Evidence source: Shared Parquet transactions and six source filters.*

![Figure A3. Five-fold errors for the original XGBoost and two comparison models; descriptive comparison only.](evidence_figures/S02_fold_mae.png)
*Evidence source: Saved experiment result table(s).*

![Figure A4. Reported MAE and RMSE for nine models. The original XGBoost result and companion benchmarks do not form a paired row-level comparison.](evidence_figures/S02_mae_rmse_tradeoff.png)
*Evidence source: Saved experiment result table(s).*

![Figure A5. Out-of-sample MAE for the eight eligible monthly forecasting methods; the seasonal naive method was selected using validation.](evidence_figures/S03_forecast_methods.png)
*Evidence source: Saved experiment result table(s).*

![Figure A6. Number of eligible transactions contributing to each observed monthly median.](evidence_figures/S03_monthly_sale_counts.png)
*Evidence source: Saved experiment result table(s).*

![Figure A7. Past-only monthly features do not improve the separate Random Forest property-level experiment on the evaluation periods shown.](evidence_figures/S03_rf_historical_ablation.png)
*Evidence source: Saved experiment result table(s).*

![Figure A8. Mean predicted and actual prices across LightGBM prediction deciles, with the perfect-calibration reference.](evidence_figures/S04_calibration.png)
*Evidence source: Saved experiment result table(s).*

![Figure A9. LightGBM mean absolute percentage error for observed property-type codes; sample sizes vary substantially.](evidence_figures/S04_property_type_relative_error.png)
*Evidence source: Saved experiment result table(s).*

![Figure A10. Bootstrap intervals for LightGBM SHAP shares across 320 sampled explanations only; they are not population confidence intervals.](evidence_figures/S05_shap_bootstrap_intervals.png)
*Evidence source: Saved experiment result table(s).*

![Figure A11. LightGBM error according to whether the property identifier appeared in an earlier training fold.](evidence_figures/S06_repeat_properties.png)
*Evidence source: Saved experiment result table(s).*

![Figure A12. LightGBM final-fold sensitivity to price-screened versus all eligible test transactions.](evidence_figures/S06_test_scope.png)
*Evidence source: Saved experiment result table(s).*

![Figure A13. Retrospective error of Council capital values. Availability before sale has not been verified.](evidence_figures/S06_council_reference_folds.png)
*Evidence source: Saved experiment result table(s).*

![Figure A14. Number of held-out sales kept or excluded by the study’s price-based evaluation screen.](evidence_figures/S06_price_screening_by_fold.png)
*Evidence source: Saved experiment result table(s).*

## Appendix B. Figure Provenance and Reproduction

All 32 figures were generated by `evidence/build_evidence.py`. The script verifies the original dataset and notebook SHA-256 fingerprints before processing their data or previously saved results. No synthetic observations, simulated prediction errors, or image-generation tools were used.

Stage 1 includes figures regenerated directly from source Parquet transactions. All other figures are plotted from the saved tables created by the project experiments. Replotting these results does not mean the original XGBoost or the comparison models have been retrained. Subgroup and robustness figures relate to the specific named models, not necessarily to XGBoost.

The file `evidence/FIGURE_PROVENANCE.json` lists each figure, the exact input filenames and SHA-256 fingerprints, data population, and plot methodology. The original transaction dataset and XGBoost notebook are required for a full rebuild but are intentionally excluded from the shareable package.

A full academic reference list should be added when this draft is integrated with the group’s literature-review section.

