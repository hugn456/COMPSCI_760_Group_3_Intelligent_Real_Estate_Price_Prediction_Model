# COMPSCI 760 — Complete available research code

**Project:** Modelling Auckland Property Prices with Explainable AI (Group 3)  
**Prepared:** 13 October 2026

This archive brings together the complete **available code** for the six-stage research workflow, its figure-building scripts, tests, aggregate-only results, and a byte-for-byte unmodified copy of the original teammate XGBoost notebook. The original notebook is not refitted or modified by this packaging step. Dataset/transaction-level inputs are **not included**.

## Read this first

This collection contains the code available from our prior six-stage research package and the original `XGBoost.ipynb` supplied in the conversation. It **does not claim** to include independent geocoding/Splink, external spatial-joining, or other teammates' original R/Python scripts that were not supplied as source files. The team GitHub repository may contain additional code; do not treat this archive as a byte-identical export of the entire team GitHub repository.

The results have different provenance:

- **Original XGBoost**: source results from `original_teammate_xgboost/XGBoost.ipynb` (unchanged). Do not replace these results with an independent XGBoost replay. The notebook provides the original five-fold configurations and performance.
- **Other prediction models**: companion Python research experiments and saved aggregate comparisons; their results are not the original XGBoost model.
- **Stage 3 monthly forecasting**: executable experiments using actual sale data with a separate 18/6/6 month evaluation design.
- **Stage 4 fairness/reliability**: companion Random Forest and LightGBM subgroup tests. Original XGBoost subgroup figures are source-reported and should not be confused with companion prediction tables.
- **Stage 5 explainability**: original-source SHAP summaries and separately labelled supplementary model analyses. SHAP is descriptive, not causal.
- **Stage 6 robustness**: hedonic benchmarks and companion LightGBM stress tests; geographic/individual-property stress tests are not direct original XGBoost results.

## Folder guide

| Folder | Available code |
|---|---|
| `original_teammate_xgboost/` | Unmodified source XGBoost notebook |
| `stages/01_data_audit/` | Dataset audit and tests |
| `stages/02_property_prediction/` | Random Forest, LightGBM, CatBoost, Extra Trees, hist. gradient boosting, Ridge and baselines |
| `stages/03_time_series/` | Monthly forecasting and historical feature pilot |
| `stages/04_fairness/` | Group reliability, calibration and plotting |
| `stages/05_shap/` | Source-backed and supplementary SHAP processing |
| `stages/06_hedonic_robustness/` | Hedonic, spatial and price-tail analyses |
| `evidence/` | Plot generation, provenance and report composition |
| `common/` | Read-only Parquet decoding helper |
| `project.py` | Unified CLI to check and run individual stages |
| `ALL_CODE_FILES.md` | Complete source code index |
| `VERIFICATION.md` | Exact checks performed in this environment |

## Setup

Python 3.11+ and a local environment with packages specified in `requirements.txt` are recommended.

```bash
python -m pip install -r requirements.txt
python project.py check
```

The original data file is excluded from this ZIP. Obtain access to the authorized project dataset and point the scripts to it when running the experiments. The expected original filename is `newest_dvrs_with_team_external.parquet`.

### Verify input fingerprints (recommended)

```bash
python project.py check \
  --dataset /path/to/newest_dvrs_with_team_external.parquet \
  --notebook original_teammate_xgboost/XGBoost.ipynb
```

The `check` command compares both files against the hashes in `source_manifest.json`.

### Run stages

```bash
python project.py run 1 --dataset /path/to/newest_dvrs_with_team_external.parquet --notebook original_teammate_xgboost/XGBoost.ipynb
python project.py run 2 --dataset /path/to/newest_dvrs_with_team_external.parquet --notebook original_teammate_xgboost/XGBoost.ipynb --extended
python project.py run 3 --dataset /path/to/newest_dvrs_with_team_external.parquet --notebook original_teammate_xgboost/XGBoost.ipynb
python project.py run 4 --dataset /path/to/newest_dvrs_with_team_external.parquet --notebook original_teammate_xgboost/XGBoost.ipynb
python project.py run 5 --dataset /path/to/newest_dvrs_with_team_external.parquet --notebook original_teammate_xgboost/XGBoost.ipynb
python project.py run 6 --dataset /path/to/newest_dvrs_with_team_external.parquet --notebook original_teammate_xgboost/XGBoost.ipynb
```

Run Stage 2 `--extended` first if Stages 4 and 6 are to use privately generated RF/LightGBM out-of-fold prediction files. Those source-level intermediate predictions are kept out of the archive; the CLI looks in the private `local_runs/stage02/` folders. You may also pass `--rf-oof` and/or `--lgbm-oof` to point at already available authorized predictions.

Stages 2, 4, 5 and 6 may be computationally expensive. Running the supplied original XGBoost notebook is a separate undertaking and may require configuring file locations in **your local execution copy**; the archived original must stay unchanged.

### Recreate figures

```bash
python evidence/build_evidence.py \
  --dataset /path/to/newest_dvrs_with_team_external.parquet \
  --notebook original_teammate_xgboost/XGBoost.ipynb
python evidence/compose_report.py
```

These scripts recreate the **research evidence plots** from original data, notebook outputs and aggregate experiment results. The decorative illustrations designed for the presentation are not experimental code outputs and should not be treated as data-generated evidence. Review `evidence/FIGURE_PROVENANCE.md` and its JSON/CSV manifests for plot-level sources.

## Important limitations / academic attribution

The full original XGBoost notebook and the separate Python companion implementations are distinguishable by folder and documented provenance. The companion codebase was assembled as analysis assistance; documentation, plots and results should be properly attributed in a group submission. Open-source packages are dependencies, not original group implementations. The original dataset is restricted; do not publish the source data or raw per-sale predictions.

No real model runtime, processor/RAM specification or training convergence curve has been newly inferred or fabricated for this code package. The existing presentation's unverified figure should not be cited as a run of this code.

**What was verified:** `VERIFICATION.md` gives the precise unit-test and stage rerun outcomes. Full end-to-end retraining of every expensive model was not part of this packaging verification.
