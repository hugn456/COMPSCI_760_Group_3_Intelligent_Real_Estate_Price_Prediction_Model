# Stage 4 — Fairness and Prediction Reliability

Audits the variation in prediction error and calibration across property-price ranges, property categories, geographical groups and mapped hazards. The detailed audit uses the existing Random Forest and LightGBM prediction tables; XGBoost group findings remain source-reported.

**Primary outputs:** `results/Companion_*_subgroup_metrics.csv`, calibration and reliability plots.

**Run:** `python project.py run 4 --dataset PATH --notebook PATH --rf-oof PRIVATE_PATH --lgbm-oof PRIVATE_PATH`. These predictions are not distributed; `python project.py run 2 --dataset PATH --notebook PATH --extended` generates them in private local storage. Once available, the `--rf-oof` and `--lgbm-oof` flags can be omitted.

**Interpretation:** Predictive reliability differs by observable property group. Demographic fairness or discrimination cannot be inferred.

Reproduction details and project-wide safeguards are in the repository-level `README.md`.
