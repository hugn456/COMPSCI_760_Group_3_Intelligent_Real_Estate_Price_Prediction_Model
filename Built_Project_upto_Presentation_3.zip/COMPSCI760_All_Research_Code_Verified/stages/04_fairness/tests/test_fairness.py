from pathlib import Path
import sys
import numpy as np,pandas as pd,pytest
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
sys.path.insert(0,str(ROOT))
from fairness_core import check_predictions,attach_context,cluster_bootstrap,group_audits,score,predicted_deciles,validation_only_bias_adjustment
from run_stage04 import team_export,companion_file


def fixture(n=1200):
    rng=np.random.default_rng(25)
    d=pd.DataFrame({'row_id':np.arange(n),'fold':np.tile(np.arange(1,6),n//5),
                    'actual':rng.uniform(200000,3000000,n)})
    d['prediction']=d.actual*.9+80000+rng.normal(0,50000,n)
    context=pd.DataFrame({'row_id':np.arange(n),'sale_price_gross':d.actual,
        'property_key':['PROPERTY_'+str(k//3) for k in range(n)],
        'price_band':['filler']*n,'property_type_group':['R']*n,
        'flood_plain_group':rng.choice(['inside_flood_plain','outside_flood_plain'],n),
        'flood_sensitive_group':['outside_sensitive_area']*n,'noise_group':['outside_overlay']*n,
        'spatial_grid':['cell_'+str(k%5) for k in range(n)],
        'sale_month_group':['2025-01']*n})
    return d,context

def test_source_join_and_realized_price_guard():
    p,c=fixture();m=attach_context(p,c)
    assert len(m)==1200 and 'signed_error' in m
    p.loc[0,'actual']+=1
    with pytest.raises(ValueError,match='realised price'):attach_context(p,c)

def test_duplicated_ids_and_missing_target_rejected():
    p,_=fixture()
    with pytest.raises(ValueError,match='Duplicated'):check_predictions(pd.concat([p,p.iloc[[0]]]))
    p.loc[0,'prediction']=np.nan
    with pytest.raises(ValueError,match='Missing'):check_predictions(p)

def test_price_band_boundaries_and_error_sign():
    p,c=fixture();p.loc[:4,'actual']=[749999,750000,1000000,1500000,2000000]
    c.loc[:4,'sale_price_gross']=p.loc[:4,'actual']
    m=attach_context(p,c)
    assert list(m.price_band.iloc[:5].astype(str))==['<750k','750k–1m','1m–1.5m','1.5m–2m','>=2m']
    assert np.allclose(m.signed_error,m.prediction-m.actual)

def test_cluster_bootstrap_reproducibility():
    p,c=fixture();m=attach_context(p,c)
    x=cluster_bootstrap(m,100,seed=7);y=cluster_bootstrap(m,100,seed=7)
    assert x==y and x['n_property_clusters']==400
    assert x['MAE_CI95_lo'] < m.abs_error.mean() < x['MAE_CI95_hi']

def test_group_suppression_and_decile_calibration():
    p,c=fixture();m=attach_context(p,c)
    t,s=group_audits(m,min_n=100,reps=12)
    assert (t.n>=100).all() and 'price_band' in set(t.dimension)
    assert 'MAE_CI95_lo' in t.columns
    dec=predicted_deciles(m)
    assert len(dec)==10 and dec.n.sum()==1200

def test_val_only_postprocessing_on_late_folds():
    p,c=fixture();m=attach_context(p,c)
    tab,adjusted=validation_only_bias_adjustment(m)
    assert len(tab)==2
    assert len(adjusted)==len(m[m.fold>=4])
    assert 'Validation-fitted diagnostic adjustment' in set(tab.variant)

def test_team_export_stays_read_only(tmp_path):
    p,c=fixture();p=p.rename(columns={'prediction':'augmented_pred'})
    fp=tmp_path/'original_team_oof.csv';p.to_csv(fp,index=False)
    before=fp.read_bytes();q=team_export(fp)
    assert q.shape==(1200,4)
    assert fp.read_bytes()==before

def test_requires_original_team_oof_and_never_uses_proxy():
    import inspect
    from run_stage04 import run
    s=inspect.getsource(run)
    assert 'Original team XGBoost row-level OOF CSV REQUIRED' in s
    assert 'source==\'team\'' in s
