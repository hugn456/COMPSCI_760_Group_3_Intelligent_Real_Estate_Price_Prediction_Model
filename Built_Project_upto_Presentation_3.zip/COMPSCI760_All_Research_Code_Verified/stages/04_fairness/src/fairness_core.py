"""Post-hoc REGRESSION reliability audit; NEVER interprets group disparities as demographic proof."""
from __future__ import annotations
import numpy as np
import pandas as pd

REQUIRED=['row_id','fold','actual','prediction']
BINS=[0,750000,1000000,1500000,2000000,np.inf]
BAND_LABELS=['<750k','750k–1m','1m–1.5m','1.5m–2m','>=2m']


def check_predictions(p):
    p=p.copy()
    for col in REQUIRED:
        if col not in p:raise ValueError('Predictions lack required column '+col)
    for col in REQUIRED:
        if p[col].isna().any():raise ValueError('Missing '+col)
    for col in REQUIRED:
        p[col]=pd.to_numeric(p[col],errors='raise')
    if p.duplicated(['row_id','fold']).any():
        raise ValueError('Duplicated (row_id, fold); select exactly one model/feature configuration')
    if (p.actual<=0).any():raise ValueError('Realised prices must be positive')
    if not np.isfinite(p[REQUIRED].to_numpy(dtype=float)).all():raise ValueError('Non-finite prediction or score')
    if (p.fold.astype(int)!=p.fold).any() or not p.fold.between(1,5).all():raise ValueError('Invalid fold ID')
    if (p.row_id.astype(int)!=p.row_id).any() or (p.row_id<0).any():raise ValueError('Invalid row_id')
    return p


def attach_context(p,context,strict_original=False):
    p=check_predictions(p)
    if strict_original and len(p)!=48848:
        raise ValueError('Original teammate OOF export expected 48,848 rows; provide complete fold records')
    attrs=context.copy()
    if attrs.duplicated('row_id').any():raise ValueError('Nonunique cohort row IDs')
    if not set(p.row_id).issubset(set(attrs.row_id)):
        raise ValueError('Prediction row IDs are not in the frozen source cohort')
    cols=[c for c in attrs.columns if c not in p.columns or c=='row_id']
    joined=p.merge(attrs[cols],how='left',on='row_id',validate='many_to_one',indicator=True)
    if not joined._merge.eq('both').all():raise ValueError('Unmatched prediction IDs')
    joined=joined.drop(columns=['_merge'])
    price=pd.to_numeric(joined.sale_price_gross,errors='coerce')
    if not np.allclose(joined.actual.to_numpy(dtype=float),price.to_numpy(dtype=float),rtol=0,atol=.01):
        raise ValueError('Row-to-property association invalid: realised price does not match source row')
    joined['price_band']=pd.cut(joined.actual,BINS,labels=BAND_LABELS,include_lowest=True,right=False)
    joined['signed_error']=joined.prediction-joined.actual
    joined['abs_error']=joined.signed_error.abs()
    joined['abs_pct_error']=joined.abs_error/joined.actual*100
    joined['overpredicted']=(joined.signed_error>0).astype(int)
    joined['property_key']=joined.property_key.astype('string')
    missing=joined.property_key.isna()|joined.property_key.fillna('').eq('')
    joined.loc[missing,'property_key']='ROW_'+joined.loc[missing,'row_id'].astype(str)
    return joined


def score(part):
    e=part.signed_error.to_numpy(dtype=float)
    return dict(n=int(len(part)),MAE_NZD=float(np.abs(e).mean()),RMSE_NZD=float(np.sqrt(np.mean(e**2))),
       median_APE_pct=float(part.abs_pct_error.median()),mean_APE_pct=float(part.abs_pct_error.mean()),
       signed_bias_NZD=float(e.mean()),median_signed_error_NZD=float(np.median(e)),
       overprediction_pct=float((e>0).mean()*100),underprediction_pct=float((e<0).mean()*100),
       mean_actual_NZD=float(part.actual.mean()),mean_predicted_NZD=float(part.prediction.mean()))


def cluster_bootstrap(part,replicates=250,seed=760):
    if not len(part):raise ValueError('Empty group')
    g=part.groupby('property_key',dropna=False).agg(ae_sum=('abs_error','sum'),err_sum=('signed_error','sum'),count=('abs_error','size'))
    ae=g.ae_sum.to_numpy();signed=g.err_sum.to_numpy();counts=g['count'].to_numpy();n=len(g)
    rng=np.random.default_rng(seed);mae=np.empty(replicates);bias=np.empty(replicates)
    for j in range(replicates):
        idx=rng.integers(0,n,n)
        denom=counts[idx].sum()
        mae[j]=ae[idx].sum()/denom
        bias[j]=signed[idx].sum()/denom
    return {'n_property_clusters':n,'MAE_CI95_lo':float(np.quantile(mae,.025)),
          'MAE_CI95_hi':float(np.quantile(mae,.975)),
          'bias_CI95_lo':float(np.quantile(bias,.025)),
          'bias_CI95_hi':float(np.quantile(bias,.975))}


def group_audits(joined,min_n=100,reps=250):
    columns=['price_band','property_type_group','flood_plain_group','flood_sensitive_group','noise_group','spatial_grid','sale_month_group','fold']
    records=[];excluded=[]
    for col in columns:
        if col not in joined:continue
        for group,part in joined.groupby(col,observed=True,dropna=False,sort=True):
            if len(part)<min_n:
                excluded.append({'dimension':col,'group':str(group),'n':len(part)})
                continue
            summary={'dimension':col,'group':str(group),**score(part),**cluster_bootstrap(part,replicates=reps,seed=760)}
            records.append(summary)
    return pd.DataFrame(records),pd.DataFrame(excluded)


def predicted_deciles(joined):
    d=joined.copy()
    # All windows pooled: descriptive reliability/calibration only (not a deployable threshold).
    d['predicted_decile']=pd.qcut(d.prediction.rank(method='first'),q=10,labels=False)+1
    result=[]
    for decile,part in d.groupby('predicted_decile'):
        s=score(part)
        result.append({'predicted_decile':int(decile),**s})
    return pd.DataFrame(result)


def validation_only_bias_adjustment(joined):
    """Fit optional companion-only correction on earlier OOF folds 1-3;
    evaluate chronologically on folds 4-5. NEVER alter team original XGBoost.
    Fix 0.5 shrinkage before observing test folds; predicted-decile bins are
    fitted from earlier scores, NOT actual outcome price bands.
    """
    train=joined[joined.fold<=3].copy();test=joined[joined.fold>=4].copy()
    if len(train)<300 or len(test)<100:return None,None
    boundary=np.quantile(train.prediction,np.arange(0.1,1.0,.1))
    labels=np.arange(10)
    trainbin=np.searchsorted(boundary,train.prediction.to_numpy(),side='right')
    testbin=np.searchsorted(boundary,test.prediction.to_numpy(),side='right')
    correction=pd.Series(train.signed_error.to_numpy()).groupby(trainbin).mean().reindex(labels).fillna(0)
    proposed=test.prediction.to_numpy()-0.5*correction.reindex(testbin).to_numpy()
    adjusted=test.copy();adjusted['prediction']=proposed
    adjusted['signed_error']=adjusted.prediction-adjusted.actual
    adjusted['abs_error']=adjusted.signed_error.abs()
    adjusted['abs_pct_error']=adjusted.abs_error/adjusted.actual*100
    adjusted['overpredicted']=(adjusted.signed_error>0).astype(int)
    return pd.DataFrame([{'variant':'Unmodified companion','heldout_folds':'4–5',**score(test)},
                         {'variant':'Validation-fitted diagnostic adjustment','heldout_folds':'4–5',**score(adjusted)}]),adjusted
