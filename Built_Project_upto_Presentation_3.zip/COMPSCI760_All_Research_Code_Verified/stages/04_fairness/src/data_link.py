"""Read-only transaction-to-row_id mapping consistent with team notebook cell 43.

Does not fit, modify, export, or invoke XGBoost. The audit refuses to join any
prediction whose row ID and realised sale-price label do not match.
"""
import hashlib
from pathlib import Path
import numpy as np
import pandas as pd
from parquet_readonly import read_parquet

DATA_SHA='07e5e22ea8c6f73b82477b023f5803961b7ba730f9a7474cbb55a27a2c0fb3b2'
TEAM_SHA='21d388340231d149109195ca0498533de28b33e692c73e6a965ce6a6c62d7057'


def sha(path):
    digest=hashlib.sha256()
    with open(path,'rb') as stream:
        for chunk in iter(lambda:stream.read(1<<20),b''):digest.update(chunk)
    return digest.hexdigest()


def read_source(dataset,notebook):
    if sha(dataset)!=DATA_SHA:raise ValueError('Source dataset SHA-256 differs from frozen team baseline')
    if sha(notebook)!=TEAM_SHA:raise ValueError('Original teammate XGBoost notebook fingerprint differs')
    try:return pd.read_parquet(dataset)
    except ImportError:return read_parquet(dataset)


def date_parser(s):
    # Teammate's original date-parser behaviour for comparison-row identity.
    if pd.isna(s):return pd.NaT
    s=str(s)
    return pd.Timestamp(year=int(s[-4:]),month=int(s[-6:-4]),day=int(s[:-6]))


def make_context(raw):
    d=raw.drop(columns=['__index_level_0__'],errors='ignore').copy()
    d['sale_date_parsed']=d.sale_date.apply(date_parser)
    masks=[
        d['zoning'].astype(str).str[0].isin(['9','1','2']),
        pd.to_numeric(d.units_of_use,errors='coerce').eq(1),
        d.sale_tenure.astype(str).eq('1'),
        d.sale_type.eq('S'),
        d.price_value_relationship.eq('1'),
        d.linz_matched.astype(bool)]
    for cond in masks:d=d.loc[cond].copy()
    d=d.sort_values('sale_date_parsed').reset_index(drop=True)
    if len(d)!=59798:raise ValueError(f'Expected original team cohort 59798; found {len(d)}')
    d['row_id']=np.arange(len(d),dtype=int)
    d['property_type']=d.property_category.astype('string').str[0]
    # Avoid missing-mapping-as-negative classification.
    flood=pd.Series('unknown',index=d.index)
    present=d.in_flood_plain.notna()
    flood.loc[present & d.in_flood_plain.astype('boolean').fillna(False)]='inside_flood_plain'
    flood.loc[present & ~d.in_flood_plain.astype('boolean').fillna(False)]='outside_flood_plain'
    d['flood_plain_group']=flood
    sensitive=d.in_flood_sensitive_area.astype('boolean')
    d['flood_sensitive_group']=np.where(sensitive.isna(),'unknown',np.where(sensitive.fillna(False),'inside_sensitive_area','outside_sensitive_area'))
    noise=d.noise_category_combination.astype('string')
    d['noise_group']=np.where(noise.isna(),'unknown',np.where(noise.eq('outside_current_overlay').fillna(False),'outside_overlay','inside_overlay'))
    lat=pd.to_numeric(d.latitude,errors='coerce');lon=pd.to_numeric(d.longitude,errors='coerce')
    resolution=.035
    key=(np.floor(lat/resolution).astype('Int64').astype('string')+'_'+np.floor(lon/resolution).astype('Int64').astype('string'))
    d['spatial_grid']=key.fillna('unlocated')
    d['property_type_group']=d.property_type.where(d.property_type.isin(['R','L']),'Other').fillna('Other')
    d['sale_month_group']=d.sale_date_parsed.dt.strftime('%Y-%m')
    d['property_key']=d.valuation_id_concat.astype('string').fillna('') if 'valuation_id_concat' in d.columns else d.row_id.astype(str)
    required=['row_id','sale_price_gross','property_key','property_type_group','flood_plain_group',
      'flood_sensitive_group','noise_group','spatial_grid','sale_month_group','sale_date_parsed']
    return d[required].copy()
