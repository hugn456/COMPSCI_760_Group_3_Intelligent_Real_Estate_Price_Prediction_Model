"""Write source-faithful RQ4 report from independently verified aggregate tables."""
import json
from pathlib import Path
import pandas as pd

def fmt(v):return ('-' if v < 0 else '') + '${:,.0f}'.format(abs(v))

def produce(out='results'):
    root=Path(out)
    rf=pd.read_csv(root/'Companion_RandomForest_subgroup_metrics.csv')
    lg=pd.read_csv(root/'Companion_LightGBM_subgroup_metrics.csv')
    ref=json.loads((root/'team_original_reported_findings.json').read_text())
    m=json.loads((root/'experiment_manifest.json').read_text())
    pp=lambda d:d.query('dimension=="price_band"').set_index('group')
    a=pp(rf);b=pp(lg)
    groups=['<750k','750k–1m','1m–1.5m','1.5m–2m','>=2m']
    lines=[]
    add=lines.append
    add('# COMPSCI 760 — Stage 4: Fairness and Subgroup Predictive Reliability')
    add('\n**Status:** Companion-model audit complete on real data. **Original team XGBoost full subgroup audit is pending its original per-sale out-of-fold export.** The original teammate notebook and reported metrics are immutable throughout this work.\n')
    add('## 1. Research question and correct interpretation')
    add('**RQ4:** Do property-price prediction errors differ across sale-price bands, property types, geographical areas and hazard-mapping categories; can differences be reduced without substantial deterioration of overall prediction accuracy?')
    add('\nThis is a **post-hoc model reliability audit for a continuous-valued regression task**. We do not observe verified protected demographics and therefore **do not claim to establish discrimination or demographic parity**. Classification fairness criteria in COMPSCI 760 Lectures 01–05 are useful motivations but do not transfer automatically to house-price regression. In particular, a group with higher MAE is not thereby proved to have been discriminated against.\n')
    add('## 2. Original teammate XGBoost evidence — unchanged')
    add('Source: **Group mate Reports.pdf, page 11**, “6. Results: Errors across price ranges.” The following are *quoted source findings*, not derived from our RF/LightGBM predictions:')
    add(f"\n- Among **{ref['original_report_group_under_750k_n']:,} sales below NZ$750,000**, the original XGBoost produced an **average overestimate of approximately {fmt(ref['original_report_group_under_750k_mean_overprediction_NZD'])}**.")
    add(f"- Among **{ref['original_report_group_at_least_2m_n']:,} sales at or above NZ$2 million**, the model's MAE was approximately **{fmt(ref['original_report_group_at_least_2m_mae_NZD'])}**, with **{ref['original_report_group_at_least_2m_underprediction_pct']:.1f}% underestimated**.")
    add(f"- The notebook's overall **{ref['original_xgb_n_oof']:,}** screened out-of-fold sales produced a reported augmented-model MAE of **{fmt(ref['original_teammate_xgboost_MAE'])}** and RMSE **{fmt(ref['original_teammate_xgboost_RMSE'])}** (source: team report page 6).")
    add('\n**Boundary:** The notebook retains the OOF predictions as a variable in the executed kernel but does not provide a downloadable row-level OOF export. We cannot compute additional XGBoost subgroup confidence intervals, flood-group errors, calibration plots or intervention results from its original **aggregate** outputs alone. The companion results below must not be represented as original-XGBoost metrics.\n')
    add('## 3. Independent companion-model audit — actual shared dataset')
    add('Our independently developed Random Forest and LightGBM are evaluated on the same 48,848 response-price-screened sales, with the same teammate-inspired five TimeSeriesSplit folds, and the shared SHA-256-verified Parquet dataset. We joined saved out-of-fold predictions to sale-price and grouping attributes with strict row-ID and exact actual-price checks. No XGBoost predictions were synthesized or refitted.\n')
    add('| Model | MAE (NZD) | RMSE (NZD) | Mean signed error | Overpredicted |')
    add('|---|---:|---:|---:|---:|')
    for title,model in [('Random Forest','Companion_RandomForest'),('LightGBM','Companion_LightGBM')]:
        o=m['computed_models'][model]['overall']
        add(f"| {title} | {fmt(o['MAE_NZD'])} | {fmt(o['RMSE_NZD'])} | {fmt(o['signed_bias_NZD'])} | {o['overprediction_pct']:.1f}% |")
    add('\nMean signed error is defined as prediction minus actual price; **positive** means overestimation, **negative** means underestimation. The MAE records average absolute NZD error, and median APE provides a scale-normalised error summary.\n')
    add('### Sale-price bands — errors are not homogeneous')
    add('| Actual sale-price range | Sales | RF MAE | LightGBM MAE | RF signed error | LightGBM signed error |')
    add('|---|---:|---:|---:|---:|---:|')
    for g in groups:
        x=a.loc[g];y=b.loc[g]
        add(f"| {g} | {int(x.n):,} | {fmt(x.MAE_NZD)} | {fmt(y.MAE_NZD)} | {fmt(x.signed_bias_NZD)} | {fmt(y.signed_bias_NZD)} |")
    add('\nBoth models overestimate cheaper homes on average and underestimate expensive ones. This resembles **regression toward the center**. We must distinguish actual-price groups (valid for *auditing*) from prediction-time features: a deployed system would not know the property\'s true sale-price band in advance. MAE gaps also partly reflect the larger monetary scale of higher-priced homes.\n')
    add('![Model MAE by actual sale-price group](fig01_companion_price_band_mae.png)\n')
    add('![Direction and magnitude of error](fig02_companion_price_band_signed_bias.png)\n')
    add('### Location and hazard mapping')
    add('The companion models were audited separately for **inside/outside flood plain, inside/outside flood-sensitive area, mapped noise overlay, property category, and 0.035-degree spatial grid**. For instance, LightGBM MAE was **'+fmt(float(lg.query('dimension=="flood_plain_group" and group=="inside_flood_plain"').MAE_NZD.iloc[0]))+'** inside mapped flood plains (n=3,162) and **'+fmt(float(lg.query('dimension=="flood_plain_group" and group=="outside_flood_plain"').MAE_NZD.iloc[0]))+'** outside them (n=45,686). Lower group-level MAE in a hazard area should **not** be interpreted as evidence that flood risk improves accuracy: the properties, price distributions, sample sizes and locations differ.\n')
    add('There were no unknown flood-layer flags within this particular LINZ-matched cohort; the code nevertheless retains an explicit `unknown` classification if future input data have missing mapping. The group sizes are markedly imbalanced.\n')
    add('![Relative error by property, flood and noise groups](fig03_lgbm_group_relative_error.png)\n')
    add('### Calibration and chronological stability')
    add('For each companion model, out-of-fold predictions were sorted into ten approximately equally populated *predicted-price* deciles. The accompanying diagnostic plots the mean prediction versus mean sale price and measures signed bias. This is regression reliability/calibration, **not** classification sufficiency or demographic calibration.\n')
    add('![Observed mean price versus predicted mean price](fig04_companion_calibration_deciles.png)\n')
    add('The five-fold MAE with uncertainty intervals shows how absolute error varied as the historical training period expanded. Intervals were obtained by property-key-cluster resampling and therefore account imperfectly for repeated transactions at a property, not for all spatial/temporal dependence.\n')
    add('![MAE over folds](fig05_companion_fold_reliability.png)\n')
    add('### Reliability intervention — companion LightGBM only')
    d=pd.read_csv(root/'Companion_LightGBM_exploratory_postprocessing.csv')
    old=d.iloc[0];new=d.iloc[1]
    add(f'Using folds 1–3 as *earlier calibration examples*, we fitted prediction-decile bias corrections and applied a fixed 50% shrinkage to folds 4–5 **without retraining the LightGBM model**. Later-fold MAE changed from **{fmt(old.MAE_NZD)} to {fmt(new.MAE_NZD)}** (difference {fmt(old.MAE_NZD-new.MAE_NZD)}), while average signed error changed from **{fmt(old.signed_bias_NZD)} to {fmt(new.signed_bias_NZD)}**. This is an **exploratory post-processing pilot on LightGBM**, not a tested improvement to the team\'s XGBoost. The 50% shrinkage was predefined and did not use later-fold sale prices in fitting.')
    add('\n![LightGBM-only post-processing pilot](fig06_exploratory_lgbm_calibration_pilot.png)\n')
    add('## 4. Uncertainty estimation, limitations and reproducibility')
    add('For each published subgroup containing **at least 100 sales**, our independently calculated MAE and mean signed error were accompanied by 95% **property-cluster bootstrap** intervals (250 replicates, fixed seed). Subgroups smaller than 100 sales are suppressed from shared output tables. These are exploratory confidence intervals, not formal multiple-comparison-adjusted significance tests. True-sale-price groups can also induce mathematical regression-to-the-mean patterns, and raw group gaps may reflect differences in property composition rather than model failure alone.\n')
    add('The notebook\'s primary evaluation uses train-fold-derived 1st–99th percentile cutoffs on test *sale prices*, so the 48,848-row results exclude selected low/high tails. Results are specific to that screened population and may not describe every future transaction. Its original folds are row-based, potentially sharing sale dates across boundaries. We document these limitations without modifying the original experiment.\n')
    add('We preserve the original dataset and notebook SHA-256 identities, do not release individual predictions or Council property records in the ZIP, and do not change the original teammate model.\n')
    add('## 5. What is needed to complete the original XGBoost audit')
    add('Please request **the already-computed `oof` variable from the original notebook** as a private CSV with columns `row_id, fold, actual, augmented_pred`. Exporting this table from the teammate\'s original notebook session requires **no retraining or notebook changes**. Our standalone `run_stage04.py --source team --team-oof ...` then uses the untouched predictions to calculate exactly the same group statistics, calibration diagnostics and clustered confidence intervals, and rejects exports whose overall MAE differs from the team\'s saved figure. Keep CSVs private under the Council agreement.\n')
    add('## 6. Conclusion for RQ4')
    add('Your teammates\' original XGBoost already provides evidence of a **low-price overprediction / high-price underprediction** pattern. Independent LightGBM and Random Forest subgroup analyses show a similar directional pattern and provide detailed baseline reliability diagnostics. However, full claims about the original XGBoost\'s group calibration, flood-area reliability or intervention outcomes **must remain pending** until its original per-sale predictions are supplied. The current evidence documents regression subgroup error disparities, not demographic unfairness or causality.\n')
    add('**Source documents:** `Group mate Reports.pdf`, pp. 6, 11, 14; `XGBoost.ipynb`, cells 43, 45, 47; `Lecture 01 - Fairness in Machine Learning.pdf`; `Lecture 05 - Fairness in Machine Learning Observational Criteria.pdf`.\n')
    path=root/'STAGE04_RESEARCH_REPORT.md';path.write_text('\n'.join(lines),encoding='utf8')
    print('wrote',path,len(lines),'sections',path.stat().st_size,'bytes')

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--out',default='results');a=p.parse_args();produce(a.out)
