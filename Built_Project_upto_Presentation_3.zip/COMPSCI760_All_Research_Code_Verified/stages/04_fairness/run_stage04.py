"""Separate Stage4 reliability audit. Team XGBoost is always immutable/read-only.

Usages:
 --source companion : use existing separately trained RF and LightGBM private OOF.
 --source team      : team must supply original oof export; NO substitute.

Only aggregate anonymized outputs are written in results/.
"""
from pathlib import Path
import argparse,json,sys
import pandas as pd
sys.path.insert(0,str(Path(__file__).resolve().parent/'src'))
from data_link import read_source,make_context,sha,DATA_SHA,TEAM_SHA
from fairness_core import attach_context,group_audits,predicted_deciles,score,validation_only_bias_adjustment

REFERENCE={
    'teammate_source':'Group mate Reports.pdf, page 11; results retained verbatim, not rerun',
    'original_teammate_xgboost_MAE':131243.38,
    'original_teammate_xgboost_RMSE':214529.56,
    'original_xgb_n_oof':48848,
    'original_report_group_under_750k_n':9443,
    'original_report_group_under_750k_mean_overprediction_NZD':70700,
    'original_report_group_at_least_2m_n':3458,
    'original_report_group_at_least_2m_mae_NZD':401100,
    'original_report_group_at_least_2m_underprediction_pct':72.5
}


def team_export(path):
    p=pd.read_csv(path)
    if set(['row_id','fold','actual','augmented_pred']).issubset(p.columns):
        return p[['row_id','fold','actual','augmented_pred']].rename(columns={'augmented_pred':'prediction'})
    if set(['row_id','fold','actual','prediction']).issubset(p.columns):
        return p[['row_id','fold','actual','prediction']]
    raise ValueError('Original team OOF CSV must have row_id,fold,actual,augmented_pred or prediction')


def companion_file(path,model,feature):
    p=pd.read_csv(path)
    if not {'model','feature_set','row_id','fold','actual','prediction'}.issubset(p.columns):
        raise ValueError('Companion prediction file schema not supported')
    p=p[(p.model==model)&(p.feature_set==feature)].copy()
    if len(p)!=48848:raise ValueError(f'Expected 48,848 companion OOF predictions for {model}, got {len(p)}')
    return p[['row_id','fold','actual','prediction']]


def one_run(p,context,label,out,min_n=100,reps=250,intervention=False):
    merged=attach_context(p,context,strict_original=True)
    groups,suppressed=group_audits(merged,min_n=min_n,reps=reps)
    calibration=predicted_deciles(merged)
    # Original 5-fold overall MAE from user-provided predictions is only claimed
    # when user actually supplied the team's export; not inferred from reported metrics.
    overview={'model_name':label,'overall':score(merged),'groups_count':len(groups),
       'suppressed_group_count':len(suppressed),
       'suppression_threshold':min_n,'confidence_intervals':'Property-cluster bootstrap, 95%'}
    groups.insert(0,'source_model',label)
    calibration.insert(0,'source_model',label)
    groups.to_csv(out/f'{label}_subgroup_metrics.csv',index=False)
    calibration.to_csv(out/f'{label}_predicted_decile_calibration.csv',index=False)
    # withheld groups only saved as aggregate suppression count; don't release their identifiers.
    if intervention:
        adjusted,_=validation_only_bias_adjustment(merged)
        if adjusted is not None:adjusted.to_csv(out/f'{label}_exploratory_postprocessing.csv',index=False)
    return overview,groups,calibration


def run(dataset,notebook,source,out,team_oof=None,rf_oof=None,lgbm_oof=None,reps=250):
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    if not Path(dataset).exists() or not Path(notebook).exists():raise FileNotFoundError('Original sources required for fingerprint verification')
    raw=read_source(dataset,notebook)
    context=make_context(raw)
    (out/'team_original_reported_findings.json').write_text(json.dumps(REFERENCE,indent=2))
    record={'teammate_original_notebook_unmodified':True,'notebook_sha256':TEAM_SHA,
            'dataset_sha256':DATA_SHA,'cohort':int(len(context)),
            'original_team_reference':'Directly from teammates PDF (not our computation)',
            'team_oof_provided':source=='team'}
    output={}; tables={}
    if source=='team':
        if not team_oof:raise ValueError('Original team XGBoost row-level OOF CSV REQUIRED. No replay or surrogate permitted.')
        oof=team_export(team_oof)
        if len(oof)!=REFERENCE['original_xgb_n_oof'] or abs(float((oof.actual-oof.prediction).abs().mean())-REFERENCE['original_teammate_xgboost_MAE'])>5:
            raise ValueError('Original teammate export does not reproduce 48,848 observations and NZ$131,243.38 MAE. No subgroup outputs written.')
        output['Original_team_XGBoost'],g,c=one_run(oof,context,'Original_team_XGBoost',out,reps=reps)
        tables['Original_team_XGBoost']=(g,c)
        # An exact-original replication claim requires original score check.
        mae=output['Original_team_XGBoost']['overall']['MAE_NZD']
        if abs(mae-REFERENCE['original_teammate_xgboost_MAE'])>5:
            raise ValueError(f'Team prediction export MAE {mae:,.2f} fails to reproduce original saved MAE 131,243.38. Remove invalid exports/results.')
    elif source=='companion':
        if not rf_oof or not lgbm_oof:raise ValueError('Companion RF and LightGBM files required')
        for name,data_path,original_name in [('Companion_RandomForest',rf_oof,'Random Forest'),('Companion_LightGBM',lgbm_oof,'LightGBM')]:
            oof=companion_file(data_path,original_name,'P+E')
            output[name],g,c=one_run(oof,context,name,out,reps=reps,intervention=(original_name=='LightGBM'))
            tables[name]=(g,c)
    else:raise ValueError('Expected team or companion')
    record['computed_models']=output
    (out/'experiment_manifest.json').write_text(json.dumps(record,indent=2,default=str))
    print(json.dumps({'mode':source,'models':{k:v['overall'] for k,v in output.items()},'outputs':str(out)},indent=2))
    return record,tables


def cli():
    p=argparse.ArgumentParser()
    p.add_argument('--dataset',required=True);p.add_argument('--notebook',required=True)
    p.add_argument('--source',choices=['team','companion'],required=True)
    p.add_argument('--team-oof');p.add_argument('--rf-oof');p.add_argument('--lgbm-oof')
    p.add_argument('--out',default='results');p.add_argument('--reps',type=int,default=250)
    a=p.parse_args()
    run(a.dataset,a.notebook,a.source,a.out,a.team_oof,a.rf_oof,a.lgbm_oof,a.reps)

if __name__=='__main__':cli()
