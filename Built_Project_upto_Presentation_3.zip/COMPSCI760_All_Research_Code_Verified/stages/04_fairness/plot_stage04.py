"""Publication-style aggregate charts; no private property rows needed."""
from pathlib import Path
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

BANDS=['<750k','750k–1m','1m–1.5m','1.5m–2m','>=2m']


def render(out):
    root=Path(out);root.mkdir(parents=True,exist_ok=True)
    rf=pd.read_csv(root/'Companion_RandomForest_subgroup_metrics.csv')
    lg=pd.read_csv(root/'Companion_LightGBM_subgroup_metrics.csv')
    models={'Random Forest':rf,'LightGBM':lg}
    def save(name):
        plt.tight_layout()
        plt.savefig(root/name,dpi=170,bbox_inches='tight')
        plt.close()
    # 1: MAE by actual-sale-price range
    fig,ax=plt.subplots(figsize=(10.2,5.5))
    pos=np.arange(len(BANDS));w=.35
    for j,(label,d) in enumerate(models.items()):
        sub=d.query('dimension=="price_band"').set_index('group').reindex(BANDS)
        ax.bar(pos+(j-.5)*w,sub.MAE_NZD/1000,w,label=label)
    ax.set_xticks(pos,BANDS)
    ax.set_ylabel('MAE (NZD thousands)')
    ax.set_xlabel('Actual sale price (evaluation-only group)')
    ax.set_title('Model error increases sharply at the upper price range')
    ax.legend(loc='upper left')
    ax.grid(axis='y',alpha=.25)
    save('fig01_companion_price_band_mae.png')

    # 2: direction of prediction error
    fig,ax=plt.subplots(figsize=(10.2,5.5))
    for j,(label,d) in enumerate(models.items()):
        sub=d.query('dimension=="price_band"').set_index('group').reindex(BANDS)
        ax.bar(pos+(j-.5)*w,sub.signed_bias_NZD/1000,w,label=label)
    ax.axhline(0,color='black',linewidth=.8)
    ax.set_xticks(pos,BANDS)
    ax.set_ylabel('Average prediction minus sale price (NZD thousands)')
    ax.set_xlabel('Actual sale price (evaluation-only group)')
    ax.set_title('Positive = overestimation; negative = underestimation')
    ax.legend()
    ax.grid(axis='y',alpha=.25)
    save('fig02_companion_price_band_signed_bias.png')

    # 3: subgroup relative error flood, noise & property type on LightGBM
    columns=['flood_plain_group','noise_group','property_type_group']
    fig,axs=plt.subplots(1,3,figsize=(15.5,4.8))
    for ax,dim,title in zip(axs,columns,['Flood-plain mapping','Noise-overlay mapping','Property type']):
        d=lg.query('dimension==@dim').sort_values('median_APE_pct')
        ax.barh(d.group.str.replace('_',' ',regex=False),d.median_APE_pct)
        ax.set_title(title)
        ax.set_xlabel('Median APE (%)')
        ax.grid(axis='x',alpha=.2)
    fig.suptitle('Relative prediction reliability: independent LightGBM',fontsize=13)
    save('fig03_lgbm_group_relative_error.png')

    # 4: empirical calibration by predicted-price decile
    fig,ax=plt.subplots(figsize=(7.3,6))
    maxv=0
    for model in ['Companion_RandomForest','Companion_LightGBM']:
        d=pd.read_csv(root/f'{model}_predicted_decile_calibration.csv')
        ax.plot(d.mean_predicted_NZD/1e6,d.mean_actual_NZD/1e6,marker='o',label=model.replace('Companion_',''))
        maxv=max(maxv,d.mean_predicted_NZD.max(),d.mean_actual_NZD.max())
    ax.plot([0,maxv/1e6],[0,maxv/1e6],linestyle='--',color='black',alpha=.7,label='Perfect mean calibration')
    ax.set_xlim(.4,2.5);ax.set_ylim(.4,2.5)
    ax.set_xlabel('Mean predicted price in predicted-price decile (NZD millions)')
    ax.set_ylabel('Mean actual sale price (NZD millions)')
    ax.set_title('Aggregate regression calibration by predicted price')
    ax.legend(fontsize=9)
    ax.grid(alpha=.2)
    save('fig04_companion_calibration_deciles.png')

    # 5: fold evolution and uncertainty
    fig,ax=plt.subplots(figsize=(8.8,5))
    for label,d in models.items():
        x=d.query('dimension=="fold"').sort_values('group')
        xs=x.group.astype(int)
        ax.errorbar(xs,x.MAE_NZD/1000,
            yerr=[(x.MAE_NZD-x.MAE_CI95_lo)/1000,(x.MAE_CI95_hi-x.MAE_NZD)/1000],
            marker='o',capsize=3,label=label)
    ax.set_xticks(range(1,6))
    ax.set_xlabel('Teammate chronological fold number')
    ax.set_ylabel('MAE (NZD thousands; 95% cluster-bootstrap CI)')
    ax.set_title('Reliability across five chronological folds')
    ax.legend()
    ax.grid(alpha=.2)
    save('fig05_companion_fold_reliability.png')

    # 6: optional companion-only late-fold diagnostic
    d=pd.read_csv(root/'Companion_LightGBM_exploratory_postprocessing.csv')
    fig,ax=plt.subplots(figsize=(7.6,4.4))
    labels=['Unmodified LightGBM','Validation-calibrated diagnostic']
    bars=ax.bar(labels,d.MAE_NZD/1000)
    for bar,value in zip(bars,d.MAE_NZD):
        ax.text(bar.get_x()+bar.get_width()/2,bar.get_height()+1.2,f'${value:,.0f}',ha='center',fontsize=10)
    ax.set_ylim(0,max(d.MAE_NZD)/1000*1.2)
    ax.set_title('LightGBM post-processing pilot: folds 4–5 only')
    ax.set_ylabel('MAE (NZD thousands)')
    ax.grid(axis='y',alpha=.2)
    save('fig06_exploratory_lgbm_calibration_pilot.png')

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--out',default='results');a=p.parse_args()
    render(a.out)
