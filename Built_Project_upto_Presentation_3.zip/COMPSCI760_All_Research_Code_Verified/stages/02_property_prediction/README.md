# Stage 2 — Property Price Prediction

Compares the fixed, source-reported XGBoost results with separate LightGBM, Random Forest, CatBoost, HistGradientBoosting, Ridge, Extra Trees and median-baseline experiments. Uses chronological folds and the recorded price-screened evaluation.

**Primary outputs:** `results/all_models_augmented_comparison.csv`, fold-level and feature-ablation tables, aggregate figures.

**Run:** `python project.py run 2 --dataset PATH --notebook PATH` reproduces the Random Forest and baseline portion, storing new files privately under `local_runs/`. Pass `--extended` to additionally fit the LightGBM, CatBoost, histogram boosting, scaled Ridge and larger Random Forest benchmarks; this may take substantial time.

**Interpretation:** Original XGBoost MAE NZ$131,243; LightGBM MAE NZ$133,294. No paired significance is claimed without original XGBoost transaction-level predictions.

Reproduction details and project-wide safeguards are in the repository-level `README.md`.
