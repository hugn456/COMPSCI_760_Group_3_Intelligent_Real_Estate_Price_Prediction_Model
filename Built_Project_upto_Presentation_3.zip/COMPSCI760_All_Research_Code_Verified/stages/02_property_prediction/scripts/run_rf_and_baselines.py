"""Stage 02 companion: Random Forest & other baselines, no edits to XGBoost.ipynb.

Reuses teammates' stated notebook cohort, preprocessing, chronological TimeSeriesSplit
(n_splits=5), 1st–99th percentile train-derived price trimming, and evaluation rows.

The official XGBoost metrics are extracted from source notebook (unaltered).
Our other models run separately on exact notebook-style matrices, are NOT patched into
or promoted over the teammates' original XGB model.
"""
from __future__ import annotations
import argparse,hashlib,json,time, warnings
from pathlib import Path
import pandas as pd
import numpy as np
from sklearn.model_selection import TimeSeriesSplit
from sklearn.preprocessing import OrdinalEncoder
from sklearn.ensemble import RandomForestRegressor,ExtraTreesRegressor, HistGradientBoostingRegressor
from sklearn.dummy import DummyRegressor
from sklearn.metrics import mean_absolute_error,mean_squared_error,r2_score
from sklearn.linear_model import Ridge

# Original lists, copied verbatim from teammates notebook cell 45 into companion code.
BASELINE_CAT = ['zoning','building_age_indicator','building_condition_indicator',
    'building_construction_indicator','mass_contour','mass_view','mass_scope_of_view',
    'mass_deck','mass_workshop_laundry','mass_other_improvements',
    'property_type','actual_property_use']
BASELINE_NUM = ['land_area','building_total_floor_area','mass_total_floor_area',
    'building_site_coverage','off_street_parking', 'mass_garage_under_main_roof',
    'mass_garage_freestanding','sale_year','sale_month','sale_quarter']
EXTERNAL_CAT = ['unitary_plan_zone','noise_category_combination']
EXTERNAL_NUM = ['longitude','latitude','dist_to_flood_plain_m',
    'dist_to_flood_sensitive_area_m','sa2_new_dwellings_consented_12m',
    'walk_supermarket_network_m','walk_bus_stop_network_m']
EXTERNAL_BOOL = ['in_flood_plain','in_flood_sensitive_area','has_flood_risk','in_noise_overlay']
LOG_COLS=['land_area','building_total_floor_area','mass_total_floor_area',
    'walk_supermarket_network_m','walk_bus_stop_network_m']
ALL_CAT=BASELINE_CAT+EXTERNAL_CAT
ALL_NUM=BASELINE_NUM+EXTERNAL_NUM
BASELINE=BASELINE_CAT+BASELINE_NUM
AUGMENTED=BASELINE+EXTERNAL_CAT+EXTERNAL_NUM+EXTERNAL_BOOL
NOTEBOOK_SHA='21d388340231d149109195ca0498533de28b33e692c73e6a965ce6a6c62d7057'
DATA_SHA='07e5e22ea8c6f73b82477b023f5803961b7ba730f9a7474cbb55a27a2c0fb3b2'
TEAM_RESULTS={'XGBoost (teammate original)':{
    'P':{'MAE':208318.50,'RMSE':317631.16,'MAPE_pct':18.17},
    'P+E':{'MAE':131243.38,'RMSE':214529.56,'MAPE_pct':11.31}}}

def sha256(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for chunk in iter(lambda:f.read(1<<20),b''):h.update(chunk)
    return h.hexdigest()

def date_parser(s):
    # Deliberately identical to teammate's cell 10, rather than 'corrected'.
    if pd.isna(s):return pd.NaT
    s=str(s);year=int(s[-4:]);month=int(s[-6:-4]);day=int(s[:-6])
    return pd.Timestamp(year=year,month=month,day=day)

def prepare(df):
    """Notebook cells 4, 10, 39, 43, 45: same method, no change to original file."""
    df=df.drop(columns=['__index_level_0__'],errors='ignore').copy()
    df=df.drop(columns=['sale_price_net','sale_price_chattels','sale_price_other',
                        'capital_value','land_value'])
    df['sale_date_parsed']=df.sale_date.apply(date_parser)
    for c in ['sale_price_gross','land_area','building_total_floor_area',
              'mass_total_floor_area','building_site_coverage','off_street_parking',
              'units_of_use','mass_garage_under_main_roof','mass_garage_freestanding',
              'longitude','latitude']:
        df[c]=pd.to_numeric(df[c],errors='coerce')
    for c in ['walk_supermarket_network_m','drive_supermarket_network_m',
              'walk_bus_stop_network_m','drive_bus_stop_network_m',
              'sa2_new_dwellings_consented_12m']:
        df[c]=df[c].astype(float)
    for c in ['in_flood_plain','in_flood_sensitive_area']:
        df[c]=df[c].astype('boolean')
    df=df.drop(columns=['drive_supermarket_network_m','drive_bus_stop_network_m'])
    counts={'source_rows':len(df)}
    filters=[
     ('zoning_912',df['zoning'].astype(str).str[0].isin(['9','1','2'])),
     ('one_unit',df['units_of_use']==1),
     ('freehold',df['sale_tenure'].astype(str)=='1'),
     ('sale_type_S',df['sale_type']=='S'),
     ('relationship_1',df['price_value_relationship']=='1'),
     ('linz_matched',df['linz_matched'].astype(bool)),
    ]
    for name,mask in filters:
        df=df.loc[mask].copy()
        counts[name]=len(df)
    # Preserve notebook ordering algorithm: default pandas sort kind, no sorting revision.
    df=df.sort_values('sale_date_parsed').reset_index(drop=True)
    df['property_type']=df['property_category'].str[0]
    df['sale_year']=df.sale_date_parsed.dt.year
    df['sale_month']=df.sale_date_parsed.dt.month
    df['sale_quarter']=df.sale_date_parsed.dt.quarter
    df['has_flood_risk']=df['in_flood_plain'] | df['in_flood_sensitive_area']
    df['in_noise_overlay']=df['noise_category_combination']!='outside_current_overlay'
    df['unitary_plan_zone']=df['unitary_plan_zone'].fillna(-1).astype(int).astype(str)
    for c in ALL_CAT:df[c]=df[c].fillna('Unknown').astype(str)
    for c in LOG_COLS:df[c]=np.log1p(df[c])
    assert len(df)==59798, f'Team filtered rows 59,798, got {len(df)}. STOP — cohort mismatch.'
    assert len(BASELINE)==22 and len(AUGMENTED)==35
    assert 'capital_value' not in df.columns and 'land_value' not in df.columns
    assert df['has_flood_risk'].notna().all()
    return df,counts

def metrics(y,p):
    y=np.asarray(y,dtype=float);p=np.asarray(p,dtype=float)
    e=y-p
    return dict(MAE=float(np.mean(abs(e))),RMSE=float(np.sqrt(np.mean(e**2))),
                MAPE_pct=float(np.mean(abs(e)/y)*100),R2=float(r2_score(y,p)))

def models(name,seed=42):
    if name=='Random Forest':
        return RandomForestRegressor(n_estimators=120,max_depth=14,min_samples_leaf=5,
                      max_features=1.0,random_state=seed,n_jobs=2)
    if name=='Extra Trees':
        return ExtraTreesRegressor(n_estimators=120,max_depth=14,min_samples_leaf=5,
                      max_features=1.0,random_state=seed,n_jobs=2)
    if name=='Median baseline':return DummyRegressor(strategy='median')
    raise KeyError(name)

def run(df,model_names=('Random Forest','Extra Trees','Median baseline'),
        out='results_rf'):
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    eligible,cohort=prepare(df)
    groups={'P':BASELINE,'P+E':AUGMENTED}
    results=[]; predictions=[];fold_summary=[]
    names=list(model_names)
    for k,(train_idx,test_idx) in enumerate(TimeSeriesSplit(n_splits=5).split(eligible),1):
        train=eligible.iloc[train_idx];test=eligible.iloc[test_idx]
        enc=OrdinalEncoder(handle_unknown='use_encoded_value',unknown_value=-1)
        enc.fit(train[ALL_CAT])
        Xtr=train[AUGMENTED].copy();Xte=test[AUGMENTED].copy()
        Xtr[ALL_CAT]=enc.transform(train[ALL_CAT]);Xte[ALL_CAT]=enc.transform(test[ALL_CAT])
        for c in EXTERNAL_BOOL:
            Xtr[c]=Xtr[c].astype(int);Xte[c]=Xte[c].astype(int)
        Xtr=Xtr.astype(float);Xte=Xte.astype(float)
        na=[c for c in ALL_NUM if Xtr[c].isna().any() or Xte[c].isna().any()]
        med=Xtr[na].median()
        Xtr[na]=Xtr[na].fillna(med);Xte[na]=Xte[na].fillna(med)
        ytr=train.sale_price_gross.values;yte=test.sale_price_gross.values
        lo,hi=np.quantile(ytr,[.01,.99]);ktr=(ytr>=lo)&(ytr<=hi);kte=(yte>=lo)&(yte<=hi)
        assert kte.sum()>0 and ktr.sum()>0
        fold_summary.append({'fold':k,'n_train':int(ktr.sum()),'n_test':int(kte.sum()),
           'train_last_date':str(train.sale_date_parsed.max().date()),
           'test_first_date':str(test.sale_date_parsed.min().date()),
           'price_trim_lo':float(lo),'price_trim_hi':float(hi)})
        print(f'FOLD {k}/5 train={ktr.sum():,}, test={kte.sum():,} start={time.strftime("%H:%M:%S")}',flush=True)
        for gn,cols in groups.items():
            for name in names:
                m=models(name)
                t0=time.monotonic()
                m.fit(Xtr.loc[ktr,cols],ytr[ktr]);pred=m.predict(Xte.loc[kte,cols])
                sc=metrics(yte[kte],pred)
                results.append({'fold':k,'feature_set':gn,'model':name,'n_test':int(kte.sum()),
                                'runtime_s':round(time.monotonic()-t0,2),**sc})
                for row,actual,estimate in zip(test_idx[kte],yte[kte],pred):
                    predictions.append({'row_id':int(row),'fold':k,'feature_set':gn,
                                        'model':name,'actual':float(actual),'prediction':float(estimate)})
                print('    ',gn,name,'MAE',round(sc['MAE']), 'RMSE',round(sc['RMSE']),
                      'runtime',round(time.monotonic()-t0,1),'s',flush=True)
        # Save a partial aggregate after each fold for crash recovery
        pd.DataFrame(results).to_csv(out/'fold_results_in_progress.csv',index=False)
    result=pd.DataFrame(results);p=pd.DataFrame(predictions);folds=pd.DataFrame(fold_summary)
    agg=[]
    for (g,name),sub in p.groupby(['feature_set','model']):
        agg.append({'feature_set':g,'model':name,'n_test':len(sub),**metrics(sub.actual,sub.prediction)})
    agg=pd.DataFrame(agg).sort_values(['feature_set','MAE'])
    result.to_csv(out/'companion_fold_results.csv',index=False)
    agg.to_csv(out/'companion_pooled_results.csv',index=False)
    folds.to_csv(out/'fold_summary.csv',index=False)
    # Never package this row-level evaluation output, only aggregates.
    priv=out/'PRIVATE';priv.mkdir(exist_ok=True)
    p.to_csv(priv/'companion_oof_predictions.csv.gz',index=False,compression='gzip')
    (out/'cohort_audit.json').write_text(json.dumps(cohort,indent=2))
    manifest={'teammate_notebook_sha256':NOTEBOOK_SHA,'source_dataset_sha256':DATA_SHA,
      'teammate_source_unmodified':True,'cohort_rows':len(eligible),'total_oof':int(folds.n_test.sum()),
      'scope':'teammate original price-screened OOF observations',
      'models_separately_developed':list(model_names),
      'reference':'Original team metrics from unchanged XGBoost.ipynb (see fixed_reference_metrics.json)'}
    (out/'run_manifest.json').write_text(json.dumps(manifest,indent=2))
    (out/'fixed_reference_metrics.json').write_text(json.dumps(TEAM_RESULTS,indent=2))
    return result,agg,p,folds,cohort

if __name__=='__main__':
    arg=argparse.ArgumentParser();arg.add_argument('--dataset',required=True)
    arg.add_argument('--notebook',required=True);arg.add_argument('--out',default='results')
    a=arg.parse_args()
    for f,expected in [(a.dataset,DATA_SHA),(a.notebook,NOTEBOOK_SHA)]:
        actual=sha256(f)
        if actual!=expected:raise SystemExit(f'Immutable source mismatch: {f} sha256 {actual}')
    try:
        raw=pd.read_parquet(a.dataset)
        print('Source read using installed Parquet engine',flush=True)
    except ImportError:
        # Offline Linux-only fallback; Windows users should install PyArrow.
        from parquet_readonly import read_parquet
        raw=read_parquet(a.dataset)
        print('Source read using read-only local SNAPPY decoder',flush=True)
    print('READER DONE',raw.shape,flush=True)
    result,agg,p,folds,cohort=run(raw,out=a.out)
    print('Cohort filters',cohort,'\n POOLED:',agg.to_string(index=False),flush=True)
