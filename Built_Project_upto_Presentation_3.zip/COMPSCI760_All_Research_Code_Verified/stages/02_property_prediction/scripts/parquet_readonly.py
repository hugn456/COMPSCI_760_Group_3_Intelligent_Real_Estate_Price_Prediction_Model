"""Compatibility import: the shared Parquet reader is maintained in common/."""
from pathlib import Path
import sys

PROJECT_ROOT = Path(__file__).resolve().parents[3]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from common.parquet_readonly import *  # noqa: F401,F403
