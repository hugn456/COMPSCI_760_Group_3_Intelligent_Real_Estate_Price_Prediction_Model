"""Rebuild clean Stage 2 charts and research report from immutable aggregate tables only.

Never runs or modifies the teammate model. All cited XGBoost figures originate in
its previously saved notebook and report, not from a second XGBoost model.
"""
from pathlib import Path
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'results'
summary=pd.read_csv(OUT/'all_models_augmented_comparison.csv')
folds=pd.read_csv(OUT/'fold_by_fold_comparison.csv')
ablation=pd.read_csv(OUT/'non_xgb_feature_ablation.csv')
assert summary.model.str.contains('XGBoost').sum()==1
assert summary.model.nunique()==9
assert all(folds.groupby('model').size()==5)
team=summary[summary.model.str.contains('XGBoost')].iloc[0]
near=summary[summary.model.eq('LightGBM')].iloc[0]

# Pooled MAE on all nine named algorithm families.
fig,ax=plt.subplots(figsize=(10.7,5.8))
chart=summary.sort_values('MAE',ascending=False)
y=np.arange(len(chart))
colors=['#17649c' if 'XGBoost' in name else '#94abbc' for name in chart.model]
ax.barh(y,chart.MAE,color=colors,height=.70)
ax.set_yticks(y,labels=chart.model)
ax.set_xlim(0,max(chart.MAE)*1.27)
ax.set_xlabel('MAE (NZD; lower is better)')
ax.set_title('Auckland property-price prediction: Stage 2 comparison')
for i,val in enumerate(chart.MAE):ax.text(val+2200,i,f'${val:,.0f}',va='center',fontsize=9)
ax.grid(axis='x',alpha=.20)
ax.set_axisbelow(True)
fig.text(.5,.009,'XGBoost: teammate\'s original reported result. Others: independently trained companion benchmarks.',ha='center',fontsize=8)
fig.tight_layout(rect=(0,.04,1,1));fig.savefig(OUT/'stage02_final_model_mae.png',dpi=170);plt.close(fig)

# Team original fold results as separately reported, compared with newly trained runs.
fig,ax=plt.subplots(figsize=(9.7,5.6))
for name in ['XGBoost — teammate original','LightGBM','HistGradientBoosting','CatBoost','Random Forest (larger)','Random Forest']:
 d=folds[folds.model.eq(name)].sort_values('fold')
 ax.plot(d.fold,d.MAE,marker='o',linewidth=2 if name.startswith('XGBoost') else 1.4,
         linestyle='-' if name.startswith('XGBoost') else '--',label=name)
ax.set_xticks(np.arange(1,6));ax.set_xlabel('Expanding-window fold')
ax.set_ylabel('MAE (NZD)');ax.set_title('Model performance across five folds')
ax.grid(alpha=.20);ax.legend(fontsize=8,ncol=2)
fig.text(.5,.007,'XGBoost fold scores: original teammate report. Companion models: separate model runs.',ha='center',fontsize=8)
fig.tight_layout(rect=(0,.035,1,1));fig.savefig(OUT/'stage02_original_xgb_vs_benchmarks_by_fold.png',dpi=170);plt.close(fig)

# Incremental feature value measured within each newly added model family.
fig,ax=plt.subplots(figsize=(9,4.9))
ablation=ablation.sort_values('augmented_MAE_reduction',ascending=False)
x=np.arange(len(ablation));w=.34
ax.bar(x-w/2,ablation.property_only_MAE,w,label='Original property-feature set')
ax.bar(x+w/2,ablation.augmented_MAE,w,label='Augmented feature set')
ax.set_xticks(x,labels=ablation.model,rotation=10)
ax.set_ylabel('MAE (NZD)');ax.set_title('Feature augmentation helps other boosting algorithms')
ax.legend();ax.grid(axis='y',alpha=.18)
fig.tight_layout();fig.savefig(OUT/'stage02_boosting_feature_ablation.png',dpi=170);plt.close(fig)

# Evaluation-only subgroup errors for a comparison of two non-XGBoost models.
sub=pd.read_csv(OUT/'benchmark_price_bands.csv')
labels=['<=750k','750k-1m','1m-1.5m','1.5m-2m','>2m']
fig,ax=plt.subplots(figsize=(9.5,5.1));x=np.arange(5);w=.36
for i,name in enumerate(['LightGBM','CatBoost']):
 d=sub[sub.model.eq(name)].set_index('price_group').reindex(labels)
 assert d.model_MAE.notna().all()
 ax.bar(x+(i-.5)*w,d.model_MAE,w,label=name)
ax.set_xticks(x,labels);ax.set_ylabel('MAE (NZD)');ax.set_xlabel('Actual sale-price band (evaluation only)')
ax.set_title('Independent model errors by actual sale-price range')
ax.legend();ax.grid(axis='y',alpha=.18)
fig.tight_layout();fig.savefig(OUT/'stage02_independent_benchmarks_price_bands.png',dpi=170);plt.close(fig)

n=int(team.n_test)
rows=['# COMPSCI 760 — Stage 2: Property Price Prediction and Independent Model Comparisons','',
 '**Group policy:** The teammate’s original `XGBoost.ipynb`, its method, and all reported scores are unchanged. Only one XGBoost result appears here: the original model from the team notebook. All other models were developed and evaluated independently.','',
 '## Dataset and evaluation','',
 f'The original property dataset contains 92,010 rows. The teammate’s six filtering conditions identify 59,798 eligible sales; the five expanding time-series folds produce **{n:,} evaluated sales** after applying the original per-fold price-screening procedure. Our new models use the same documented fold design, feature groups and score definitions; exact property-by-property equivalence to the teammate’s saved XGBoost predictions cannot be verified without their row-level prediction export.','',
 'The augmented set consists of 35 attributes, including latitude and longitude. These results do not isolate the effect of other external layers after coordinates.','',
 '## Pooled augmented-model results','',
 '| Model | Source | MAE (NZD) | RMSE (NZD) | MAPE (%) |','|---|---|---:|---:|---:|']
for r in summary.itertuples(index=False):
 rows.append(f'| {r.model} | {r.source} | {r.MAE:,.0f} | {r.RMSE:,.0f} | {r.MAPE_pct:.2f} |')
rows+=['',
 f'**Interpretation:** The team’s original XGBoost has the lowest **reported** MAE (NZ${team.MAE:,.0f}) and RMSE (NZ${team.RMSE:,.0f}) among these nine configurations. The closest independent alternative is LightGBM (MAE NZ${near.MAE:,.0f}; RMSE NZ${near.RMSE:,.0f}). The aggregate MAE difference is approximately NZ${near.MAE-team.MAE:,.0f}. This supports the group’s choice of XGBoost *among the configurations evaluated*, not universal algorithm superiority.','',
 '![Pooled model MAE](stage02_final_model_mae.png)','',
 '## Fold-level comparison','',
 'The figure below uses the **original five per-fold augmented XGBoost scores from the team report**, alongside the independently trained model fold scores. Thus no alternative XGBoost implementation appears. These fold averages are descriptive and do not establish statistical significance.','',
 '![Original XGBoost and companion fold performance](stage02_original_xgb_vs_benchmarks_by_fold.png)','',
 '| Fold | Original XGBoost MAE | LightGBM MAE | Lower MAE |','|---|---:|---:|---|']
for i in range(1,6):
 x=folds[(folds.model=='XGBoost — teammate original')&(folds.fold==i)].iloc[0]
 l=folds[(folds.model=='LightGBM')&(folds.fold==i)].iloc[0]
 rows.append(f'| {i} | NZ${x.MAE:,.0f} | NZ${l.MAE:,.0f} | {"XGBoost" if x.MAE<l.MAE else "LightGBM"} |')
rows+=['','The original reported XGBoost has a lower MAE than LightGBM in **4 of 5** folds. These comparisons are across published/aggegated fold metrics and do not substitute for a paired transaction-level significance test.','',
 '## Feature-set checks on independent boosting models','',
 '| Model | Property features MAE | Augmented MAE | Reduction |','|---|---:|---:|---:|']
for r in ablation.itertuples(index=False):
 rows.append(f'| {r.model} | NZ${r.property_only_MAE:,.0f} | NZ${r.augmented_MAE:,.0f} | NZ${r.augmented_MAE_reduction:,.0f} |')
rows+=['','Feature augmentation benefits these three independently trained models. Because coordinates are part of the augmented set, no claim about the *additional* impact of environmental information alone follows.','',
 '![Feature augmentation ablation](stage02_boosting_feature_ablation.png)','',
 '## Price-band diagnostics for independently trained models','',
 'The price-band chart compares only LightGBM and CatBoost, whose individual predictions are available from our separate experiments. The team’s original XGBoost is deliberately absent from this subgroup chart because the original per-sale predictions were not provided.','',
 '![Price band diagnostics](stage02_independent_benchmarks_price_bands.png)','',
 '## Inference and methodological boundaries','',
 '**We do not report paired confidence intervals comparing the original XGBoost with another model**, because its exact property-level predictions are unavailable. The main model comparison reports descriptive, pooled and fold-level scores only.','',
 'Additional limitations are (i) the original row-based `TimeSeriesSplit` protocol can divide sales from the same date between training and test; (ii) the original 1st–99th percentile test-price inclusion rule uses observed sale prices, so results apply to a screened evaluation cohort; (iii) external GIS feature vintages have not been established for every historical sale; (iv) comparison models are reasonable tested configurations, not exhaustively optimised across algorithms. None of these caveats changes the teammate’s original implementation.','',
 '## Group-ready report wording','',
 '> We selected XGBoost as the primary property-price model following the team’s original experiments. To support this decision, separate benchmark runs assessed Random Forest, Extra Trees, LightGBM, CatBoost, histogram gradient boosting, Ridge regression and a median-price baseline using the same recorded feature groups and five-fold evaluation design. The original XGBoost achieved a reported MAE of NZ$131,243 and RMSE of NZ$214,530, the lowest reported errors among the evaluated configurations. LightGBM was the nearest alternative, with an MAE of NZ$133,294. The comparison supports XGBoost as the best-performing tested configuration, while a direct paired statistical test with the original model remains unavailable without its transaction-level predictions.','']
(OUT/'STAGE02_FINAL_CLEAN_REPORT.md').write_text('\n'.join(rows))
print('Generated clean research report, four charts, fold tables: ',OUT)
