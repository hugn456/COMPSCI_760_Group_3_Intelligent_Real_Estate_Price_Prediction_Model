"""Additional independent COMPSCI760 Stage2 benchmarks. Team notebook is READ-ONLY.

Inherit teammate's original source->cohort/feature/timesplit and train-target 1-99%
trim logic, WITHOUT changing the teammate notebook. Produce independent model
results only. The team's original XGBoost remains the sole XGBoost reference.
Direct paired inference against it is unavailable without its original predictions.
"""
from __future__ import annotations
import argparse, json, time, sys, os
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingRegressor, RandomForestRegressor
from sklearn.linear_model import Ridge
from sklearn.model_selection import TimeSeriesSplit
from sklearn.preprocessing import OrdinalEncoder,StandardScaler
from sklearn.pipeline import make_pipeline
from catboost import CatBoostRegressor
from lightgbm import LGBMRegressor

THIS=Path(__file__).resolve().parent
sys.path.insert(0,str(THIS/'scripts'))
from run_rf_and_baselines import (prepare, sha256, NOTEBOOK_SHA, DATA_SHA,
       AUGMENTED,BASELINE,ALL_CAT,ALL_NUM,EXTERNAL_BOOL,metrics)

SOURCE=Path(os.environ.get('COMPSCI760_DATASET','/mnt/data/newest_dvrs_with_team_external.parquet'))
NOTEBOOK=Path(os.environ.get('COMPSCI760_NOTEBOOK','/mnt/data/XGBoost.ipynb'))

MODEL_SPECS={
 'LightGBM':{'n_estimators':450,'num_leaves':31,'learning_rate':.04,'min_child_samples':22,'max_depth':-1,'colsample_bytree':.8,'reg_lambda':2,'verbosity':-1,'random_state':42,'n_jobs':2},
 'CatBoost':{'iterations':500,'depth':6,'learning_rate':.05,'l2_leaf_reg':3,'loss_function':'RMSE','verbose':False,'random_seed':42,'thread_count':2,'allow_writing_files':False},
 'HistGradientBoosting':{'max_iter':250,'max_leaf_nodes':31,'learning_rate':.06,'min_samples_leaf':20,'l2_regularization':1,'random_state':42},
 'Ridge (scaled)':{'alpha':200.0},
 'Random Forest (larger)':{'n_estimators':160,'max_depth':None,'min_samples_leaf':2,'max_features':.8,'random_state':42,'n_jobs':2},
}

def estimator(name):
 if name=='LightGBM': return LGBMRegressor(**MODEL_SPECS[name])
 if name=='CatBoost': return CatBoostRegressor(**MODEL_SPECS[name])
 if name=='HistGradientBoosting':return HistGradientBoostingRegressor(**MODEL_SPECS[name])
 if name=='Ridge (scaled)':return make_pipeline(StandardScaler(),Ridge(**MODEL_SPECS[name]))
 if name=='Random Forest (larger)':return RandomForestRegressor(**MODEL_SPECS[name])
 raise KeyError(name)

def read_data():
 assert sha256(SOURCE)==DATA_SHA and sha256(NOTEBOOK)==NOTEBOOK_SHA,'Immutable source SHA mismatch'
 try: return pd.read_parquet(SOURCE)
 except ImportError:
  from parquet_readonly import read_parquet
  return read_parquet(SOURCE)

def prepare_fold_matrices(train,test):
 """Mirror existing companion's training-only encoding and imputation."""
 enc=OrdinalEncoder(handle_unknown='use_encoded_value',unknown_value=-1)
 enc.fit(train[ALL_CAT])
 Xtr=train[AUGMENTED].copy();Xte=test[AUGMENTED].copy()
 Xtr[ALL_CAT]=enc.transform(train[ALL_CAT]);Xte[ALL_CAT]=enc.transform(test[ALL_CAT])
 for c in EXTERNAL_BOOL:
  Xtr[c]=Xtr[c].astype(int);Xte[c]=Xte[c].astype(int)
 Xtr=Xtr.astype(float);Xte=Xte.astype(float)
 na=[c for c in ALL_NUM if Xtr[c].isna().any() or Xte[c].isna().any()]
 med=Xtr[na].median()
 Xtr[na]=Xtr[na].fillna(med);Xte[na]=Xte[na].fillna(med)
 if Xtr.isna().any().any() or Xte.isna().any().any():
  raise ValueError('Unexpected missing model inputs')
 return Xtr,Xte

def run(features=('P+E',),models=('LightGBM','CatBoost','HistGradientBoosting','Ridge (scaled)','Random Forest (larger)'),out=None):
 out=Path(out or THIS/'results');out.mkdir(parents=True,exist_ok=True)
 (out/'PRIVATE').mkdir(exist_ok=True)
 print('Reading frozen dataset, no writes to original files',flush=True)
 raw=read_data()
 df,counts=prepare(raw)
 assert counts['linz_matched']==59798
 # Pre-capture available council assessment ID from unchanged df, not a new predictor.
 if 'valuation_id_concat' in df:
  property_ids=df['valuation_id_concat'].astype('string').fillna('')
 else:
  property_ids=pd.Series(['']*len(df),index=df.index,dtype='string')
 print('Eligible transactions',len(df),flush=True)
 predictions=[];scores=[]; folds=[]
 for fold,(train_idx,test_idx) in enumerate(TimeSeriesSplit(n_splits=5).split(df),1):
  train=df.iloc[train_idx];test=df.iloc[test_idx]
  Xtr,Xte=prepare_fold_matrices(train,test)
  ytr=train.sale_price_gross.to_numpy(float);yte=test.sale_price_gross.to_numpy(float)
  lo,hi=np.quantile(ytr,[.01,.99]);keeptr=(ytr>=lo)&(ytr<=hi);keepte=(yte>=lo)&(yte<=hi)
  assert keeptr.sum()>0 and keepte.sum()>0
  folds.append({'fold':fold,'train_count':int(keeptr.sum()),'test_count':int(keepte.sum()),'train_end_date':str(train.sale_date_parsed.max().date()),'test_start_date':str(test.sale_date_parsed.min().date())})
  for feature in features:
   cols=BASELINE if feature=='P' else AUGMENTED if feature=='P+E' else None
   if cols is None:raise ValueError(feature)
   for model_name in models:
    t=time.monotonic(); est=estimator(model_name)
    est.fit(Xtr.loc[keeptr,cols],ytr[keeptr])
    pred=np.asarray(est.predict(Xte.loc[keepte,cols]),dtype=float)
    values=metrics(yte[keepte],pred)
    score={'model':model_name,'feature_set':feature,'fold':fold,'n_test':int(keepte.sum()),'fit_and_predict_s':round(time.monotonic()-t,3),**values}
    scores.append(score)
    for idx,truth,yhat in zip(test_idx[keepte],yte[keepte],pred):
     predictions.append({'row_id':int(idx),'fold':fold,'actual':float(truth),'prediction':float(yhat),'property_key':str(property_ids.iloc[idx]),'feature_set':feature,'model':model_name})
    print(f"Fold {fold}/5 {feature} {model_name}: MAE {values['MAE']:,.0f} RMSE {values['RMSE']:,.0f} {time.monotonic()-t:.1f}s",flush=True)
  pd.DataFrame(scores).to_csv(out/'fold_metrics_progress.csv',index=False)
  pd.DataFrame(predictions).to_csv(out/'PRIVATE/extended_predictions_progress.csv.gz',index=False,compression='gzip')
 scores=pd.DataFrame(scores);predictions=pd.DataFrame(predictions)
 pooled=[];slice_groups=[]
 for (feature,model),group in predictions.groupby(['feature_set','model']):
  pooled.append({'feature_set':feature,'model':model,'n_test':len(group),**metrics(group.actual,group.prediction)})
  # Evaluation-only property price bins. This model's own errors only;
  # no synthetic substitution for teammate XGBoost property-level results.
  breaks=[0,750_000,1_000_000,1_500_000,2_000_000,np.inf]
  labels=['<=750k','750k-1m','1m-1.5m','1.5m-2m','>2m']
  binned=group.copy()
  binned['price_group']=pd.cut(binned.actual,bins=breaks,labels=labels,include_lowest=True)
  for band,items in binned.groupby('price_group',observed=True):
   slice_groups.append({'model':model,'feature_set':feature,'price_group':str(band),
                        'n':len(items),'model_MAE':float(np.abs(items.actual-items.prediction).mean())})
 scores.to_csv(out/'fold_metrics.csv',index=False)
 pd.DataFrame(pooled).sort_values(['feature_set','MAE']).to_csv(out/'pooled_metrics.csv',index=False)
 pd.DataFrame(slice_groups).to_csv(out/'price_band_checks.csv',index=False)
 pd.DataFrame(folds).to_csv(out/'fold_summary.csv',index=False)
 predictions.to_csv(out/'PRIVATE/extended_predictions.csv.gz',index=False,compression='gzip')
 manifest={'source_dataset_sha256':DATA_SHA,'teammate_notebook_sha256':NOTEBOOK_SHA,
           'original_notebook_untouched':True, 'source_read_only':True,'cohort':counts,'evaluation_rows':int(sum(d['test_count'] for d in folds)),
           'feature_sets':list(features),'new_models':list(models),'model_parameters':{k:MODEL_SPECS[k] for k in models},
           'benchmark_reference':'original teammate XGBoost notebook saved summary scores only; no paired inference',
           'original_teammate_XGBoost_MAE_augmented':131243.38,
           'test_trim_note':'Teammate protocol selects test rows with true prices within the training 1% to 99% boundaries',
           'model_selection_note':'Additional model parameters chosen before viewing results. No claim of exhaustive tuning.'}
 (out/'manifest.json').write_text(json.dumps(manifest,indent=2))
 return scores,pd.DataFrame(pooled),pd.DataFrame(slice_groups)

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--features',nargs='+',default=['P+E'],choices=['P','P+E'])
 p.add_argument('--models',nargs='+',default=list(MODEL_SPECS),choices=list(MODEL_SPECS));p.add_argument('--out',default=str(THIS/'results'))
 a=p.parse_args();run(tuple(a.features),tuple(a.models),out=a.out)
