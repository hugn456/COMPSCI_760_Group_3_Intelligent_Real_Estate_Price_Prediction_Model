from pathlib import Path
import importlib.util
import pandas as pd
import pytest

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'results'

def test_one_and_only_original_xgboost():
    scores=pd.read_csv(OUT/'all_models_augmented_comparison.csv')
    xgb=scores[scores.model.str.contains('XGBoost')]
    assert len(scores)==9 and len(xgb)==1
    assert xgb.iloc[0].model=='XGBoost — teammate original'
    assert xgb.iloc[0].MAE==pytest.approx(131243.38)
    assert xgb.iloc[0].RMSE==pytest.approx(214529.56)
    assert xgb.iloc[0].source.startswith('Teammate original notebook')
    assert scores.iloc[0].model=='XGBoost — teammate original'


def test_fold_results_original_source_and_five_observations_each():
    folds=pd.read_csv(OUT/'fold_by_fold_comparison.csv')
    assert all(v==5 for v in folds.groupby('model').size())
    assert folds.model.str.contains('XGBoost').sum()==5
    orig=folds[folds.model.str.contains('XGBoost')]
    assert all(orig.source.str.startswith('Teammate original'))
    assert orig.n_test.sum()==48848
    assert orig.sort_values('fold').MAE.iloc[0]==pytest.approx(140093.61)
    assert orig.sort_values('fold').MAE.iloc[-1]==pytest.approx(121260.98)


def test_feature_ablation_is_non_xgb_and_matches_main_scores():
    ab=pd.read_csv(OUT/'non_xgb_feature_ablation.csv')
    main=pd.read_csv(OUT/'all_models_augmented_comparison.csv').set_index('model')
    assert len(ab)==3 and (ab.augmented_MAE_reduction>0).all()
    for r in ab.itertuples(index=False):
        assert r.augmented_MAE==pytest.approx(main.loc[r.model].MAE)


def test_price_bands_contain_only_independently_evaluated_models():
    pb=pd.read_csv(OUT/'benchmark_price_bands.csv')
    assert not pb.model.str.contains('XGBoost',case=False).any()
    assert set(pb.price_group)=={'<=750k','750k-1m','1m-1.5m','1.5m-2m','>2m'}
    assert pb.groupby('model').n.sum().eq(48848).all()


def test_no_extra_xgboost_in_text_files():
    # The shareable package must not introduce an extra XGBoost implementation.
    for f in ROOT.rglob('*'):
        if not f.is_file() or any(x in f.parts for x in ('__pycache__','.pytest_cache','PRIVATE','tests')):
            continue
        if f.suffix not in ('.py','.csv','.md','.json','.txt'):
            continue
        content=f.read_text(encoding='utf-8').lower()
        assert 'notebook-spec' not in content or 'notebook-spec' in f.name
        assert 'xgboost replay' not in content
        assert 'independent xgboost' not in content


def test_source_helpers_load_without_model_files():
    source=(ROOT/'scripts/run_rf_and_baselines.py').read_text()
    assert 'XGBRegressor' not in source
    source2=(ROOT/'run_additional_benchmarks.py').read_text()
    assert 'REPLAY_CSV' not in source2
    assert 'XGBRegressor' not in source2
