import sys
from pathlib import Path
import numpy as np,pandas as pd,pytest
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'src'))
from stage03_core import reproduce_teammate_eligibility,monthly_series,month_features,forecast_one,walk_forward,score_forecasts,choose_from_validation,fixed_origin_forecast


def toy_data():
    months=pd.date_range('2024-01-01',periods=30,freq='MS')
    n=30*3
    return pd.DataFrame({'sale_date':[f'{d.day}{d.month:02d}{d.year}' for d in months for k in range(3)],
        'sale_price_gross':[float(700000+12000*i + [0,30000,100000][j]) for i in range(30) for j in range(3)],
        'zoning':['9A']*n,'units_of_use':[1]*n,'sale_tenure':['1']*n,'sale_type':['S']*n,
        'price_value_relationship':['1']*n,'linz_matched':[True]*n})

def test_matching_filter_order():
    d=toy_data()
    d.loc[0,'sale_type']='X';d.loc[1,'sale_tenure']='2';d.loc[2,'linz_matched']=False
    a,c=reproduce_teammate_eligibility(d)
    assert c['source']==90 and c['LINZ matched']==87 and a.sale_price_gross.gt(0).all()

def test_aggregates_are_monthly_and_medians():
    d,c=reproduce_teammate_eligibility(toy_data())
    m,summary=monthly_series(d)
    assert len(m)==30 and summary['included_transactions']==90
    assert m.iloc[0].median_price_nzd==730000

def test_history_features_have_only_past_information():
    m,_=monthly_series(reproduce_teammate_eligibility(toy_data())[0]); features=month_features(m)
    assert pd.isna(features.iloc[0].price_lag_1m)
    assert features.iloc[1].price_lag_1m==m.iloc[0].median_price_nzd
    assert features.iloc[12].price_lag_12m==m.iloc[0].median_price_nzd
    assert pd.isna(features.iloc[12].price_yoy_prev_month_pct)
    for date in features.index[1:]:
        changed=m.copy();changed.loc[changed.index>=date,'median_price_nzd']=99_999_999
        new=month_features(changed)
        old=features.loc[date,features.columns!='calendar_month']
        fresh=new.loc[date,features.columns!='calendar_month']
        pd.testing.assert_series_equal(old,fresh)

def test_seasonal_naive_uses_history_only():
    v=np.arange(20,dtype=float)*1000+900000
    assert forecast_one(v,'Seasonal naive (12m)')==v[-12]
    assert forecast_one(v,'Naive (last month)')==v[-1]

def test_walk_forward_validation_test_isolation():
    m,_=monthly_series(reproduce_teammate_eligibility(toy_data())[0])
    forecasts=walk_forward(m.median_price_nzd,models=['Naive (last month)','Seasonal naive (12m)'])
    assert len(forecasts)==24
    assert forecasts.query('phase=="validation"').month.nunique()==6
    assert forecasts.query('phase=="test"').month.nunique()==6
    assert forecasts.groupby(['phase','model']).size().eq(6).all()
    assert all(pd.Timestamp(a)<pd.Timestamp(b) for a,b in forecasts[['trained_through','month']].itertuples(index=False,name=None))
    sc=score_forecasts(forecasts)
    assert choose_from_validation(sc) in forecasts.model.unique()

def test_fixed_origin_disallows_test_year_target_leakage():
    m,_=monthly_series(reproduce_teammate_eligibility(toy_data())[0]);y=m.median_price_nzd
    a=fixed_origin_forecast(y)
    changed=y.copy();changed.iloc[24:]*=2
    b=fixed_origin_forecast(changed)
    assert np.array_equal(a.forecast_nzd.to_numpy(),b.forecast_nzd.to_numpy())
    assert not np.array_equal(a.actual_nzd.to_numpy(),b.actual_nzd.to_numpy())

def test_reject_bad_month_count():
    m,_=monthly_series(reproduce_teammate_eligibility(toy_data())[0])
    with pytest.raises(ValueError,match='number of months'):
        walk_forward(m.median_price_nzd.iloc[:-1],models=['Naive (last month)'])

def test_historical_features_merge_by_month_not_current_price():
    sys.path.insert(0,str(ROOT))
    from run_historical_feature_pilot import joined_features,H_COLS
    d,c=reproduce_teammate_eligibility(toy_data());m,_=monthly_series(d)
    f=joined_features(d,m)
    assert f.shape[0]==d.shape[0]
    assert len(H_COLS)==9
    march=f.loc[f.month==pd.Timestamp('2025-03-01')]
    assert march.price_lag_1m.eq(m.loc['2025-02-01','median_price_nzd']).all()
    assert not march.price_lag_1m.eq(m.loc['2025-03-01','median_price_nzd']).all()


def test_feature_pilot_encoder_is_train_fitted_only():
    sys.path.insert(0,str(ROOT))
    from run_historical_feature_pilot import train_only_encoder
    from companion_stage02_features import AUGMENTED,ALL_CAT,EXTERNAL_BOOL
    # Synthetic dataframe with all teammate-selected input features, not a new teammate model.
    from companion_stage02_features import ALL_NUM
    baseline={k:np.ones(12) for k in ALL_NUM+EXTERNAL_BOOL}
    for k in ALL_CAT:baseline[k]=['A']*8+['B']*4
    df=pd.DataFrame(baseline)
    df.loc[8,'land_area']=np.nan
    # require just the augmented 35 fields
    tr=df.iloc[:8];te=df.iloc[8:]
    a,b=train_only_encoder(tr,te,AUGMENTED)
    assert b[ALL_CAT[0]].iloc[0]==-1
    assert np.isfinite(a.to_numpy()).all() and np.isfinite(b.to_numpy()).all()


def test_saved_series_and_model_selection_stable():
    base=ROOT/'results'
    if not (base/'experiment_manifest.json').is_file():pytest.skip('results not present in clean source-only test run')
    import json
    mf=json.loads((base/'experiment_manifest.json').read_text())
    m=pd.read_csv(base/'monthly_median_series.csv')
    s=pd.read_csv(base/'forecast_model_comparison.csv')
    assert mf['series_summary']['included_transactions']==59281
    assert len(m)==30
    assert mf['winner']==choose_from_validation(s)
    assert mf['winner']=='Seasonal naive (12m)'
