"""Independent experiment B: Does lagged market context help our companion RF?

NEVER execute, retrain or modify teammate's original XGBoost. This experiment
uses its documented eligibility, base + external feature definitions, and an
independent rolling monthly re-trained Random Forest pair as a diagnostic.
Not directly comparable to official team XGB; separate time windows/estimator.
"""
from __future__ import annotations
import argparse,json,sys,hashlib
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import OrdinalEncoder
from sklearn.metrics import mean_absolute_error
sys.path.insert(0,str(Path(__file__).resolve().parent/'src'))
from stage03_core import read_verified_source,reproduce_teammate_eligibility,monthly_series,month_features,DATA_HASH,NOTEBOOK_HASH
from companion_stage02_features import prepare, AUGMENTED, ALL_CAT, ALL_NUM, EXTERNAL_BOOL

H_COLS=['price_lag_1m','price_lag_3m','price_lag_12m','price_mean_prev3m','price_mean_prev6m',
        'price_momentum_prev_1m_vs_3m','price_yoy_prev_month_pct','sales_count_prev_month',
        'sales_volume_mean_prev3m']


def joined_features(eligible:pd.DataFrame, monthly:pd.DataFrame):
    market=month_features(monthly)[H_COLS].copy()
    # No historical feature uses the current month's sale price.
    grouped=eligible.copy()
    grouped['month']=grouped.sale_date_parsed.dt.to_period('M').dt.to_timestamp()
    features=grouped.merge(market,left_on='month',right_index=True,how='left',validate='many_to_one')
    return features


def train_only_encoder(training,testing,cols):
    enc=OrdinalEncoder(handle_unknown='use_encoded_value',unknown_value=-1)
    enc.fit(training[ALL_CAT])
    def encoded(block):
        x=block[cols].copy()
        x[ALL_CAT]=enc.transform(block[ALL_CAT])
        for v in EXTERNAL_BOOL:x[v]=x[v].astype(int)
        for v in H_COLS:
            if v in x.columns:x[v]=pd.to_numeric(x[v],errors='coerce')
        return x.astype(float)
    a=encoded(training); b=encoded(testing)
    med=a.median(numeric_only=True)
    a=a.fillna(med);b=b.fillna(med)
    if not np.isfinite(a.to_numpy()).all() or not np.isfinite(b.to_numpy()).all():
        raise ValueError('Incomplete feature matrix after train-only imputation')
    return a,b


def evaluate_pilot(data,outdir,trees=90):
    output=Path(outdir);output.mkdir(parents=True,exist_ok=True)
    # Rolling-origin test: for each forecast month, update training using only
    # transactions strictly before its first day. 2025-02+ guarantees lag12.
    data=data.copy()
    data['month']=data.sale_date_parsed.dt.to_period('M').dt.to_timestamp()
    data=data.loc[data.month.between('2025-02-01','2026-06-01')].copy()
    rows=[];sample_counts=[]
    for month in pd.date_range('2025-10-01','2026-06-01',freq='MS'):
        phase='validation' if month<pd.Timestamp('2026-01-01') else 'test'
        tr=data.loc[data.month<month]
        te=data.loc[data.month==month]
        if len(tr)<2000 or len(te)<100:raise ValueError('Unexpectedly sparse fold')
        assert tr.sale_date_parsed.max()<te.sale_date_parsed.min()
        # Train-only price percentile trimming, same for both independent RF variants.
        p1,p99=np.quantile(tr.sale_price_gross,[.01,.99])
        train_ok=tr.sale_price_gross.between(p1,p99)
        sample_counts.append({'month':str(month.date()),'phase':phase,'train_rows':len(tr),
                              'train_fit_rows':int(train_ok.sum()),'test_rows_all':len(te),
                              'test_rows_within_train_price_bounds':int(te.sale_price_gross.between(p1,p99).sum())})
        cols=AUGMENTED+H_COLS
        xtr,xte=train_only_encoder(tr,te,cols)
        for featset,features in [('original_augmented',AUGMENTED),('original_augmented_plus_past_market',cols)]:
            model=RandomForestRegressor(n_estimators=trees,max_depth=14,min_samples_leaf=5,
                                        max_features=1.0,random_state=42,n_jobs=2)
            model.fit(xtr.loc[train_ok,features],tr.loc[train_ok,'sale_price_gross'].to_numpy(dtype=float))
            estimates=model.predict(xte[features])
            y=te.sale_price_gross.to_numpy(float)
            within=te.sale_price_gross.between(p1,p99).to_numpy()
            for scope,mask in [('all_sales',np.ones(len(y),dtype=bool)),('teammate_price_band',within)]:
                err=estimates[mask]-y[mask]
                rows.append({'month':str(month.date()),'phase':phase,
                             'model':'RF companion (unchanged team XGB not involved)',
                             'feature_set':featset,'evaluation_scope':scope,'n_test':int(mask.sum()),
                             'MAE_nzd':float(np.mean(abs(err))),
                             'RMSE_nzd':float(np.sqrt(np.mean(err**2))),
                             'mean_signed_error_nzd':float(np.mean(err))})
            print(f'{month.date()} {phase} {featset}: all-sale MAE={np.mean(abs(estimates-y)):,.0f}',flush=True)
    metrics=pd.DataFrame(rows)
    metrics.to_csv(output/'rf_historical_feature_monthly_results.csv',index=False,float_format='%.5f')
    pd.DataFrame(sample_counts).to_csv(output/'rf_historical_feature_sample_counts.csv',index=False)
    agg=metrics.groupby(['phase','feature_set','evaluation_scope'],as_index=False).apply(
        lambda g:pd.Series({'n_months':len(g),'n_total_sales':int(g.n_test.sum()),
               'weighted_MAE_nzd':float(np.average(g.MAE_nzd,weights=g.n_test))}),include_groups=False)
    agg.to_csv(output/'rf_historical_feature_pilot_summary.csv',index=False,float_format='%.5f')
    (output/'rf_historical_feature_pilot_manifest.json').write_text(json.dumps({
        'analysis':'Completely separate companion RandomForest retraining, two feature sets',
        'team_xgboost_untouched':True,'notebook_hash':NOTEBOOK_HASH,'dataset_hash':DATA_HASH,
        'months_train_initial':'Feb-Sep 2025','validation_months':'Oct-Dec 2025','test_months':'Jan-Jun 2026',
        'model':'RandomForestRegressor(n_estimators=%s,max_depth=14,min_samples_leaf=5,max_features=1.0,random_state=42,n_jobs=2)'%trees,
        'rolling':'Refit every month using all previous eligible months, no current month sales in training',
        'error_policy':'primary all-sales (does not depend on future actual prices), sensitivity teammate price-band selection',
        'reporting_assumption':'Month t lag covariates treat month t-1 realised transactions as known before month t; no release timestamp supplied. NOT demonstrated deployable as-of.',
        'limitation':'Cannot use this experiment to claim historical lags improve the fixed official team XGBoost.'},indent=2))
    return agg,metrics


def run(dataset,notebook,out,trees=90):
    # Import source reader from our Stage 02 companion, which uses a read-only
    # Parquet fallback when PyArrow is absent. Teammate file is never executed.
    from parquet_readonly import read_parquet
    from stage03_core import sha256
    if sha256(dataset)!=DATA_HASH or sha256(notebook)!=NOTEBOOK_HASH:
        raise ValueError('Unexpected original source fingerprint')
    raw=read_parquet(dataset)
    standard,counts=prepare(raw)
    if len(standard)!=59798:raise ValueError('Notebook cohort mismatch')
    eligible,_=reproduce_teammate_eligibility(raw)
    months,_=monthly_series(eligible)
    with_features=joined_features(standard,months)
    return evaluate_pilot(with_features,out,trees)

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--dataset',default='/mnt/data/newest_dvrs_with_team_external.parquet')
    p.add_argument('--notebook',default='/mnt/data/XGBoost.ipynb')
    p.add_argument('--out',default='results')
    p.add_argument('--trees',type=int,default=90)
    a=p.parse_args(); run(a.dataset,a.notebook,a.out,a.trees)
