"""Separate Stage 03 module. Team's XGBoost.ipynb is NEVER loaded/executed/modified.

Monthly target: median gross NZD sale price for the exact six-filter eligible
population recorded in teammate notebook cell 43. All figures are descriptive
transaction-mix medians, NOT hedonic-adjusted house-price indices.
"""
from __future__ import annotations
import hashlib
from pathlib import Path
import warnings
import numpy as np
import pandas as pd
from statsmodels.tsa.stattools import adfuller, acf, pacf
from statsmodels.tsa.holtwinters import SimpleExpSmoothing, Holt
from statsmodels.tsa.arima.model import ARIMA

DATA_HASH='07e5e22ea8c6f73b82477b023f5803961b7ba730f9a7474cbb55a27a2c0fb3b2'
NOTEBOOK_HASH='21d388340231d149109195ca0498533de28b33e692c73e6a965ce6a6c62d7057'
COLS=['sale_date','sale_price_gross','zoning','units_of_use','sale_tenure','sale_type','price_value_relationship','linz_matched']
CUTOFF='2026-06'


def sha256(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda:f.read(1<<20),b''):h.update(chunk)
    return h.hexdigest()


def read_verified_source(path, notebook=None):
    if sha256(path)!=DATA_HASH:raise ValueError('Dataset SHA-256 mismatch; STOP')
    if notebook is not None and sha256(notebook)!=NOTEBOOK_HASH:
        raise ValueError('Teammate notebook SHA-256 mismatch; STOP')
    try: return pd.read_parquet(path, columns=COLS)
    except (ImportError, ValueError):
        from parquet_readonly import read_parquet
        return read_parquet(path, columns=COLS)


def parse_notebook_dates(s):
    # Semantics of teammate notebook: day + 2-digit month + 4-digit year.
    # Intentionally retain this parsing convention unchanged in OUR module.
    return s.map(lambda x:pd.Timestamp(year=int(str(x)[-4:]),month=int(str(x)[-6:-4]),day=int(str(x)[:-6])) if pd.notna(x) else pd.NaT)


def reproduce_teammate_eligibility(raw):
    d=raw.copy()
    if not set(COLS).issubset(d):raise ValueError('Missing source columns')
    d['sale_date_parsed']=parse_notebook_dates(d['sale_date'])
    d['sale_price_gross']=pd.to_numeric(d['sale_price_gross'],errors='coerce')
    d['units_of_use']=pd.to_numeric(d['units_of_use'],errors='coerce')
    checks=[('eligible zoning',lambda v:v.zoning.astype(str).str[0].isin(['9','1','2'])),
            ('single unit',lambda v:v.units_of_use.eq(1)),
            ('freehold tenure',lambda v:v.sale_tenure.astype(str).eq('1')),
            ('sale type S',lambda v:v.sale_type.eq('S')),
            ('market relationship',lambda v:v.price_value_relationship.eq('1')),
            ('LINZ matched',lambda v:v.linz_matched.astype(bool))]
    counts={'source':len(d)}
    for name, fn in checks:
        d=d.loc[fn(d)].copy();counts[name]=len(d)
    if len(d)==0:raise ValueError('No eligible sales')
    if d.sale_date_parsed.isna().any() or d.sale_price_gross.isna().any() or (d.sale_price_gross<=0).any():
        raise ValueError('Missing, invalid or nonpositive eligible transaction')
    return d,counts


def monthly_series(eligible, last_complete=CUTOFF):
    d=eligible.copy()
    d['period']=d.sale_date_parsed.dt.to_period('M')
    complete=d.loc[d.period<=pd.Period(last_complete,freq='M')]
    g=complete.groupby('period').sale_price_gross.agg(['size','median','mean']).rename(columns={'size':'n_sales','median':'median_price_nzd','mean':'mean_price_nzd'})
    g=g.asfreq('M')
    if g.isna().any().any() or len(g)<24:raise ValueError('Missing months or too short a series')
    g.index=g.index.to_timestamp(how='start')
    g.index.name='month'
    return g, {'excluded_after_complete_month':int((d.period>pd.Period(last_complete)).sum()),'included_transactions':int(g.n_sales.sum()),'n_months':len(g)}


def month_features(monthly):
    """Row for month t has ONLY price/sales data from months <t.

    The availability premise is publication of monthly sales observations before
    the month being predicted. Historical release-date delays not documented.
    """
    m=monthly.copy()
    y=m.median_price_nzd.astype(float)
    n=m.n_sales.astype(float)
    v=pd.DataFrame(index=m.index)
    v.index.name='month'
    for lag in [1,2,3,6,12]:
        v[f'price_lag_{lag}m']=y.shift(lag)
    v['price_mean_prev3m']=y.shift(1).rolling(3,min_periods=3).mean()
    v['price_median_prev3m']=y.shift(1).rolling(3,min_periods=3).median()
    v['price_mean_prev6m']=y.shift(1).rolling(6,min_periods=6).mean()
    v['price_momentum_prev_1m_vs_3m']=y.shift(1)-y.shift(3)
    v['price_yoy_prev_month_pct']=100*(y.shift(1)/y.shift(13)-1)
    v['sales_count_prev_month']=n.shift(1)
    v['sales_volume_mean_prev3m']=n.shift(1).rolling(3,min_periods=3).mean()
    v['calendar_month']=v.index.month
    return v


def adf_diagnostics(series,training_length=18):
    y=series.iloc[:training_length].astype(float)
    out={}
    for label,values in [('raw',y),('first_difference',y.diff().dropna()),('log',np.log(y)),('log_difference',np.log(y).diff().dropna())]:
        try:
            adf=adfuller(values,autolag='AIC',maxlag=min(3,(len(values)-1)//2-1))
            out[label]={'test_statistic':float(adf[0]),'p_value':float(adf[1]),'used_lags':int(adf[2]),'nobs':int(adf[3])}
        except Exception as e:out[label]={'failure':str(e)}
    for kind,values in [('acf_raw',y),('pacf_raw',y)]:
        try:
            a=acf(values,nlags=6,fft=False) if kind.startswith('acf') else pacf(values,nlags=6,method='ywm')
            out[kind]=[float(x) for x in a]
        except Exception as e:out[kind]={'failure':str(e)}
    return out


def forecast_one(history, model):
    """Fitting uses historical months up to t-1, NEVER month t."""
    y=np.asarray(history,dtype=float)
    if len(y)<15:raise ValueError('Need 15+ observations for Stage 3 models')
    with warnings.catch_warnings():
        warnings.filterwarnings('ignore',category=UserWarning)
        warnings.filterwarnings('ignore',category=RuntimeWarning)
        if model=='Naive (last month)':return float(y[-1])
        if model=='Seasonal naive (12m)':return float(y[-12])
        if model=='Rolling mean (3m)':return float(y[-3:].mean())
        if model=='SES':
            fit=SimpleExpSmoothing(y,initialization_method='estimated').fit(optimized=True)
            return float(fit.forecast(1)[0])
        if model=='Holt damped trend':
            fit=Holt(y,damped_trend=True,initialization_method='estimated').fit(optimized=True)
            return float(fit.forecast(1)[0])
        params={'ARIMA (0,1,1)':(0,1,1),'ARIMA (1,1,0)':(1,1,0),'ARIMA (1,1,1)':(1,1,1)}
        if model in params:
            fit=ARIMA(y,order=params[model],enforce_stationarity=False,enforce_invertibility=False).fit(method_kwargs={'maxiter':75})
            return float(fit.forecast(1)[0])
    raise KeyError(f'Unknown forecasting model: {model}')

MODELS=['Naive (last month)','Seasonal naive (12m)','Rolling mean (3m)','SES','Holt damped trend','ARIMA (0,1,1)','ARIMA (1,1,0)','ARIMA (1,1,1)']


def walk_forward(series, models=MODELS, initial_train_months=18, validation_months=6, test_months=6):
    y=series.astype(float)
    if len(y)!=initial_train_months+validation_months+test_months:
        raise ValueError('Unexpected number of months; review cohort/date window')
    rows=[]
    for month_pos in range(initial_train_months,len(y)):
        history=y.iloc[:month_pos]
        phase='validation' if month_pos<initial_train_months+validation_months else 'test'
        for name in models:
            forecast=forecast_one(history.to_numpy(),name)
            actual=float(y.iloc[month_pos])
            rows.append({'month':str(y.index[month_pos].date()),'phase':phase,
                         'model':name,'trained_through':str(history.index[-1].date()),
                         'train_months':len(history),'actual_nzd':actual,'forecast_nzd':forecast,
                         'absolute_error_nzd':abs(actual-forecast),'signed_error_nzd':forecast-actual,
                         'square_error_nzd2':(forecast-actual)**2,
                         'APE_percent':100*abs(actual-forecast)/actual})
    return pd.DataFrame(rows)


def score_forecasts(pred):
    return (pred.groupby(['phase','model'],as_index=False)
            .agg(n=('absolute_error_nzd','size'),MAE_nzd=('absolute_error_nzd','mean'),
                 MSE=('square_error_nzd2','mean'),MAPE_percent=('APE_percent','mean'),
                 mean_signed_error_nzd=('signed_error_nzd','mean'))
            .assign(RMSE_nzd=lambda x:np.sqrt(x.MSE))
            .drop(columns=['MSE']))


def choose_from_validation(scores):
    v=scores[scores.phase=='validation'].sort_values(['MAE_nzd','RMSE_nzd','model']).reset_index(drop=True)
    if len(v)==0:raise ValueError('Missing validation data')
    return str(v.loc[0,'model'])


def fixed_origin_forecast(y,models=('Naive (last month)','Seasonal naive (12m)'),origin_train_months=24,horizon=6):
    # At December 2025 origin, predict Jan-Jun2026 without consulting ANY 2026 labels.
    hist=np.asarray(y.iloc[:origin_train_months],float)
    actual=np.asarray(y.iloc[origin_train_months:origin_train_months+horizon],float)
    if len(actual)!=horizon:raise ValueError('bad fixed horizon')
    rows=[]
    for name in models:
        if name=='Naive (last month)':fc=np.repeat(hist[-1],horizon)
        elif name=='Seasonal naive (12m)':fc=hist[-12:][:horizon]
        elif name=='SES':
            with warnings.catch_warnings():
                warnings.simplefilter('ignore')
                fc=np.asarray(SimpleExpSmoothing(hist,initialization_method='estimated').fit().forecast(horizon),float)
        elif name=='Holt damped trend':
            with warnings.catch_warnings():
                warnings.simplefilter('ignore')
                fc=np.asarray(Holt(hist,damped_trend=True,initialization_method='estimated').fit().forecast(horizon),float)
        else:raise KeyError(name)
        for i,(a,p) in enumerate(zip(actual,fc)):
            rows.append({'month':str(y.index[origin_train_months+i].date()),'model':name,
                         'forecast_origin':str(y.index[origin_train_months-1].date()),
                         'actual_nzd':float(a),'forecast_nzd':float(p),'absolute_error_nzd':abs(float(a-p))})
    return pd.DataFrame(rows)
