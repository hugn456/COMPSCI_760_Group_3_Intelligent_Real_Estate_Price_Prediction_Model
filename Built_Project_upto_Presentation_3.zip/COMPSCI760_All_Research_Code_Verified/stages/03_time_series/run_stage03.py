"""Stand-alone COMPSCI 760 Stage 3: forecast Auckland monthly median sale prices.

No teammate notebook execution or modifications.  Outputs monthly aggregates only.
"""
import argparse,json,sys
from pathlib import Path
import numpy as np
import pandas as pd
sys.path.insert(0,str(Path(__file__).resolve().parent/'src'))
from stage03_core import (read_verified_source,reproduce_teammate_eligibility,monthly_series,
    month_features,adf_diagnostics,walk_forward,score_forecasts,choose_from_validation,
    fixed_origin_forecast,DATA_HASH,NOTEBOOK_HASH,MODELS)


def run(dataset,notebook,outdir):
    out=Path(outdir);out.mkdir(parents=True,exist_ok=True)
    raw=read_verified_source(dataset,notebook)
    eligible,counts=reproduce_teammate_eligibility(raw)
    if counts.get('LINZ matched')!=59798:
        raise ValueError('Teammate source cohort mismatch: eligible transaction count is not 59,798')
    months,summary=monthly_series(eligible)
    if len(months)!=30 or summary['included_transactions']!=59281:
        raise ValueError('Unexpected 30-month series or included sales count; abort')
    months.to_csv(out/'monthly_median_series.csv',float_format='%.5f')
    lagged=month_features(months)
    lagged.to_csv(out/'past_only_monthly_market_features.csv',float_format='%.7f')
    diag=adf_diagnostics(months.median_price_nzd)
    (out/'stationarity_acf_pacf.json').write_text(json.dumps(diag,indent=2))
    predictions=walk_forward(months.median_price_nzd)
    predictions.to_csv(out/'walk_forward_one_step_forecasts.csv',index=False,float_format='%.6f')
    scores=score_forecasts(predictions)
    scores.to_csv(out/'forecast_model_comparison.csv',index=False,float_format='%.5f')
    winner=choose_from_validation(scores)
    strict=predictions.query('model==@winner')
    selected=scores.query('model==@winner')
    fixed=fixed_origin_forecast(months.median_price_nzd,models=['Naive (last month)','Seasonal naive (12m)','SES','Holt damped trend'])
    fixed.to_csv(out/'fixed_origin_six_month_forecasts.csv',index=False,float_format='%.6f')
    manifest={'source_sha256':DATA_HASH,'teammate_notebook_sha256':NOTEBOOK_HASH,'teammate_notebook_modified':False,
        'stage':'03, new independent time-series forecasting of original teammate cohort',
        'cohort_selection_counts':counts,'series_summary':summary,
        'target':'unadjusted monthly median of gross sold price NZD, not a quality-adjusted house price index',
        'included_months':[str(months.index.min().date()),str(months.index.max().date())],
        'excluded_months':['2026-07','2026-08'],
        'excluded_why':'July and August 2026 have unusually sparse recorded sales (490 and 27 respectively); likely incomplete data coverage, exclusion is an analyst Stage3 decision, not a teammate rule.',
        'split':{'training':'2024-01 through 2025-06: 18 months',
                 'validation':'2025-07 through 2025-12: 6 months',
                 'test':'2026-01 through 2026-06: 6 months',
                 'evaluation':'walk forward one-step, refit on all previously observed months each origin'},
        'model_selection':'lowest validation MAE; test not consulted',
        'winner':winner,
        'feature_availability':'lag features use completed prior months only; public sale reporting lags are not recorded and could affect deployability',
        'fixed_origin':'6-step Jan-Jun2026 forecasting using only data observed by December 2025; separate from one-step walk forward',
        'evaluation_limits':['only 30 monthly observations; 6 validation and 6 test origins',
          'monthly sale mix changes across time; median series is not a repeat-sales index',
          'no final claims of seasonality significance from two annual cycles',
          'no changes or retraining to official team XGBoost','no future actual monthly information enters a month-t one-step forecast'],
        'stage3_feature_extension':'past-only market feature table is supplied separately for a future independent property-level pilot; it has not been inserted into the official team XGBoost'}
    (out/'experiment_manifest.json').write_text(json.dumps(manifest,indent=2))
    print('Stage 03 monthly cohort:',summary)
    print('Chosen by VALIDATION:',winner)
    print('Model scores (MAE):')
    print(scores.pivot(index='model',columns='phase',values='MAE_nzd').sort_values('validation').to_string(float_format=lambda x:f'{x:,.1f}'))
    print('Selected model hold-out:',selected.to_dict(orient='records'))
    return months,lagged,predictions,scores,fixed,manifest

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--dataset',default='/mnt/data/newest_dvrs_with_team_external.parquet')
    p.add_argument('--notebook',default='/mnt/data/XGBoost.ipynb')
    p.add_argument('--out',default='results')
    a=p.parse_args();run(a.dataset,a.notebook,a.out)
