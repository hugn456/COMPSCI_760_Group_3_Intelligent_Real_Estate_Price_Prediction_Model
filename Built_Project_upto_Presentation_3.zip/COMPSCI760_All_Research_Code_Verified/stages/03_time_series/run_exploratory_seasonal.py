"""EXPLORATORY 24-month origin seasonal models: NOT eligible for 18-month validation model selection."""
import json,warnings
from pathlib import Path
import numpy as np,pandas as pd
from statsmodels.tsa.holtwinters import ExponentialSmoothing
from statsmodels.tsa.statespace.sarimax import SARIMAX


def run(resultdir='results'):
    dest=Path(resultdir)
    d=pd.read_csv(dest/'monthly_median_series.csv',parse_dates=['month']).set_index('month')
    train=d.median_price_nzd.iloc[:24].astype(float).to_numpy()
    true=d.median_price_nzd.iloc[24:30].astype(float).to_numpy()
    outputs=[]
    with warnings.catch_warnings(record=True) as warn:
        warnings.simplefilter('ignore')
        specs={
            'Holt-Winters additive (exploratory)':lambda:ExponentialSmoothing(train,trend='add',seasonal='add',seasonal_periods=12,initialization_method='estimated').fit(optimized=True).forecast(6),
            'SARIMA (0,1,1)(0,1,0,12) (exploratory)':lambda:SARIMAX(train,order=(0,1,1),seasonal_order=(0,1,0,12),trend='n',enforce_stationarity=False,enforce_invertibility=False).fit(disp=False,maxiter=100).forecast(6)
        }
        for name,model in specs.items():
            try:
                pred=np.asarray(model(),dtype=float)
                if len(pred)!=len(true) or not np.isfinite(pred).all():raise ValueError('Invalid seasonal model forecasts')
                for j,(actual,estimate) in enumerate(zip(true,pred)):
                    outputs.append({'model':name,'month':d.index[24+j].strftime('%Y-%m-%d'),
                                    'forecast_origin':'2025-12-01',
                                    'actual_nzd':float(actual),'forecast_nzd':float(estimate),
                                    'absolute_error_nzd':float(abs(actual-estimate))})
            except Exception as exc:
                print(f'Could not fit {name}: {exc}')
    result=pd.DataFrame(outputs)
    if len(result):result.to_csv(dest/'exploratory_seasonal_models.csv',index=False)
    (dest/'exploratory_seasonal_manifest.json').write_text(json.dumps({
        'status':'EXPLORATORY, not included in model selection based on six validation months',
        'reason':'24 initial training months required for two full seasonal cycles, while core validation begins with 18.',
        'start_train':'2024-01','end_train':'2025-12','forecast':'six months 2026-01 to 2026-06 fixed-origin, no 2026 labels known at forecast creation',
        'warning':'Only two seasonal cycles; model choice or inference from test comparison would be post-hoc.'},indent=2))
    print(result.groupby('model').absolute_error_nzd.mean().round(2) if len(result) else 'No exploratory fit succeeded')
    return result

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--out',default='results');a=p.parse_args();run(a.out)
