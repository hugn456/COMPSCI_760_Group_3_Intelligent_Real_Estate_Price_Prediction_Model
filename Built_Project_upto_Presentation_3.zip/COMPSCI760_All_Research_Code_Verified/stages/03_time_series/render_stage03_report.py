"""Read Stage 03 aggregate CSVs and render standalone figures and research report.
Does not read raw transaction records or execute teammate's notebook.
"""
from pathlib import Path
import argparse,json
import numpy as np,pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from src.stage03_core import DATA_HASH, NOTEBOOK_HASH
from matplotlib.ticker import FuncFormatter,MultipleLocator


def png(fig,path):
    fig.tight_layout();fig.savefig(path,dpi=175,bbox_inches='tight');plt.close(fig)


def fmtmoney(v):return '${:,.0f}'.format(v)

def build(out='results'):
    out=Path(out);out.mkdir(exist_ok=True,parents=True)
    month=pd.read_csv(out/'monthly_median_series.csv',parse_dates=['month']).set_index('month')
    scores=pd.read_csv(out/'forecast_model_comparison.csv')
    pred=pd.read_csv(out/'walk_forward_one_step_forecasts.csv',parse_dates=['month'])
    fixed=pd.read_csv(out/'fixed_origin_six_month_forecasts.csv',parse_dates=['month'])
    diag=json.loads((out/'stationarity_acf_pacf.json').read_text())
    manifest=json.loads((out/'experiment_manifest.json').read_text())
    winner=manifest['winner']
    # Monthly price series and temporal boundary markers.
    fig,ax=plt.subplots(figsize=(11.5,4.6))
    ax.plot(month.index,month.median_price_nzd/1e6,marker='o',markersize=3.7,linewidth=1.8,label='Monthly unadjusted median price')
    ax.axvline(pd.Timestamp('2025-07-01'),ls='--',lw=1,label='Validation begins')
    ax.axvline(pd.Timestamp('2026-01-01'),ls=':',lw=1.5,label='Test begins')
    ax.set_title('Auckland monthly median gross sale price — teammate-eligible transactions',fontweight='bold')
    ax.set_ylabel('Median price (NZ$ millions)');ax.set_xlabel('Sale month')
    ax.grid(alpha=.25);ax.legend(loc='best',fontsize=8)
    png(fig,out/'fig01_auckland_monthly_median.png')
    # Model selection with both phases (selected by validation not the test phase).
    pivot=scores.pivot(index='model',columns='phase',values='MAE_nzd').sort_values('validation')
    fig,ax=plt.subplots(figsize=(12.0,5.4))
    x=np.arange(len(pivot));w=.36
    ax.bar(x-w/2,pivot.validation.values/1000,width=w,label='Validation MAE')
    ax.bar(x+w/2,pivot.test.values/1000,width=w,label='Test MAE')
    ax.set_xticks(x);ax.set_xticklabels(pivot.index,rotation=23,ha='right',fontsize=9)
    ax.set_ylabel('MAE (NZ$ thousands)')
    ax.set_title('Walk-forward forecasts — validation-selected comparison',fontweight='bold')
    ax.grid(axis='y',alpha=.25);ax.set_axisbelow(True);ax.legend()
    png(fig,out/'fig02_validation_test_mae.png')
    # Holdout actual vs two baselines: note seasonal naive includes actual previous year's month.
    chosen=pred.query('phase=="test" and model==@winner').sort_values('month')
    naive=pred.query('phase=="test" and model=="Naive (last month)"').sort_values('month')
    fig,ax=plt.subplots(figsize=(10.2,4.7))
    ax.plot(chosen.month,chosen.actual_nzd/1000,'o-',label='Observed 2026 monthly median',linewidth=2)
    ax.plot(chosen.month,chosen.forecast_nzd/1000,'s--',label='Selected seasonal naive forecast',linewidth=1.8)
    ax.plot(naive.month,naive.forecast_nzd/1000,'d:',label='Naive previous-month forecast')
    ax.set_title('Held-out January–June 2026: actual vs one-step forecasts',fontweight='bold')
    ax.set_ylabel('NZ$ thousands');ax.grid(alpha=.25);ax.legend(fontsize=9)
    png(fig,out/'fig03_test_predictions.png')
    # Monthly counts and reporting completeness caution.
    fig,ax=plt.subplots(figsize=(11.2,3.8))
    ax.bar(month.index,month.n_sales,width=23)
    ax.set_title('Eligible transactions included in each complete month',fontweight='bold')
    ax.set_ylabel('Number of completed sales');ax.grid(axis='y',alpha=.25)
    png(fig,out/'fig04_monthly_transactions.png')
    # Raw ACF/PACF only from training months; not high-confidence annual-season evidence.
    fig,axes=plt.subplots(1,2,figsize=(9.9,3.7))
    for axis,lab in zip(axes,['acf_raw','pacf_raw']):
        vals=diag[lab][1:]
        axis.bar(np.arange(1,len(vals)+1),vals)
        axis.axhline(0,linewidth=1)
        axis.set_title(lab.split('_')[0].upper()+' — initial 18-month training set')
        axis.set_xticks(range(1,7));axis.set_xlabel('Lag in months');axis.set_ylim(-1,1)
        axis.grid(axis='y',alpha=.22)
    png(fig,out/'fig05_training_acf_pacf.png')
    # RQ3 lag pilot figures only if it completed successfully.
    pilot=None
    if (out/'rf_historical_feature_pilot_summary.csv').is_file():
        pilot=pd.read_csv(out/'rf_historical_feature_pilot_summary.csv')
        va=pilot.query('evaluation_scope=="all_sales"').pivot(index='phase',columns='feature_set',values='weighted_MAE_nzd')
        if not va.empty:
            fig,ax=plt.subplots(figsize=(8.3,4.6))
            pos=np.arange(len(va));width=.36
            ax.bar(pos-width/2,va.original_augmented/1000,width,label='RF original augmented features')
            ax.bar(pos+width/2,va.original_augmented_plus_past_market/1000,width,label='RF with past-only market features')
            ax.set_xticks(pos);ax.set_xticklabels([x.title() for x in va.index])
            ax.set_ylabel('Weighted MAE (NZ$ thousands)')
            ax.set_title('Independent RF lag-feature experiment (NOT teammate XGBoost)',fontweight='bold')
            ax.grid(axis='y',alpha=.25);ax.set_axisbelow(True);ax.legend(fontsize=8)
            png(fig,out/'fig06_rf_lag_feature_pilot.png')
    # report text
    tablelines=['| Model | Validation MAE | Test MAE | Test RMSE |','|---|---:|---:|---:|']
    for name,row in pivot.iterrows():
        t=scores.query('phase=="test" and model==@name').iloc[0]
        bold='**' if name==winner else ''
        tablelines.append(f'| {bold}{name}{bold} | {bold}{fmtmoney(row.validation)}{bold} | {bold}{fmtmoney(row.test)}{bold} | {fmtmoney(t.RMSE_nzd)} |')
    winner_test=scores.query('phase=="test" and model==@winner').iloc[0]
    winner_val=scores.query('phase=="validation" and model==@winner').iloc[0]
    ffix=fixed.groupby('model').absolute_error_nzd.mean().sort_values()
    fixed_table='\n'.join(f'| {k} | {fmtmoney(v)} |' for k,v in ffix.items())
    exploratory_table=''
    if (out/'exploratory_seasonal_models.csv').exists():
        exp=pd.read_csv(out/'exploratory_seasonal_models.csv')
        exp_scores=exp.groupby('model').absolute_error_nzd.mean().sort_values()
        exploratory_table='\n'.join(f'| {name} | {fmtmoney(value)} |' for name,value in exp_scores.items())
    monthly_table='\n'.join(f'| {pd.Timestamp(i).strftime("%b %Y")} | {int(row.n_sales):,} | {fmtmoney(row.median_price_nzd)} |' for i,row in month.iterrows())
    forecast_table='\n'.join(f'| {row.month.strftime("%b %Y")} | {fmtmoney(row.actual_nzd)} | {fmtmoney(row.forecast_nzd)} | {fmtmoney(row.absolute_error_nzd)} |' for row in chosen.itertuples(index=False))
    adf_raw=diag['raw'].get('p_value');adf_diff=diag['first_difference'].get('p_value')
    pilot_summary='''The optional property-level Random Forest lag-feature pilot has not completed yet; its results should not be inferred from the monthly forecasting result.'''
    if pilot is not None:
        p=pilot.query('evaluation_scope=="all_sales"').pivot(index='phase',columns='feature_set',values='weighted_MAE_nzd')
        if len(p)==2:
            pv=p.loc['validation'];pt=p.loc['test']
            delta=float(pt.original_augmented_plus_past_market-pt.original_augmented)
            improvement='lower' if delta<0 else 'higher'
            pilot_summary=(f'We ran a separate **independent Random Forest** companion pilot using 2025 February–September as the initial training period, rolling monthly updates through validation in October–December 2025 and testing in January–June 2026. The *all eligible sales* weighted MAEs for RF without versus with the historical features were **{fmtmoney(pv.original_augmented)} vs {fmtmoney(pv.original_augmented_plus_past_market)} on validation**, and **{fmtmoney(pt.original_augmented)} vs {fmtmoney(pt.original_augmented_plus_past_market)} on test**. The historical-feature version was {fmtmoney(abs(delta))} {improvement} in test MAE. These are results from an independently trained RF experiment and **do not test changes to the teammate’s XGBoost**. The pilot assumes past-month completed sales prices are available before the next month begins, but actual reporting delays are unknown.')
    report=f'''# Stage 3 — Time Series Forecasting: Auckland Property Market (COMPSCI 760)

## Scope and relationship to the group project

This is an **independent Stage 3 contribution**, designed to address **RQ3:** *How accurately can historical Auckland housing transactions forecast monthly market prices, and does incorporating historical market information improve individual property-price predictions?* The original teammate `XGBoost.ipynb` is treated as an **unchanged reference**: it is neither executed, edited, nor retrained here. Stage 2's official model-selection findings are separate from these monthly results.

## 1. Data, cohort and monthly target

The shared source dataset contains **92,010 transactions**. Applying the original notebook's six sales-eligibility rules in the same order produces **59,798 eligible transactions**, without changing the raw source. The dataset covers January 2024 through August 2026. We exclude the sparsely recorded **July (490 eligible sales)** and **August (27 eligible sales)** 2026 months from primary forecasting, leaving **59,281 transactions over 30 complete monthly observations (January 2024–June 2026)**. In particular, June 2026 contains **1,285 sales**; the more recent months are suspiciously sparse, so comparisons using them as complete monthly observations could be misleading.

The prediction target is the **median observed gross property sale price in NZ dollars** per calendar month. This monthly median is not a hedonic index: changes in the mix of properties sold (size, location, type) can move it even if quality-adjusted house prices are unchanged.

![Monthly price history](fig01_auckland_monthly_median.png)

![Eligible monthly sales counts](fig04_monthly_transactions.png)

## 2. Training chronology and no-leakage evaluation

We reserve January 2024–June 2025 (**18 months**) for initial training, July–December 2025 (**6 months**) for validation, and January–June 2026 (**6 months**) for the final test. The primary evaluation is **expanding-window, one-step-ahead prediction**: for each target month, the model fits exclusively to past monthly values, predicts the next month, then updates before the following month's forecast. There are only six independent monthly test targets; property-sale counts cannot be treated as 59,281 independent forecasting test cases.

Forecasting models evaluated are last-month naive, **12-month seasonal naive**, 3-month rolling mean, simple exponential smoothing (SES), Holt damped trend, and three ARIMA orders `(0,1,1)`, `(1,1,0)`, `(1,1,1)`. Each model is fitted at each forecast origin, and **the model is selected exclusively by minimum validation MAE**. No property-level ML model is edited or used to generate these monthly forecasts.

## 3. Stationarity and time dependence

The training-only Augmented Dickey–Fuller (ADF) test gives **p = {adf_raw:.4f} on the raw initial 18-month series**, and **p = {adf_diff:.4f} after first differencing**. The raw training sample rejects the ADF unit-root null at 5%, although the very short series makes this statistical evidence fragile. The test does not prove perfect stationarity; changing property mix and uncertain seasonal patterns remain. ARIMA differencing models are included as alternatives, not because differencing was unambiguously required. The figure below shows the first six training-set ACF/PACF lags; lag 12 is not estimable reliably from just 18 initial months.

![Training ACF/PACF](fig05_training_acf_pacf.png)

## 4. One-step forecast comparisons

{chr(10).join(tablelines)}

![Forecasting model validation/test MAE](fig02_validation_test_mae.png)

**Validation winner: {winner}**, with a **validation MAE of {fmtmoney(winner_val.MAE_nzd)}** and **held-out test MAE of {fmtmoney(winner_test.MAE_nzd)}**. On test, its RMSE is **{fmtmoney(winner_test.RMSE_nzd)}** and MAPE **{winner_test.MAPE_percent:.2f}%**. This is evidence of useful yearly repeating levels in this *specific* 30-month dataset, not proof of a stable seasonal causal structure or generalisation to longer periods.

### Selected model's six held-out one-step forecasts

| Target month | Actual monthly median | Forecast | Absolute error |
|---|---:|---:|---:|
{forecast_table}

![Held-out monthly forecast vs actual](fig03_test_predictions.png)

## 5. Realistic fixed-origin 6-month forecast

A separate six-step evaluation was conducted from **December 2025**, asking each model to forecast all six months January–June 2026 **without seeing any 2026 actual monthly medians**. This differs from rolling one-step prediction, which can use newly observed earlier test months for later test-month forecasts.

| Fixed-origin method | Six-month MAE |
|---|---:|
{fixed_table}

The seasonal naive method can use the corresponding six monthly values from 2025 that are all known at this December 2025 forecast origin. These fixed-origin results therefore provide a useful check that its performance is not entirely dependent on frequent within-test retraining.

As exploratory additional analyses, Holt–Winters additive smoothing and SARIMA seasonal forecasting are fitted only after **24 months (through December 2025)**, so they are **not eligible for selection using the six 2025 validation months**. Their January–June 2026 results are recorded below (and in `exploratory_seasonal_models.csv`) and must not be presented as a validation-selected win over our chosen method. With only two annual cycles, seasonal parameter estimation is uncertain.

| Exploratory fixed-origin seasonal model | January–June 2026 MAE |
|---|---:|
{exploratory_table}

## 6. RQ3: historical market context for property valuation

For later property-price sensitivity testing, we created a separate monthly feature table: lagged medians at 1, 2, 3, 6 and 12 months, 3/6-month trailing statistics, month-over-month momentum, a previous-month year-over-year measure (where at least 13 historical months exist), and lagged monthly sale counts. All price and volume predictors for month *t* use observations **strictly before month t**; the current month median is never used as a predictor. The features are released as `past_only_monthly_market_features.csv` and are **not inserted into the original teammate XGBoost**.

{pilot_summary}

## 7. Interpretation, threats to validity, and group hand-off

The main RQ3 result is that *historical sale prices provide a strong simple forecast benchmark for Auckland's unadjusted monthly transaction medians*. A 12-month seasonal naive predictor was strongest by pre-specified validation MAE. The conclusion concerns **market-level monthly medians**, not property-level XGBoost performance. The independent historical-feature experiment (if complete) adds information on **the RF companion only**.

The most important limitations are: only 30 months, just six monthly held-out targets, aggregate-sale composition shifts, possible missing late-reporting transactions even before July, and unknown publication delays for sale prices. Although the lag feature calculations themselves have no forward-looking month inputs, a real-time system would need verified release timestamps before assuming every completed sale was available by the next month. The original team model's fixed code and results remain untouched throughout.

## Reproducibility and outputs

Dataset SHA-256: `{DATA_HASH}`. Original notebook SHA-256: `{NOTEBOOK_HASH}`. The source dataset and notebook are read-only and excluded from the downloadable Stage 3 package. Reproduction instructions and source-exclusion guidelines are in `README.md`. Figures and aggregate monthly outputs are included, subject to any applicable Council data-sharing terms.
'''
    (out/'STAGE03_RESEARCH_REPORT.md').write_text(report,encoding='utf-8')
    print('Rendered report, figures; pilot present =',pilot is not None)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--out',default='results');a=p.parse_args();build(a.out)
