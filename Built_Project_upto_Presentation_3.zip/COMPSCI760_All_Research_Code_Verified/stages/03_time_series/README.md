# Stage 3 — Time Series Forecasting

Evaluates an unadjusted monthly sale-price median using 30 complete months. Chooses a forecasting model on six validation months and evaluates it on six separate test months. A historical-feature Random Forest sensitivity study is included.

**Primary outputs:** monthly series, chronological forecasts, model comparison, fixed-origin predictions and figures.

**Run:** `python project.py run 3 --dataset PATH --notebook PATH` reproduces the main monthly comparison. Optional analyses are available in `run_exploratory_seasonal.py` and `run_historical_feature_pilot.py`.

**Interpretation:** Seasonal-naive test MAE NZ$9,500 over six monthly test observations; not a property-level valuation score.

Reproduction details and project-wide safeguards are in the repository-level `README.md`.
