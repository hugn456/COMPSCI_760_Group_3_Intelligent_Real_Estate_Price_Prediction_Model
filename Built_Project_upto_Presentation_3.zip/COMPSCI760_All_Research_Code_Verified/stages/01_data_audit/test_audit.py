"""Lightweight guard checks for the unified Stage 1 audit."""
from pathlib import Path
import importlib.util
import json
import ast

ROOT = Path(__file__).resolve().parents[2]

def test_sources_pinned():
    sources = json.loads((ROOT / 'source_manifest.json').read_text())
    assert sources['dataset']['sha256'] == '07e5e22ea8c6f73b82477b023f5803961b7ba730f9a7474cbb55a27a2c0fb3b2'
    assert sources['original_xgboost_notebook']['sha256'] == '21d388340231d149109195ca0498533de28b33e692c73e6a965ce6a6c62d7057'

def test_no_source_mutation_or_exported_individual_sales():
    src=(Path(__file__).parent/'audit.py').read_text()
    ast.parse(src)
    assert 'to_csv' not in src
    assert 'XGBRegressor' not in src
