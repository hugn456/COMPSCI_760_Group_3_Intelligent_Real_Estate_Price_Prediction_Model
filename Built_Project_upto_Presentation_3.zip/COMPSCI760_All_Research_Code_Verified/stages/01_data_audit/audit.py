"""Stage 1: reproducible audit of the shared Auckland transaction dataset.

The same six source filters are implemented once in Stage 3 and reused here.
This module produces aggregate counts only; no transaction rows are exported.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import pandas as pd

PROJECT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(PROJECT / "stages" / "03_time_series" / "src"))
sys.path.insert(0, str(PROJECT))
from stage03_core import (DATA_HASH, NOTEBOOK_HASH, sha256,
                          reproduce_teammate_eligibility)
from common.parquet_readonly import read_parquet

def audit(dataset: Path, notebook: Path) -> dict:
    dataset, notebook = Path(dataset), Path(notebook)
    if sha256(dataset) != DATA_HASH or sha256(notebook) != NOTEBOOK_HASH:
        raise ValueError("Source integrity mismatch: dataset/notebook must be unchanged")
    # Audit the full source schema; the eligibility calculation remains the
    # same six filters used by the project forecasting and modelling code.
    try:
        raw = pd.read_parquet(dataset)
    except ImportError:
        raw = read_parquet(dataset)
    eligible, stages = reproduce_teammate_eligibility(raw)
    missing = {column: int(eligible[column].isna().sum()) for column in raw.columns}
    worst = sorted(missing.items(), key=lambda item: (-item[1], item[0]))
    nonzero_missing = {column: n for column, n in worst if n > 0}
    prices = pd.to_numeric(eligible.sale_price_gross, errors="coerce")
    quintiles = prices.quantile([0.01, 0.50, 0.99])
    if "valuation_id_concat" in eligible:
        keys = eligible.valuation_id_concat.dropna().astype(str)
        repeat_ids = int(keys.value_counts().gt(1).sum())
    else:
        repeat_ids = None
    report = {
        "original_rows": int(len(raw)),
        "source_columns": int(raw.shape[1]),
        "eligibility_counts": {k: int(v) for k, v in stages.items()},
        "eligible_rows": int(len(eligible)),
        "eligible_date_min": str(eligible.sale_date_parsed.min().date()),
        "eligible_date_max": str(eligible.sale_date_parsed.max().date()),
        "columns_with_missing_values": len(nonzero_missing),
        "largest_missing_counts_eligible": dict(list(nonzero_missing.items())[:15]),
        "missing_values_by_column_eligible": missing,
        "eligible_sale_price_quantiles_nzd": {
            "p01": float(quintiles.loc[0.01]),
            "median": float(quintiles.loc[0.50]),
            "p99": float(quintiles.loc[0.99])
        },
        "property_identifiers_with_multiple_transactions": repeat_ids,
        "coordinate_complete_sales": int(eligible[["latitude", "longitude"]].notna().all(axis=1).sum()),
        "limitations": [
            "Missing hazard layers do not necessarily imply absence of risk.",
            "The source is a snapshot; effective as-of-sale availability is unverified.",
            "Source filtering is reproduced for consistency, not modified."
        ],
        "dataset_sha256": DATA_HASH,
        "notebook_sha256": NOTEBOOK_HASH
    }
    if int(len(raw)) != 92010 or int(len(eligible)) != 59798:
        raise ValueError("Unexpected source or eligible-cohort size")
    return report

def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset", type=Path, required=True)
    parser.add_argument("--notebook", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    output = audit(args.dataset, args.notebook)
    args.out.mkdir(parents=True, exist_ok=True)
    (args.out / "dataset_audit.json").write_text(json.dumps(output, indent=2) + "\n")
    print(f"Stage 1: {output['original_rows']:,} source rows; "
          f"{output['eligible_rows']:,} eligible rows. See {args.out / 'dataset_audit.json'}")

if __name__ == "__main__":
    main()
