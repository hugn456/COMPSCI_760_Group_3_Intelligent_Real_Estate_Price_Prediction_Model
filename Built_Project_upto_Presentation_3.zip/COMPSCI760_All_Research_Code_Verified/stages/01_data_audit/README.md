# Stage 1 — Data Cleaning and Audit

Verifies source hashes, reproduces the six transaction eligibility filters, and summarises missingness across 57 physical Parquet fields (including a stored index), sale-price distributions, repeat-property counts and coordinate coverage. No individual-sale records are shared.

**Run:** `python project.py run 1 --dataset PATH --notebook PATH`

**Output:** `local_runs/stage01/dataset_audit.json` and a verified aggregate snapshot in `results/dataset_audit.json`. The source data and XGBoost notebook remain read-only.

Reproduction details and project-wide safeguards are in the repository-level `README.md`.
