"""Read-only cohort reconstruction from frozen teammate notebook; NO ML training.

Reuses teammates' stated notebook cohort, preprocessing, chronological TimeSeriesSplit
(n_splits=5), 1st–99th percentile train-derived price trimming, and evaluation rows.

The official XGBoost metrics are extracted from source notebook (unaltered).
No source model training is defined in this module.
"""
from __future__ import annotations
import hashlib
from pathlib import Path
import pandas as pd
import numpy as np

# Original lists, copied verbatim from teammates notebook cell 45 into companion code.
BASELINE_CAT = ['zoning','building_age_indicator','building_condition_indicator',
    'building_construction_indicator','mass_contour','mass_view','mass_scope_of_view',
    'mass_deck','mass_workshop_laundry','mass_other_improvements',
    'property_type','actual_property_use']
BASELINE_NUM = ['land_area','building_total_floor_area','mass_total_floor_area',
    'building_site_coverage','off_street_parking', 'mass_garage_under_main_roof',
    'mass_garage_freestanding','sale_year','sale_month','sale_quarter']
EXTERNAL_CAT = ['unitary_plan_zone','noise_category_combination']
EXTERNAL_NUM = ['longitude','latitude','dist_to_flood_plain_m',
    'dist_to_flood_sensitive_area_m','sa2_new_dwellings_consented_12m',
    'walk_supermarket_network_m','walk_bus_stop_network_m']
EXTERNAL_BOOL = ['in_flood_plain','in_flood_sensitive_area','has_flood_risk','in_noise_overlay']
LOG_COLS=['land_area','building_total_floor_area','mass_total_floor_area',
    'walk_supermarket_network_m','walk_bus_stop_network_m']
ALL_CAT=BASELINE_CAT+EXTERNAL_CAT
ALL_NUM=BASELINE_NUM+EXTERNAL_NUM
BASELINE=BASELINE_CAT+BASELINE_NUM
AUGMENTED=BASELINE+EXTERNAL_CAT+EXTERNAL_NUM+EXTERNAL_BOOL
NOTEBOOK_SHA='21d388340231d149109195ca0498533de28b33e692c73e6a965ce6a6c62d7057'
DATA_SHA='07e5e22ea8c6f73b82477b023f5803961b7ba730f9a7474cbb55a27a2c0fb3b2'

def sha256(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for chunk in iter(lambda:f.read(1<<20),b''):h.update(chunk)
    return h.hexdigest()

def date_parser(s):
    # Deliberately identical to teammate's cell 10, rather than 'corrected'.
    if pd.isna(s):return pd.NaT
    s=str(s);year=int(s[-4:]);month=int(s[-6:-4]);day=int(s[:-6])
    return pd.Timestamp(year=year,month=month,day=day)

def prepare(df):
    """Notebook cells 4, 10, 39, 43, 45: same method, no change to original file."""
    df=df.drop(columns=['__index_level_0__'],errors='ignore').copy()
    df=df.drop(columns=['sale_price_net','sale_price_chattels','sale_price_other',
                        'capital_value','land_value'])
    df['sale_date_parsed']=df.sale_date.apply(date_parser)
    for c in ['sale_price_gross','land_area','building_total_floor_area',
              'mass_total_floor_area','building_site_coverage','off_street_parking',
              'units_of_use','mass_garage_under_main_roof','mass_garage_freestanding',
              'longitude','latitude']:
        df[c]=pd.to_numeric(df[c],errors='coerce')
    for c in ['walk_supermarket_network_m','drive_supermarket_network_m',
              'walk_bus_stop_network_m','drive_bus_stop_network_m',
              'sa2_new_dwellings_consented_12m']:
        df[c]=df[c].astype(float)
    for c in ['in_flood_plain','in_flood_sensitive_area']:
        df[c]=df[c].astype('boolean')
    df=df.drop(columns=['drive_supermarket_network_m','drive_bus_stop_network_m'])
    counts={'source_rows':len(df)}
    filters=[
     ('zoning_912',df['zoning'].astype(str).str[0].isin(['9','1','2'])),
     ('one_unit',df['units_of_use']==1),
     ('freehold',df['sale_tenure'].astype(str)=='1'),
     ('sale_type_S',df['sale_type']=='S'),
     ('relationship_1',df['price_value_relationship']=='1'),
     ('linz_matched',df['linz_matched'].astype(bool)),
    ]
    for name,mask in filters:
        df=df.loc[mask].copy()
        counts[name]=len(df)
    # Preserve notebook ordering algorithm: default pandas sort kind, no sorting revision.
    df=df.sort_values('sale_date_parsed').reset_index(drop=True)
    df['property_type']=df['property_category'].str[0]
    df['sale_year']=df.sale_date_parsed.dt.year
    df['sale_month']=df.sale_date_parsed.dt.month
    df['sale_quarter']=df.sale_date_parsed.dt.quarter
    df['has_flood_risk']=df['in_flood_plain'] | df['in_flood_sensitive_area']
    df['in_noise_overlay']=df['noise_category_combination']!='outside_current_overlay'
    df['unitary_plan_zone']=df['unitary_plan_zone'].fillna(-1).astype(int).astype(str)
    for c in ALL_CAT:df[c]=df[c].fillna('Unknown').astype(str)
    for c in LOG_COLS:df[c]=np.log1p(df[c])
    assert len(df)==59798, f'Team filtered rows 59,798, got {len(df)}. STOP — cohort mismatch.'
    assert len(BASELINE)==22 and len(AUGMENTED)==35
    assert 'capital_value' not in df.columns and 'land_value' not in df.columns
    assert df['has_flood_risk'].notna().all()
    return df,counts
