"""Supplementary hedonic baselines and robustness checks, NEVER trains teammate XGBoost.

Uses exactly the same source eligibility and row-time splits as the fixed team
notebook, with target-trimmed OOF metrics labelled as conditional on known Y.
All other models are independent companions; never claim original XGB paired tests.
"""
from __future__ import annotations
import hashlib, sys, json
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.model_selection import TimeSeriesSplit
from sklearn.preprocessing import OneHotEncoder,StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.linear_model import Ridge
from sklearn.metrics import mean_absolute_error,mean_squared_error,r2_score
from lightgbm import LGBMRegressor

# Retain team cohort logic as the unmodified independent adapter from earlier Stage 2.
from teammate_cohort_adapter import prepare, AUGMENTED, BASELINE, ALL_CAT, ALL_NUM, EXTERNAL_BOOL, DATA_SHA,NOTEBOOK_SHA
from parquet_readonly import read_parquet

HEDONIC_CAT=['zoning_group','building_age_indicator','building_condition_indicator','property_type']
HEDONIC_NUM=['land_area','building_total_floor_area','building_site_coverage',
             'off_street_parking','mass_garage_under_main_roof','sale_year','longitude','latitude','has_flood_risk']

LGBM_PARAMS={'n_estimators':450,'num_leaves':31,'learning_rate':.04,
             'min_child_samples':22,'max_depth':-1,'colsample_bytree':.8,
             'reg_lambda':2,'verbosity':-1,'random_state':42,'n_jobs':2}


def sha256(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()


def load_verified(dataset,notebook):
    if sha256(dataset)!=DATA_SHA or sha256(notebook)!=NOTEBOOK_SHA:
        raise ValueError('Frozen original source changed; integration stopped')
    try:raw=pd.read_parquet(dataset)
    except ImportError:raw=read_parquet(dataset)
    # Extra columns for independent audit only. The original teammate notebook drops
    # capital_value and has no predictors using any reference valuation information.
    raw['capital_value_reference']=pd.to_numeric(raw['capital_value'],errors='coerce')
    raw['valuation_effective_serial_reference']=pd.to_numeric(raw['current_effective_valuation_date'],errors='coerce')
    raw['source_pos_reference']=np.arange(len(raw))
    d,counts=prepare(raw)
    d['row_id']=np.arange(len(d))
    d['zoning_group']=d.zoning.astype(str).str[0]
    d['valuation_effective_date_reference']=pd.to_datetime(d.valuation_effective_serial_reference,unit='D',origin='1899-12-30',errors='coerce')
    d['property_key']=d.valuation_id_concat.astype(str)
    return d,counts


def score(y,p):
    y=np.asarray(y,dtype=float);p=np.asarray(p,dtype=float)
    if len(y)==0 or len(y)!=len(p) or not np.isfinite(y).all() or not np.isfinite(p).all():
        raise ValueError('Bad evaluation arrays')
    return {'n':int(len(y)),'MAE':float(mean_absolute_error(y,p)),
            'RMSE':float(np.sqrt(mean_squared_error(y,p))),
            'MAPE_pct':float(np.mean(np.abs(y-p)/y)*100),
            'R2':float(r2_score(y,p)) if len(y)>1 else None,
            'mean_signed_error':float(np.mean(p-y))}


def train_quantile_filter(ytrain,ytest):
    low,high=np.quantile(ytrain,[.01,.99])
    return (ytrain>=low)&(ytrain<=high),(ytest>=low)&(ytest<=high),(float(low),float(high))


def design(train,test,kind):
    if kind=='Hedonic Ridge (compact)':
        cat=HEDONIC_CAT
        num=HEDONIC_NUM
    elif kind=='Hedonic Ridge (augmented)':
        cat=ALL_CAT
        num=[c for c in AUGMENTED if c not in cat]
    else:raise KeyError(kind)
    def xform(rows):
        x=rows[cat+num].copy()
        for c in cat:x[c]=x[c].astype('string').fillna('Unknown').astype(str)
        for c in num:x[c]=pd.to_numeric(x[c],errors='coerce')
        return x
    transform=ColumnTransformer([
        ('num',Pipeline([('imputer',SimpleImputer(strategy='median')),
                         ('scaler',StandardScaler())]),num),
        ('cat',OneHotEncoder(handle_unknown='ignore',min_frequency=3),cat),
    ],remainder='drop',sparse_threshold=.7)
    return xform(train),xform(test),transform


def fit_log_ridge(train,test,train_mask,kind,alpha=20):
    xtr,xte,transform=design(train,test,kind)
    # Fit all imputers and categories ONLY on retained historical training rows.
    x=transform.fit_transform(xtr.iloc[np.flatnonzero(train_mask)])
    xt=transform.transform(xte)
    y=np.log(train.sale_price_gross.to_numpy(dtype=float)[train_mask])
    model=Ridge(alpha=alpha,solver='lsqr',tol=1e-5)
    model.fit(x,y)
    smear=float(np.mean(np.exp(y-model.predict(x))))
    p=np.exp(np.clip(model.predict(xt),-20,20))*smear
    if np.any(~np.isfinite(p)):raise ValueError('Nonfinite inverse log estimate')
    return p,{'smear_factor':smear,'alpha':alpha,'n_training':int(train_mask.sum()),'n_columns_after_encoding':int(x.shape[1])}


def team_style_encoded(train,test):
    """Only an independent companion LightGBM. Uses original team's inputs exactly,
    without fitting or modifying any XGBoost."""
    from sklearn.preprocessing import OrdinalEncoder
    enc=OrdinalEncoder(handle_unknown='use_encoded_value',unknown_value=-1)
    enc.fit(train[ALL_CAT])
    a=train[AUGMENTED].copy();b=test[AUGMENTED].copy()
    a[ALL_CAT]=enc.transform(train[ALL_CAT]);b[ALL_CAT]=enc.transform(test[ALL_CAT])
    for col in EXTERNAL_BOOL:
        a[col]=a[col].astype(int);b[col]=b[col].astype(int)
    a=a.astype(float);b=b.astype(float)
    med=a[ALL_NUM].median()
    a[ALL_NUM]=a[ALL_NUM].fillna(med)
    b[ALL_NUM]=b[ALL_NUM].fillna(med)
    if not np.isfinite(a.to_numpy()).all() or not np.isfinite(b.to_numpy()).all():
        raise ValueError('Missing or invalid matrix')
    return a,b


def spatial_blocks(d,resolution=.035):
    lat=pd.to_numeric(d.latitude,errors='coerce');lon=pd.to_numeric(d.longitude,errors='coerce')
    valid=lat.notna()&lon.notna()
    out=pd.Series('unlocated',index=d.index,dtype=str)
    out.loc[valid]=(np.floor(lat[valid]/resolution).astype(int).astype(str)+'_'+
                    np.floor(lon[valid]/resolution).astype(int).astype(str))
    return out


def select_spatial_holdout(train,test,min_training=20,min_test=10):
    blocks_train=spatial_blocks(train);blocks_test=spatial_blocks(test)
    train_counts=blocks_train.value_counts();test_counts=blocks_test.value_counts()
    eligible=[block for block,n in test_counts.items() if block!='unlocated' and n>=min_test and
              train_counts.get(block,0)>=min_training]
    # Deterministic block selection, approx 20% of eligible locations.
    chosen={block for block in eligible if int(hashlib.sha256(block.encode()).hexdigest()[:8],16)%5==0}
    if len(chosen)<3 and len(eligible)>=6:
        ranked=sorted(eligible,key=lambda s:hashlib.sha256(s.encode()).hexdigest())
        chosen=set(ranked[:max(3,len(ranked)//5)])
    train_mask=~blocks_train.isin(chosen)
    test_unseen=blocks_test.isin(chosen)
    if train_mask.sum()<200 or test_unseen.sum()<30 or (~test_unseen).sum()<30:
        raise ValueError('Spatial data too small for meaningful holdout')
    assert not set(blocks_train.loc[~train_mask]).isdisjoint(chosen)
    assert not set(blocks_train.loc[train_mask]).intersection(chosen)
    return train_mask.to_numpy(),test_unseen.to_numpy(),chosen


def run_hedonic_oof(d,out,alpha=20):
    scores=[];preds=[];folds=[]
    for fold,(train_idx,test_idx) in enumerate(TimeSeriesSplit(n_splits=5).split(d),1):
        train=d.iloc[train_idx];test=d.iloc[test_idx]
        yt=train.sale_price_gross.to_numpy(dtype=float);ye=test.sale_price_gross.to_numpy(dtype=float)
        trkeep,tekeep,(lo,hi)=train_quantile_filter(yt,ye)
        folds.append({'fold':fold,'n_train':len(train),'n_test':len(test),'n_test_trimmed':int(tekeep.sum()),
                      'train_end':str(train.sale_date_parsed.max().date()),
                      'test_start':str(test.sale_date_parsed.min().date()),
                      'price_quantile_lo':lo,'price_quantile_hi':hi,
                      'shared_boundary_date':str(train.sale_date_parsed.max().date())==str(test.sale_date_parsed.min().date())})
        for name in ['Hedonic Ridge (compact)','Hedonic Ridge (augmented)']:
            pred,info=fit_log_ridge(train,test,trkeep,name,alpha=alpha)
            for scope,idx in [('trimmed',np.flatnonzero(tekeep)),('all_test',np.arange(len(test)) )]:
                m=score(ye[idx],pred[idx]);scores.append({'fold':fold,'model':name,'scope':scope,**m,**info})
                if scope=='trimmed':
                    for i in idx:
                        preds.append({'row_id':int(test.row_id.iloc[i]),'fold':fold,'model':name,
                                      'actual':float(ye[i]),'prediction':float(pred[i])})
            print('Ridge fold',fold,name,'conditional MAE',round(scores[-2]['MAE']),flush=True)
    fold_df=pd.DataFrame(folds)
    metrics=pd.DataFrame(scores)
    preds=pd.DataFrame(preds)
    pool=[]
    for (name),g in preds.groupby('model'):
        pool.append({'model':name,'scope':'trimmed','source':'independent hedonic extension',**score(g.actual,g.prediction)})
    # All-test pooled scores via fold weighted errors aren't reconstructable from trim-only preds,
    # so we keep per-fold all-test scores distinct from pooled conditional figures.
    metrics.to_csv(out/'hedonic_fold_metrics.csv',index=False)
    pd.DataFrame(pool).to_csv(out/'hedonic_pooled_metrics.csv',index=False)
    fold_df.to_csv(out/'fold_registry_summary.csv',index=False)
    out_private=out.parent/'PRIVATE';out_private.mkdir(exist_ok=True)
    preds.to_csv(out_private/'hedonic_oof_predictions.csv.gz',index=False,compression='gzip')
    return metrics,pd.DataFrame(pool),fold_df,preds


def property_repeat_audit(d,out,source_pred_path):
    # Uses existing prior companion observations for original notebook test window.
    p=pd.read_csv(source_pred_path)
    p=p[(p.feature_set=='P+E') & p.model.isin(['LightGBM'])].copy()
    if p.duplicated(['fold','row_id']).any():raise ValueError('Duplicate companion predictions')
    sample=d[['row_id','property_key','sale_price_gross']].copy()
    p=p.drop(columns=['property_key'],errors='ignore')
    merged=p.merge(sample,on='row_id',validate='one_to_one')
    if not np.allclose(merged.actual,merged.sale_price_gross):raise ValueError('Companion property row labels differ')
    counts=[]
    from sklearn.model_selection import TimeSeriesSplit
    histories={i:set(d.iloc[t].property_key) for i,(t,_) in enumerate(TimeSeriesSplit(n_splits=5).split(d),1)}
    merged['seen_property_in_train']=[str(prop) in histories[int(fold)] for prop,fold in zip(merged.property_key,merged.fold)]
    for (f,grp),v in merged.groupby(['fold','seen_property_in_train']):
        counts.append({'fold':int(f),'property_previously_seen':bool(grp),**score(v.actual,v.prediction)})
    full=[]
    for g,s in merged.groupby('seen_property_in_train'):
        full.append({'property_previously_seen':bool(g),**score(s.actual,s.prediction),'n_distinct_property_keys':s.property_key.nunique()})
    pd.DataFrame(counts).to_csv(out/'repeat_property_by_fold_lightgbm.csv',index=False)
    pd.DataFrame(full).to_csv(out/'repeat_property_pooled_lightgbm.csv',index=False)
    return pd.DataFrame(full)


def run_holdout_probes(d,out):
    # 5th fold same as original team fold design; new LightGBM only.
    tr,te=list(TimeSeriesSplit(n_splits=5).split(d))[-1]
    train=d.iloc[tr];test=d.iloc[te]
    yt=train.sale_price_gross.to_numpy(float);ye=test.sale_price_gross.to_numpy(float)
    trkeep,tekeep,(lo,hi)=train_quantile_filter(yt,ye)
    xtr,xte=team_style_encoded(train,test)
    spatial_train,spatial_unseen,chosen=select_spatial_holdout(train,test)
    prop_in_test=set(test.property_key)
    property_disjoint=~train.property_key.isin(prop_in_test).to_numpy()
    probe=[];private_preds=[]
    scenarios=[('chronological_reference',trkeep),('withheld_geographic_blocks',trkeep&spatial_train),
               ('property_disjoint_training',trkeep&property_disjoint)]
    estimates={}
    for name,keep in scenarios:
        model=LGBMRegressor(**LGBM_PARAMS)
        model.fit(xtr.loc[keep],yt[keep])
        pred=model.predict(xte)
        estimates[name]=pred
        for scope,sel in [('price_trimmed',tekeep),('all_test_sales',np.ones(len(test),dtype=bool))]:
            idx=np.flatnonzero(sel)
            probe.append({'experiment':name,'scope':scope,'subgroup':'all',
                          'train_n':int(keep.sum()),'test_n':len(idx),**score(ye[idx],pred[idx])})
            if scope=='price_trimmed' and name=='withheld_geographic_blocks':
                for group,mask in [('unseen_block',spatial_unseen),('seen_or_other_block',~spatial_unseen)]:
                    chosen_idx=np.flatnonzero(sel&mask)
                    if len(chosen_idx): probe.append({'experiment':name,'scope':scope,'subgroup':group,
                        'train_n':int(keep.sum()),'test_n':len(chosen_idx),**score(ye[chosen_idx],pred[chosen_idx])})
        private_preds.append(pd.DataFrame({'row_id':test.row_id,'model':name,'actual':ye,'prediction':pred,
                                           'test_price_in_original_quantiles':tekeep,'unseen_geography':spatial_unseen}))
        print('HOLDOUT',name,'train_n',keep.sum(),'MAE',score(ye[tekeep],pred[tekeep])['MAE'],flush=True)
    pd.DataFrame(probe).to_csv(out/'robustness_holdout_experiments.csv',index=False)
    pd.concat(private_preds,ignore_index=True).to_csv(out.parent/'PRIVATE/holdout_predictions.csv.gz',compression='gzip',index=False)
    summary={'fold':5,'price_lower_1pct_nzd':lo,'price_upper_99pct_nzd':hi,
        'n_train_before_trim':len(train),'n_test_before_trim':len(test),'n_test_trimmed':int(tekeep.sum()),
        'spatial_cell_size_degrees':.035,'n_spatial_blocks_withheld':len(chosen),
        'n_test_spatial_unseen_trimmed':int((spatial_unseen&tekeep).sum()),
        'n_test_spatial_other_trimmed':int((~spatial_unseen&tekeep).sum()),
        'n_training_rows_omitted_for_spatial':int((trkeep&~spatial_train).sum()),
        'n_training_rows_omitted_for_property_disjoint':int((trkeep&~property_disjoint).sum()),
        'n_unique_test_property_ids':int(test.property_key.nunique()),
        'n_shared_train_test_property_ids':int(len(set(train.property_key).intersection(set(test.property_key)))),
        'original_cv_fold_policy_unchanged':True,'geographic_and_property_purges_apply_to_independent_LightGBM_only':True}
    (out/'robustness_design.json').write_text(json.dumps(summary,indent=2))
    return pd.DataFrame(probe),summary


def council_reference(d,out):
    rows=[]
    for fold,(tr,te) in enumerate(TimeSeriesSplit(n_splits=5).split(d),1):
        train=d.iloc[tr];test=d.iloc[te]
        trkeep,tekeep,_=train_quantile_filter(train.sale_price_gross.to_numpy(float),test.sale_price_gross.to_numpy(float))
        y=test.sale_price_gross.to_numpy(float)
        cv=test.capital_value_reference.to_numpy(float)
        effective=test.valuation_effective_date_reference
        recorded=tekeep & np.isfinite(cv) & (cv>0)
        for category,mask in [('all_positive_cv',recorded),('effective_not_later_than_sale',recorded & effective.le(test.sale_date_parsed).to_numpy())]:
            if not np.any(mask):continue
            rows.append({'fold':fold,'subset':category,**score(y[mask],cv[mask]),
                         'note':'Council CV is a reference-only comparison; effective date is NOT proof of historical publication'})
    result=pd.DataFrame(rows)
    result.to_csv(out/'council_value_reference_by_fold.csv',index=False)
    return result


def paired_companion_interval(hedonic_oof,source_pred_path,d,out,n_bootstrap=500,seed=760):
    """Matched MAE difference and cluster CI between OUR augmented Ridge and OUR LightGBM.

    No claim is made about a paired confidence interval for teammate's original XGBoost.
    """
    ridge=hedonic_oof[hedonic_oof.model=='Hedonic Ridge (augmented)'].copy()
    lgbm=pd.read_csv(source_pred_path)
    lgbm=lgbm[(lgbm.model=='LightGBM')&(lgbm.feature_set=='P+E')].copy()
    if lgbm.duplicated(['row_id','fold']).any() or ridge.duplicated(['row_id','fold']).any():
        raise ValueError('Duplicate fold/row keys prevent comparison')
    x=ridge[['row_id','fold','actual','prediction']].merge(
        lgbm[['row_id','fold','actual','prediction']],on=['row_id','fold'],how='outer',
        validate='one_to_one',indicator=True,suffixes=('_ridge','_lgbm'))
    if not (x._merge=='both').all() or len(x)!=len(ridge) or len(x)!=len(lgbm):
        raise ValueError('Model predictions not matched on identical rows/folds')
    if not np.allclose(x.actual_ridge,x.actual_lgbm,atol=.001,rtol=0):
        raise ValueError('Actual sale price targets disagree in matched data')
    keys=d[['row_id','property_key']]
    x=x.merge(keys,on='row_id',validate='one_to_one')
    x['delta_mae']=np.abs(x.prediction_ridge-x.actual_ridge)-np.abs(x.prediction_lgbm-x.actual_lgbm)
    # Group transactions belonging to repeated property IDs.
    cluster=x.groupby('property_key').delta_mae.agg(['sum','count'])
    rg=np.random.default_rng(seed)
    sums=cluster['sum'].to_numpy();sizes=cluster['count'].to_numpy()
    n=len(cluster)
    ci=[]
    for i in range(n_bootstrap):
        sample=rg.integers(0,n,size=n)
        ci.append(float(sums[sample].sum()/sizes[sample].sum()))
    result={'comparison':'OUR augmented hedonic Ridge vs OUR LightGBM (NOT original team XGBoost)',
            'n_shared_observations':len(x),'n_distinct_property_clusters':n,
            'MAE_ridge_minus_LightGBM':float(x.delta_mae.mean()),
            'cluster_bootstrap_95pct_lower':float(np.quantile(ci,.025)),
            'cluster_bootstrap_95pct_upper':float(np.quantile(ci,.975)),
            'positive_difference_means':'LightGBM has lower conditional MAE than Ridge',
            'not_original_xgboost_predictions':True}
    (out/'paired_companion_ridge_vs_lightgbm.json').write_text(json.dumps(result,indent=2))
    return result
