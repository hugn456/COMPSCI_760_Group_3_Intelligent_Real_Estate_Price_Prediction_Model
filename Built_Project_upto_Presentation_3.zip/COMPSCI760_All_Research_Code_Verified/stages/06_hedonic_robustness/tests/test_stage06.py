import sys
from pathlib import Path
import numpy as np,pandas as pd,pytest
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'src'))
from stage06_core import (score,train_quantile_filter,spatial_blocks,select_spatial_holdout,
    fit_log_ridge,team_style_encoded,HEDONIC_CAT)

def test_mae_rmse_and_signed_error():
    z=score([100,200,300],[120,190,330]);assert z['n']==3
    assert z['MAE']==20
    assert z['RMSE']==pytest.approx(np.sqrt((400+100+900)/3))
    assert z['mean_signed_error']==pytest.approx(40/3)

def test_price_trimming_only_uses_training_quantiles():
    ytrain=np.arange(100,300,dtype=float)
    ktrain,ktest,(lo,hi)=train_quantile_filter(ytrain,np.array([10,110,300000]))
    assert lo>100 and hi<299
    assert not ktest[0] and ktest[1] and not ktest[2]

def test_geographic_blocking_is_stable():
    a=pd.DataFrame({'latitude':[-36.85,-36.86,-37.05,np.nan],
                    'longitude':[174.70,174.71,175.2,175.2]})
    blocks=spatial_blocks(a)
    assert blocks.iloc[0] in str(blocks.iloc[0]);assert blocks.iloc[3]=='unlocated'
    assert len(blocks)==4

def test_no_direct_target_or_council_in_hedonic_inputs():
    assert {'sale_price_gross','capital_value','land_value'}.isdisjoint(HEDONIC_CAT)

def test_fitting_compact_hedonic_is_finite():
    rng=np.random.default_rng(83);n=75
    base=pd.DataFrame({'sale_price_gross':800000+rng.uniform(0,400000,n),
       'zoning_group':['9']*n,'building_age_indicator':['A']*n,
       'building_condition_indicator':['B']*n,'property_type':['R']*n,
       'land_area':rng.uniform(3,6,n),'building_total_floor_area':rng.uniform(4,6,n),
       'building_site_coverage':rng.uniform(0,100,n),'off_street_parking':rng.integers(0,4,n),
       'mass_garage_under_main_roof':rng.integers(0,3,n),'sale_year':[2025]*n,
       'longitude':rng.normal(174.8,.05,n),'latitude':rng.normal(-36.85,.05,n),
       'has_flood_risk':[False]*n})
    prediction,detail=fit_log_ridge(base.iloc[:60],base.iloc[60:],np.ones(60,dtype=bool),'Hedonic Ridge (compact)')
    assert len(prediction)==15 and np.isfinite(prediction).all()
    assert detail['n_training']==60

def test_paired_subset_metrics_must_not_fake_matching():
    with pytest.raises(ValueError):score([100,150],[110])

def test_paired_cluster_requires_exact_same_fold_and_price(tmp_path):
    from stage06_core import paired_companion_interval
    hed=pd.DataFrame({'row_id':[1,2,3],'fold':[1,1,2],
        'model':['Hedonic Ridge (augmented)']*3,'actual':[100,200,300],'prediction':[130,220,290]})
    d=pd.DataFrame({'row_id':[1,2,3],'property_key':['A','A','B']})
    lgb=pd.DataFrame({'row_id':[1,2,3],'fold':[1,1,2],
        'model':['LightGBM']*3,'feature_set':['P+E']*3,
        'actual':[100,200,300],'prediction':[120,210,298]})
    p=tmp_path/'lgb.csv';lgb.to_csv(p,index=False)
    result=paired_companion_interval(hed,p,d,tmp_path,100)
    assert result['n_shared_observations']==3
    assert result['MAE_ridge_minus_LightGBM']==pytest.approx((10+10+8)/3)
    lgb.loc[0,'fold']=7;lgb.to_csv(p,index=False)
    with pytest.raises(ValueError,match='not matched'):
        paired_companion_interval(hed,p,d,tmp_path,10)
