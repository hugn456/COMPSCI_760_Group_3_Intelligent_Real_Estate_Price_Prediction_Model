"""Generate aggregate academic Stage6 manuscript and figures; no private row outputs."""
from pathlib import Path
import json
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'results'


def generate(out=OUT):
 out=Path(out);out.mkdir(parents=True,exist_ok=True)
 hed=pd.read_csv(out/'hedonic_pooled_metrics.csv');fold=pd.read_csv(out/'hedonic_fold_metrics.csv')
 hold=pd.read_csv(out/'robustness_holdout_experiments.csv')
 repeat=pd.read_csv(out/'repeat_property_pooled_lightgbm.csv')
 cv=pd.read_csv(out/'council_value_reference_by_fold.csv')
 registry=pd.read_csv(out/'fold_registry_summary.csv')
 paired=json.loads((out/'paired_companion_ridge_vs_lightgbm.json').read_text())
 spatial=json.loads((out/'robustness_design.json').read_text())
 status=json.loads((out/'stage06_manifest.json').read_text())
 orig=json.loads((out/'ORIGINAL_TEAM_REPORTED_ONLY.json').read_text())
 money=lambda x:f'NZ${x:,.0f}'
 d={row.model:row for row in hed.itertuples(index=False)}
 p=hold[(hold.scope=='price_trimmed')&(hold.subgroup=='all')].set_index('experiment')
 s=hold[(hold.experiment=='withheld_geographic_blocks')&(hold.scope=='price_trimmed')].set_index('subgroup')
 cv5=cv[(cv.fold==5)&(cv.subset=='all_positive_cv')].iloc[0]
 # 1: legend distinguishes original reported source from our own independent experiments.
 names=['Original team XGBoost','LightGBM (own, Stage 2)','Hedonic Ridge (own, augmented)',
        'Hedonic Ridge (own, compact)','Original team Hedonic OLS']
 values=[orig['teammate_original_XGBoost_augmented']['MAE'],
         133293.521687, d['Hedonic Ridge (augmented)'].MAE,
         d['Hedonic Ridge (compact)'].MAE,
         orig['teammate_original_Hedonic_OLS']['MAE']]
 fig,ax=plt.subplots(figsize=(11,5.5)); bars=ax.barh(names,values)
 for i,b in enumerate(bars):
  if i in (0,4):b.set_hatch('///')
  ax.text(values[i]+2000,b.get_y()+b.get_height()/2,money(values[i]),va='center',fontsize=9)
 ax.set_xlim(0,300000);ax.invert_yaxis();ax.set_xlabel('MAE (NZD, lower is better)')
 ax.set_title('Hedonic and machine-learning comparison: original source vs companion models')
 ax.text(.01,-.18,'Striped: original teammate notebook results; solid: independent companion results.\nComparison is aggregate, not a paired significance test against the original XGBoost.',transform=ax.transAxes,fontsize=9)
 fig.tight_layout();fig.savefig(out/'fig01_hedonic_vs_ml_mae.png',dpi=160,bbox_inches='tight');plt.close(fig)
 # 2: spatial block evaluation
 fig,ax=plt.subplots(figsize=(8,5));labels=['Withheld blocks','Other test blocks'];v=[s.loc['unseen_block','MAE'],s.loc['seen_or_other_block','MAE']]
 b=ax.bar(labels,v);ax.bar_label(b,labels=[money(x) for x in v],padding=4)
 ax.set_ylabel('MAE (NZD)');ax.set_ylim(0,max(v)*1.17)
 ax.set_title('Independent LightGBM: performance on geographically withheld test blocks')
 fig.tight_layout();fig.savefig(out/'fig02_spatial_seen_unseen.png',dpi=160);plt.close(fig)
 # 3: holdout training protocol
 fig,ax=plt.subplots(figsize=(9,5)); names3=['Historical training','Withheld 30 spatial blocks','Remove previously seen test properties']
 x=[p.loc[k,'MAE'] for k in ['chronological_reference','withheld_geographic_blocks','property_disjoint_training']]
 b=ax.barh(names3,x);ax.bar_label(b,labels=[money(v) for v in x],padding=4)
 ax.set_xlim(0,max(x)*1.3);ax.invert_yaxis();ax.set_xlabel('Fold 5 price-trimmed test MAE (NZD)')
 ax.set_title('Independent LightGBM: three training-set robustness designs')
 fig.tight_layout();fig.savefig(out/'fig03_purged_training_robustness.png',dpi=160);plt.close(fig)
 # 4: price-screened vs all future sales
 scores=hold[(hold.experiment=='chronological_reference')&(hold.subgroup=='all')].set_index('scope')
 fig,ax=plt.subplots(figsize=(7,5));v=[scores.loc['price_trimmed','MAE'],scores.loc['all_test_sales','MAE']]
 b=ax.bar(['Notebook-style price-screened','All eligible test sales'],v);ax.bar_label(b,labels=[money(y) for y in v],padding=4)
 ax.set_ylim(0,max(v)*1.2);ax.set_ylabel('MAE (NZD)');ax.set_title('Effect of conditioning the evaluation on known sale price')
 fig.tight_layout();fig.savefig(out/'fig04_price_tail_test_scope.png',dpi=160);plt.close(fig)
 # 5: repeat property reliability from companion LightGBM original OOF
 r=repeat.set_index('property_previously_seen')
 fig,ax=plt.subplots(figsize=(7,5));v=[r.loc[False,'MAE'],r.loc[True,'MAE']];b=ax.bar(['Unseen property ID','Previously seen property ID'],v)
 ax.bar_label(b,labels=[money(y) for y in v],padding=4);ax.set_ylim(0,max(v)*1.2)
 ax.set_ylabel('MAE (NZD)');ax.set_title('Repeated-property analysis in independent LightGBM OOF predictions')
 fig.tight_layout();fig.savefig(out/'fig05_repeat_property_reliability.png',dpi=160);plt.close(fig)
 # 6: evolving Council reference MAE vs independent hedonic ridge
 cvbar=cv[cv.subset=='all_positive_cv'].set_index('fold')
 hbar=fold[(fold.model=='Hedonic Ridge (augmented)')&(fold.scope=='trimmed')].set_index('fold')
 fig,ax=plt.subplots(figsize=(8,5));ax.plot(cvbar.index,cvbar.MAE,marker='o',label='Council capital value (retrospective reference)')
 ax.plot(hbar.index,hbar.MAE,marker='s',label='Independent augmented hedonic Ridge')
 ax.set_xticks(range(1,6));ax.set_ylabel('MAE (NZD)');ax.set_xlabel('Chronological fold')
 ax.set_title('Reference values vs hedonic regression (availability unverified)');ax.legend();fig.tight_layout()
 fig.savefig(out/'fig06_council_cv_context.png',dpi=160);plt.close(fig)
 # Produce compact tables and main written report
 original=orig['teammate_original_XGBoost_augmented'];ol=orig['teammate_original_Hedonic_OLS']
 status_info='All scripts are independent and do not alter your teammates’ original model, XGBoost.ipynb, or input Parquet.'
 md=f'''# COMPSCI 760 — Stage 6: Hedonic Regression and Robustness

**Contribution type:** Independent companion experiments plus clearly attributed findings from the immutable teammate XGBoost notebook. **Evaluation source:** the same 92,010-row DVRS Parquet file, with the six original-team eligibility rules, giving **59,798 eligible sales**. **Fold design:** 5 expanding time-ordered row splits and the team’s training-fold 1st–99th sale-price screening (conditional evaluation).  **Evaluated observations:** {int(registry.n_test_trimmed.sum()):,} per model. No XGBoost was refitted.

## Research aim

This stage supports **RQ2**, comparing the group's explainable machine-learning approach with traditional hedonic regression and valuation references, and **RQ4**, assessing model reliability when properties are located in unfamiliar areas or repeat-sale identities are withheld. We also distinguish results on the original screened population from *all* future eligible sales, and document limits of existing Council valuations as a prospective benchmark.

## 1. Hedonic regression vs machine learning

The original teammate notebook reported a traditional **log-price OLS hedonic model with one-hot predictors and a smearing correction**, on its 48,848 screened out-of-fold sales: MAE **{money(ol['MAE'])}** and RMSE **{money(ol['RMSE'])}**. On the same published protocol, its XGBoost augmented model achieved **{money(original['MAE'])} MAE** and **{money(original['RMSE'])} RMSE**. These are **original, unmodified notebook results**; we neither reran nor modified its XGBoost/OLS models.

Our independent additions evaluate two **regularised log-price hedonic models**: a compact (structural + location) and an augmented version covering the original 35 modelling features. Both are fitted only on each historical training window. Each employs training-only categorical encoding, numerical imputation, scaling, Ridge regularisation (alpha 20), and a Duan-style training-residual smearing factor on the inverse-log transform. No Council capital/land values are used as explanatory features.

| Model and ownership | OOF observations | MAE (NZD) | RMSE (NZD) | MAPE | Evaluation caveat |
|---|---:|---:|---:|---:|---|
| Original team XGBoost augmented | 48,848 | {money(original['MAE'])} | {money(original['RMSE'])} | {original['MAPE_pct']:.2f}% | Source-reported results; no original per-row export |
| Original team hedonic OLS | 48,848 | {money(ol['MAE'])} | {money(ol['RMSE'])} | {ol['MAPE_pct']:.2f}% | Source-reported results |
| Our hedonic Ridge, compact | {int(d['Hedonic Ridge (compact)'].n):,} | {money(d['Hedonic Ridge (compact)'].MAE)} | {money(d['Hedonic Ridge (compact)'].RMSE)} | {d['Hedonic Ridge (compact)'].MAPE_pct:.2f}% | Independent new training |
| Our hedonic Ridge, augmented | {int(d['Hedonic Ridge (augmented)'].n):,} | {money(d['Hedonic Ridge (augmented)'].MAE)} | {money(d['Hedonic Ridge (augmented)'].RMSE)} | {d['Hedonic Ridge (augmented)'].MAPE_pct:.2f}% | Independent new training |

**Interpretation:** The regularised augmented hedonic extension improves MAE by approximately **{money(d['Hedonic Ridge (compact)'].MAE - d['Hedonic Ridge (augmented)'].MAE)}** over its compact counterpart, but it does not close the substantial observed gap against the original-team XGBoost result. Our companion Ridge results were obtained using matching screening rules and TimeSeriesSplit sizes; we cannot claim transaction-by-transaction identity of their predictions with the original unsaved XGBoost predictions, or attach paired confidence intervals to that cross-source comparison.

![Model comparison](fig01_hedonic_vs_ml_mae.png)

## 2. Matched, paired evaluation against a separate boosted-tree model

An **independent LightGBM** comparison from Stage 2 was matched to our augmented Ridge on *both* the fold ID and exact transaction row ID, with the sale-price label checked for equality. A property-identifier-clustered bootstrap (500 replicates, seed 760) estimates that Ridge's MAE exceeds LightGBM's by **{money(paired['MAE_ridge_minus_LightGBM'])}**, with a nominal 95% interval **{money(paired['cluster_bootstrap_95pct_lower'])} to {money(paired['cluster_bootstrap_95pct_upper'])}**. This **does not** compare against the original XGBoost; no original XGBoost out-of-fold prediction export was supplied.

## 3. Geographical generalisation

For a new diagnostic evaluation, we independently trained LightGBM on the **fifth chronological fold**. We chose deterministic 0.035-degree latitude–longitude blocks and excluded **{spatial['n_spatial_blocks_withheld']} entire blocks** from its training data. The price-screened held-out test period contains **{spatial['n_test_spatial_unseen_trimmed']:,} sales** in the geographically unseen blocks and **{spatial['n_test_spatial_other_trimmed']:,}** elsewhere.

- In the geographically purged model, unseen-block MAE was **{money(s.loc['unseen_block','MAE'])}**, compared with **{money(s.loc['seen_or_other_block','MAE'])}** on the other test observations.
- The model trained on all historical locations (chronological reference) achieved **{money(p.loc['chronological_reference','MAE'])}** on the same overall screened final-fold test set.
- Excluding the selected geographic blocks increased overall test MAE to **{money(p.loc['withheld_geographic_blocks','MAE'])}**.

This is evidence that geographic transfer is harder. The unseen and other regions differ in property composition and sample sizes, so the gap is **not** a controlled causal estimate of the effect of unseen location. Unlike the team's original fold scheme, this additional experiment deliberately withholds complete geographic blocks; it does not change the original model.

![Spatial robustness](fig02_spatial_seen_unseen.png)

## 4. Repeat-property generalisation

Matching original transaction identifiers to the property's `valuation_id_concat` reveals **{int(r.loc[True,'n']):,}** historically seen-property sales and **{int(r.loc[False,'n']):,}** never-previously-seen-property sales in independent LightGBM OOF evaluation. MAE was **{money(r.loc[True,'MAE'])}** for seen properties versus **{money(r.loc[False,'MAE'])}** for unseen properties. This does not prove property-ID leakage; property ID was not used as a predictor, and repeated sales may differ in ease of prediction.

As an independent controlled stress test on fold 5, we removed **{spatial['n_training_rows_omitted_for_property_disjoint']:,} historically eligible training rows** representing properties whose IDs occur in the future test window. The LightGBM test MAE changed from **{money(p.loc['chronological_reference','MAE'])}** to **{money(p.loc['property_disjoint_training','MAE'])}**. This modest change suggests the original matching property IDs are not by themselves responsible for most of this companion model's performance. This finding does not certify group-disjoint generalisation for the teammate's original XGBoost.

![Repeat-property reliability](fig05_repeat_property_reliability.png)

## 5. Impact of conditional price-tail screening

The original protocol screens each fold's test observations using the observed *true* sale price relative to the historical training 1st–99th percentile cutoffs. That is a valid **descriptive conditional error measure**, but not the model's error on all later sales. In independent LightGBM's final fold:

| Later-test population | Count | MAE (NZD) | RMSE (NZD) |
|---|---:|---:|---:|
| Sale-price screened | {int(scores.loc['price_trimmed','n']):,} | {money(scores.loc['price_trimmed','MAE'])} | {money(scores.loc['price_trimmed','RMSE'])} |
| All eligible sales | {int(scores.loc['all_test_sales','n']):,} | {money(scores.loc['all_test_sales','MAE'])} | {money(scores.loc['all_test_sales','RMSE'])} |

The all-sale MAE is higher by **{money(scores.loc['all_test_sales','MAE']-scores.loc['price_trimmed','MAE'])}**. We report this as a **new companion-model robustness result** only; we do not replace your teammates' original XGBoost figures.

![Test-screening sensitivity](fig04_price_tail_test_scope.png)

## 6. Council capital-value reference

The raw file contains historical Council `capital_value` fields, which were excluded from the teammate's original ML inputs. We used those fields as an **independent reference** only, not as model predictors. On fold 5's screened test subset with positive recorded CV values (n={int(cv5.n):,}), CV-versus-sale MAE was **{money(cv5.MAE)}**, versus **{money(cv5.RMSE)} RMSE**. The comparison differs from the group's separately reported CV benchmark on 43,476 matched transactions; do not combine the two populations or claim that XGBoost beats CV.

We decoded effective dates from the source's Excel-style serial date field and checked whether each recorded CV's *effective* date preceded the sale. Critically, **effective date does not establish when the specific value was released, observed, or historically available**. Consequently, none of these capital-value statistics proves performance against a genuinely prospective publicly accessible valuation service. No online estimator benchmark is claimed.

![Council valuation benchmark](fig06_council_cv_context.png)

## 7. Limitations and research conclusion

This Stage 6 contribution adds (1) independent regularised hedonic regression, (2) matched boosting-vs-hedonic evidence **only among companion models**, (3) geographically withheld generalisation, (4) repeat-property diagnostics and a property-disjoint training stress test, (5) full-tail versus price-screened evaluation, and (6) a separately labelled CV context check.

Limitations include only one late-fold spatial stress test, deterministic non-randomly chosen blocks, different regional price mixes, no verified publication vintages for external or CV data, five original folds sharing calendar boundaries, and reliance on screened test targets for published notebook-style MAE. The original teammate's XGBoost out-of-fold predictions were not delivered as separate row-level artifacts; therefore, no direct paired robustness test for that original model is represented as completed.

**Conclusion:** The team's original XGBoost remains the agreed preferred *property-level machine-learning model* among the tested configurations, backed by the much lower reported MAE than the traditional hedonic OLS and our supplemental Ridge benchmarks. But the Council capital-value reference can be highly competitive on its own restricted subsets, and geographic/price-tail generalisation needs separate attention. None of these companion tests changes the original XGBoost model or results.

### Integrity and provenance

{status_info} The original notebook and dataset were verified against fixed SHA-256 hashes. Source and model ownership are documented in `stage06_manifest.json`. Property-level data and row-level model predictions are excluded from the shareable archive.
'''
 (out/'STAGE06_RESEARCH_REPORT.md').write_text(md)
 print('Report written:',out/'STAGE06_RESEARCH_REPORT.md')

if __name__=='__main__':generate()
