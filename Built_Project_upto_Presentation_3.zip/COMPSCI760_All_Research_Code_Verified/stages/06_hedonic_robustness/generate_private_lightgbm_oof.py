"""Optional local companion LightGBM OOF generator for a self-contained Stage6 run.

Does NOT load/modify/retrain the teammate's original XGBoost. Saves individual
transaction predictions only to a PRIVATE file excluded from the ZIP.
"""
import argparse,sys
from pathlib import Path
import numpy as np,pandas as pd
from sklearn.model_selection import TimeSeriesSplit
from lightgbm import LGBMRegressor
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'src'))
from stage06_core import load_verified,train_quantile_filter,team_style_encoded,LGBM_PARAMS,score


def make_predictions(data,destination):
    rows=[];fold_scores=[]
    for fold,(tr,te) in enumerate(TimeSeriesSplit(n_splits=5).split(data),1):
        trd,ted=data.iloc[tr],data.iloc[te]
        yt=trd.sale_price_gross.to_numpy(float);ye=ted.sale_price_gross.to_numpy(float)
        kt,ke,_=train_quantile_filter(yt,ye)
        a,b=team_style_encoded(trd,ted)
        m=LGBMRegressor(**LGBM_PARAMS)
        m.fit(a.loc[kt],yt[kt]);pred=m.predict(b.loc[ke])
        fold_scores.append({'fold':fold,**score(ye[ke],pred)})
        for row,actual,yhat,key in zip(ted.row_id.to_numpy()[ke],ye[ke],pred,ted.property_key.to_numpy()[ke]):
            rows.append({'row_id':int(row),'fold':fold,'actual':float(actual),
                         'prediction':float(yhat),'model':'LightGBM','feature_set':'P+E',
                         'property_key':str(key)})
        print('LightGBM companion fold',fold,'MAE',round(fold_scores[-1]['MAE']),flush=True)
    dest=Path(destination)
    if dest.parent.name !='PRIVATE':raise ValueError('Private predictions must be stored in a PRIVATE directory')
    dest.parent.mkdir(parents=True,exist_ok=True)
    output=pd.DataFrame(rows)
    if len(output)!=48848:raise ValueError(f'Screened OOF cohort mismatch: {len(output)}')
    output.to_csv(dest,index=False,compression='gzip')
    return output,pd.DataFrame(fold_scores)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--dataset',default=str(ROOT.parent/'newest_dvrs_with_team_external.parquet'))
    parser.add_argument('--notebook',default=str(ROOT.parent/'XGBoost.ipynb'))
    parser.add_argument('--out',default=str(ROOT/'PRIVATE/companion_lightgbm_oof.csv.gz'))
    args=parser.parse_args()
    d,_=load_verified(args.dataset,args.notebook)
    make_predictions(d,args.out)
