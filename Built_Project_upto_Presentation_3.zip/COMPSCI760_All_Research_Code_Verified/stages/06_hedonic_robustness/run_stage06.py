"""One command to run all Stage 6 original-source-preserving companion analyses."""
import argparse, json,sys,time
from pathlib import Path
import pandas as pd
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'src'))
from stage06_core import (load_verified,run_hedonic_oof,property_repeat_audit,
                          council_reference,run_holdout_probes,paired_companion_interval,DATA_SHA,NOTEBOOK_SHA)


def run(dataset,notebook,out,lightgbm_private):
    print('Stage 06: verifying untouched source files and reading data',flush=True)
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    start=time.monotonic()
    d,counts=load_verified(dataset,notebook)
    print('Source/cohort',len(d),counts,flush=True)
    mf,pool,fold,pred=run_hedonic_oof(d,out)
    print('HEDONIC pooled:\n'+pool.to_string(index=False),flush=True)
    paired=paired_companion_interval(pred,lightgbm_private,d,out)
    print('Paired companion MAE difference:',paired['MAE_ridge_minus_LightGBM'],flush=True)
    repeat=property_repeat_audit(d,out,lightgbm_private)
    print('Repeat-property summary:\n'+repeat.to_string(index=False),flush=True)
    cv=council_reference(d,out)
    probe,design=run_holdout_probes(d,out)
    original_metrics={'teammate_original_XGBoost_augmented':{'n':48848,'MAE':131243.38,'RMSE':214529.56,'MAPE_pct':11.31},
          'teammate_original_XGBoost_baseline':{'n':48848,'MAE':208318.50,'RMSE':317631.16,'MAPE_pct':18.17},
          'teammate_original_Hedonic_OLS':{'n':48848,'MAE':243001.11,'RMSE':683993.77,'MAPE_pct':20.92}}
    (out/'ORIGINAL_TEAM_REPORTED_ONLY.json').write_text(json.dumps(original_metrics,indent=2))
    manifest={'source_data_sha256':DATA_SHA,'original_notebook_sha256':NOTEBOOK_SHA,
      'raw_rows':92010,'cohort_rows':len(d),'n_eval_original_notebook_policy':int(fold.n_test_trimmed.sum()),
      'notebook_file_modified':False,'XGBoost_trained_or_replaced':False,
      'source_of_XGBoost_and_original_OLS_metrics':'Saved outputs in original immutable XGBoost.ipynb, NOT our experiments',
      'own_independent_models':['Hedonic Ridge (compact)','Hedonic Ridge (augmented)','Companion LightGBM holdout stress tests'],
      'own_stats_source':'New training on shared dataset with original eligibility rules and row-based folds',
      'total_run_seconds':round(time.monotonic()-start,2),
      'validation_limitations':['Original notebook folds may share a calendar day','Evaluation trims test properties using their observed prices','Historical GIS data snapshot dates not established','CV effective date alone does not verify public availability','Spatial region selection deterministic but geographic composition not controlled','Model comparisons to original XGBoost only aggregate, not individually paired']}
    (out/'stage06_manifest.json').write_text(json.dumps(manifest,indent=2))
    print('FINISHED Stage06 in',manifest['total_run_seconds'],'seconds',flush=True)
    return manifest

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--dataset',default=str(HERE.parent/'newest_dvrs_with_team_external.parquet'))
    p.add_argument('--notebook',default=str(HERE.parent/'XGBoost.ipynb'))
    p.add_argument('--companion-predictions',default=str(HERE/'PRIVATE/companion_lightgbm_oof.csv.gz'))
    p.add_argument('--out',default=str(HERE/'results'))
    a=p.parse_args()
    run(a.dataset,a.notebook,a.out,a.companion_predictions)
