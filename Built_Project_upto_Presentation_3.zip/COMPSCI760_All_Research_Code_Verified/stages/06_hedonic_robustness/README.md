# Stage 6 — Hedonic Regression and Robustness

Compares compact and augmented regularised hedonic models with the original source-reported XGBoost and hedonic OLS summaries. Separate LightGBM stress tests examine unfamiliar geographic blocks, repeated properties, price tails and Council-value references.

**Primary outputs:** pooled hedonic metrics, fold metrics, geographic holdouts, repeat-property diagnostics and figures.

**Run:** `python project.py run 6 --dataset PATH --notebook PATH --lgbm-oof PRIVATE_PATH`; the prediction file can be generated with `python project.py run 2 --dataset PATH --notebook PATH --extended`, or separately using `generate_private_lightgbm_oof.py`.

**Interpretation:** Geographic robustness findings apply to LightGBM, not XGBoost. Council-value effective dates do not establish pre-sale publication or availability.

Reproduction details and project-wide safeguards are in the repository-level `README.md`.
