# Stage 5 — Explainable AI (SHAP)

Analyses the XGBoost SHAP values already reported in the fixed notebook and verifies supplementary LightGBM/Random Forest SHAP explanations, keeping the model sources distinct.

**Primary outputs:** original-source SHAP summaries, model-group importance and SHAP additivity checks.

**Run:** `python project.py run 5 --dataset PATH --notebook PATH`. This can be computationally expensive; the group package already contains aggregate results.

**Interpretation:** About 33.0% of total XGBoost attribution is assigned to latitude/longitude and 7.1% to the other 11 external features. Attribution is neither causal impact nor added predictive accuracy.

Reproduction details and project-wide safeguards are in the repository-level `README.md`.
