"""Extract read-only saved SHAP feature ranking and group-share from teammate notebook cell 75.

NO XGB training, no modifications, no rerunning notebook cells. Computed sums are
new arithmetic interpretations of team-published original results, not new XGB SHAP.
"""
from __future__ import annotations
import hashlib
from pathlib import Path
import re
import nbformat
import pandas as pd
import numpy as np

NOTEBOOK_SHA = '21d388340231d149109195ca0498533de28b33e692c73e6a965ce6a6c62d7057'
EXTERNAL_FEATURES=['unitary_plan_zone','noise_category_combination','longitude','latitude',
'dist_to_flood_plain_m','dist_to_flood_sensitive_area_m','sa2_new_dwellings_consented_12m',
'walk_supermarket_network_m','walk_bus_stop_network_m','in_flood_plain',
'in_flood_sensitive_area','has_flood_risk','in_noise_overlay']
LOCATION=['longitude','latitude']


def original_shap_readonly(notebook_path):
    path=Path(notebook_path)
    with path.open('rb') as f: actual=hashlib.file_digest(f,'sha256').hexdigest()
    if actual!=NOTEBOOK_SHA:
        raise ValueError('The immutable teammate notebook hash has changed. Aborting.')
    notebook=nbformat.read(path,as_version=4)
    cell=notebook.cells[75]
    chunks=[]
    for out in cell.get('outputs',[]):
        if out.get('output_type')=='stream': chunks.append(out.get('text',''))
        elif 'data' in out: chunks.append(out['data'].get('text/plain',''))
    text='\n'.join(chunks)
    share_match=re.search(r'SHAP share of external features:\s*([\d.]+)%',text)
    if not share_match: raise ValueError('Expected notebook-saved external SHAP share not found')
    percent=float(share_match.group(1))
    rows=[]
    for line in text.splitlines():
        for feature in EXTERNAL_FEATURES:
            found=re.match(r'^\s*'+re.escape(feature)+r'\s+([0-9]+(?:\.[0-9]+)?)\s*$',line)
            if found:rows.append((feature,float(found.group(1))))
    table=pd.DataFrame(rows,columns=['feature','reported_mean_absolute_SHAP_NZD'])
    if len(table)!=len(EXTERNAL_FEATURES) or table.feature.duplicated().any():
        raise ValueError(f'Expected 13 unique features, found {len(table)}')
    table['source']='teammate original XGBoost saved notebook output (unchanged)'
    ext_sum=float(table.reported_mean_absolute_SHAP_NZD.sum())
    coord_sum=float(table.loc[table.feature.isin(LOCATION),'reported_mean_absolute_SHAP_NZD'].sum())
    other=ext_sum-coord_sum
    # Estimated overall P+L+E shares inferred from the saved 40.1% group share;
    # precision limited by the group percentage rounding to 1 decimal place.
    summary={
        'source':'Teammate original notebook, cell 75; arithmetic derived without model access',
        'teammate_reported_external_share_pct':percent,
        'n_external_features_reported':len(EXTERNAL_FEATURES),
        'original_external_mean_abs_SHAP_sum_NZD':ext_sum,
        'coordinate_feature_mean_abs_SHAP_sum_NZD':coord_sum,
        'other_external_feature_mean_abs_SHAP_sum_NZD':other,
        'coordinates_within_external_pct':100*coord_sum/ext_sum,
        'other_external_within_external_pct':100*other/ext_sum,
        'coordinate_pct_of_all_features_approx':percent*coord_sum/ext_sum,
        'other_external_pct_of_all_features_approx':percent*other/ext_sum,
        'property_group_pct_of_all_features_approx':100-percent,
        'interpretation':'relative mean absolute SHAP attribution (not causal effects, not model error reduction)',
        'limitation':'Original 40.1% is rounded; feature values were rounded to NZD; splits share the same 80/20 context as notebook cell 75.'
    }
    return table.sort_values('reported_mean_absolute_SHAP_NZD',ascending=False).reset_index(drop=True),summary


def original_drop_one_readonly(notebook_path):
    """Read teammate's saved *drop-one retraining* RMSE differences; not a SHAP statistic."""
    path=Path(notebook_path)
    with path.open('rb') as source:
        if hashlib.file_digest(source,'sha256').hexdigest()!=NOTEBOOK_SHA:
            raise ValueError('Immutable teammate notebook fingerprint mismatch')
    nb=nbformat.read(path,as_version=4)
    output='\n'.join((o.get('text','') if o.get('output_type')=='stream' else o.get('data',{}).get('text/plain','')) for o in nb.cells[78].get('outputs',[]))
    rows=[]
    for line in output.splitlines():
        match=re.match(r'^\s*dropped\s+(\S+)\s+RMSE=\$([\d,]+)\s+\(\s*([+-]?[\d,]+)\s+vs full model\)',line)
        if match:rows.append((match.group(1),float(match.group(2).replace(',','')),float(match.group(3).replace(',',''))))
    df=pd.DataFrame(rows,columns=['feature','teammate_drop_one_RMSE_NZD','teammate_drop_one_RMSE_delta_NZD'])
    if len(df)!=13 or df.feature.duplicated().any() or set(df.feature)!=set(EXTERNAL_FEATURES):
        raise ValueError('Expected 13 drop-one external feature results from notebook cell 78')
    return df
