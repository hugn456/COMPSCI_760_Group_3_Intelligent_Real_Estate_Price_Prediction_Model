"""Stage 5 original XGBoost read-only SHAP extraction + companion-model explanation.

LightGBM & Random Forest are NEW, independent companion fits on team's cohort.
NEVER train XGBoost or represent companion SHAP values as the original team model.
"""
from __future__ import annotations
import argparse, hashlib, json, os, sys, time
from pathlib import Path
import numpy as np
import pandas as pd
import shap
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import OrdinalEncoder
from lightgbm import LGBMRegressor
THIS=Path(__file__).resolve().parent
sys.path.insert(0,str(THIS/'src'))
from source_xgboost_shap import original_shap_readonly,NOTEBOOK_SHA
from notebook_cohort_reference import (prepare,AUGMENTED,BASELINE,ALL_CAT,ALL_NUM,
                                         EXTERNAL_BOOL,DATA_SHA,sha256)
from parquet_readonly import read_parquet

# Derived from Stage 2 companion precommitted model specs. Not the original XGB.
MODEL_PARAMS={
    'LightGBM':{'n_estimators':450,'num_leaves':31,'learning_rate':.04,'min_child_samples':22,
                'max_depth':-1,'colsample_bytree':.8,'reg_lambda':2,'verbosity':-1,'random_state':42,'n_jobs':2},
    'RandomForest':{'n_estimators':120,'max_depth':14,'min_samples_leaf':5,
                    'max_features':1.0,'random_state':42,'n_jobs':2}}
GROUPS={
    'Property and basic attributes':list(BASELINE),
    'Coordinates':['latitude','longitude'],
    'Other external': [c for c in AUGMENTED if c not in BASELINE+['longitude','latitude']],
}
assert len(GROUPS['Property and basic attributes'])==22
assert len(GROUPS['Other external'])==11
assert set().union(*(set(v) for v in GROUPS.values()))==set(AUGMENTED)


def checked_parquet(path):
    if sha256(path)!=DATA_SHA:raise ValueError('Shared source Parquet fingerprint mismatch; do not proceed')
    try:return pd.read_parquet(path)
    except ImportError:return read_parquet(path)


def fold_80_20(df):
    n=int(len(df)*.8)
    train,test=df.iloc[:n],df.iloc[n:]
    yt=train.sale_price_gross.to_numpy(dtype=float)
    ye=test.sale_price_gross.to_numpy(dtype=float)
    low,high=np.quantile(yt,[.01,.99])
    return train,test,yt,ye,(yt>=low)&(yt<=high),(ye>=low)&(ye<=high),(low,high)


def encode_inputs(train,test):
    enc=OrdinalEncoder(handle_unknown='use_encoded_value',unknown_value=-1)
    enc.fit(train[ALL_CAT])
    a=train[AUGMENTED].copy();b=test[AUGMENTED].copy()
    a[ALL_CAT]=enc.transform(train[ALL_CAT]);b[ALL_CAT]=enc.transform(test[ALL_CAT])
    for c in EXTERNAL_BOOL:a[c]=a[c].astype(int);b[c]=b[c].astype(int)
    a=a.astype(float);b=b.astype(float)
    na=[c for c in ALL_NUM if a[c].isna().any() or b[c].isna().any()]
    med=a[na].median();a[na]=a[na].fillna(med);b[na]=b[na].fillna(med)
    if not np.isfinite(a.to_numpy()).all() or not np.isfinite(b.to_numpy()).all():
        raise ValueError('Missing or non-finite features after notebook-style preprocessing')
    return a,b


def shap_validate(model,features,limit=350,seed=42):
    sample=features.sample(n=min(limit,len(features)),random_state=seed)
    shap_values=shap.TreeExplainer(model).shap_values(sample)
    raw=np.asarray(shap_values,dtype=float)
    if raw.shape != sample.shape:raise ValueError(f'SHAP output mismatch {raw.shape} != {sample.shape}')
    # Explicit tree path dependent base value, consistent with raw TreeSHAP output.
    explainer=shap.TreeExplainer(model)
    baseline=np.asarray(explainer.expected_value,dtype=float)
    if baseline.size!=1:raise ValueError('Unexpected base value array')
    pred=np.asarray(model.predict(sample),dtype=float)
    reconstruction=baseline.item()+raw.sum(axis=1)
    maximum=float(np.abs(reconstruction-pred).max())
    assert np.allclose(pred,reconstruction,rtol=1e-5,atol=3),f'SHAP additivity failed: max residual NZ${maximum:.2f}'
    return sample,raw,float(baseline.item()),maximum


def summarize_attributions(modelname,sample,values):
    imp=pd.DataFrame({'feature':sample.columns,
        'mean_absolute_shap_nzd':np.abs(values).mean(axis=0),
        'mean_signed_shap_nzd':values.mean(axis=0),
        'model':modelname}).sort_values('mean_absolute_shap_nzd',ascending=False)
    sums=imp.set_index('feature')['mean_absolute_shap_nzd']
    total=float(sums.sum());group_rows=[]
    for label,columns in GROUPS.items():
        vals=values[:,[sample.columns.get_loc(x) for x in columns]]
        group_rows.append({
            'model':modelname,'feature_group':label,'n_features':len(columns),
            'sum_individual_mean_absolute_SHAP_NZD':float(np.abs(vals).mean(axis=0).sum()),
            'relative_individual_attribution_pct':float(np.abs(vals).mean(axis=0).sum()/total*100),
            'mean_abs_of_signed_group_sum_NZD':float(np.abs(vals.sum(axis=1)).mean()),
            'mean_signed_group_sum_NZD':float(vals.sum(axis=1).mean())
        })
    return imp,pd.DataFrame(group_rows)


def run(dataset, notebook, out, models=('LightGBM','RandomForest'),sample_size=320):
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    print('1. Extracting original teammate XGBoost SHAP values (read-only)',flush=True)
    original,team_summary=original_shap_readonly(notebook)
    original.to_csv(out/'team_original_xgb_external_shap.csv',index=False)
    (out/'team_original_xgb_shap_derived_summary.json').write_text(json.dumps(team_summary,indent=2)+'\n')
    print('Original 40.1% external share: coords fraction',round(team_summary['coordinates_within_external_pct'],2),'%',flush=True)
    print('2. Reading shared source and preparing companion LightGBM/RF data',flush=True)
    data=checked_parquet(dataset)
    df,counts=prepare(data)
    train,test,ytr,yte,ktr,kte,(lo,hi)=fold_80_20(df)
    a,b=encode_inputs(train,test)
    ytr=ytr[ktr];yte=yte[kte];a=a.loc[ktr];b=b.loc[kte]
    print('80/20 sample: train',len(a),'test',len(b),'features',len(a.columns),flush=True)
    numeric=[];groups=[];evaluation=[]
    for modelname in models:
        ts=time.monotonic()
        if modelname=='LightGBM':m=LGBMRegressor(**MODEL_PARAMS[modelname])
        elif modelname=='RandomForest':m=RandomForestRegressor(**MODEL_PARAMS[modelname])
        else:raise ValueError('Only independent companion model names permitted, no XGBoost')
        m.fit(a,ytr)
        p=np.asarray(m.predict(b),dtype=float)
        mae=float(np.mean(np.abs(yte-p)))
        rmse=float(np.sqrt(np.mean((yte-p)**2)))
        print(modelname,'trained; 80/20 MAE',round(mae,2),'seconds',round(time.monotonic()-ts,1),flush=True)
        sample_limit=min(sample_size,16) if modelname=='RandomForest' else sample_size
        sample,values,expected,residual=shap_validate(m,b,limit=sample_limit)
        print(modelname,'SHAP additivity max residual $',round(residual,5),flush=True)
        imp, grp=summarize_attributions(modelname,sample,values)
        numeric.append(imp);groups.append(grp)
        evaluation.append({'model':modelname,'source':'independent companion model, NOT original team XGBoost',
                           'n_train_after_price_trim':len(a),'n_test_after_price_trim':len(b),
                           'n_explained':len(sample),'base_prediction_nzd':expected,
                           'additivity_max_absolute_error_nzd':residual,'MAE':mae,'RMSE':rmse,
                           'split':'80/20 chronological transaction split, notebook-compatible',
                           'evaluation':'test true price restricted to training 1%-99% quantile bounds'})
        # PRIVATE outputs contain individual SHAP values, so not delivered publicly.
        private=out.parent/'PRIVATE';private.mkdir(parents=True,exist_ok=True)
        pd.DataFrame(values,columns=sample.columns).to_csv(private/f'{modelname}_sample_shap_PRIVATE.csv.gz',index=False,compression='gzip')
    pd.concat(numeric,ignore_index=True).to_csv(out/'companion_feature_SHAP_importance.csv',index=False)
    pd.concat(groups,ignore_index=True).to_csv(out/'companion_group_SHAP_importance.csv',index=False)
    pd.DataFrame(evaluation).to_csv(out/'companion_model_SHAP_checks.csv',index=False)
    manifest={'team_notebook_sha256':NOTEBOOK_SHA,'dataset_sha256':DATA_SHA,
      'teammate_xgboost_modified_or_retrained':False,
      'original_xgboost_shap_source':'Existing saved teammate notebook outputs only, not recomputed',
      'companion_models':list(models),'model_hyperparameters':{n:MODEL_PARAMS[n] for n in models},
      'sample_size_requested':sample_size,'source_cohort_eligible':len(df),
      'cohort_filter_counts':counts,'chronological_80_20_train_final_date':str(train.sale_date_parsed.max().date()),
      'chronological_80_20_test_initial_date':str(test.sale_date_parsed.min().date()),
      'train_price_filter':[float(lo),float(hi)],
      'limitations':['Companion models retrained independently; not the team XGBoost.',
                     'XGB source grouping includes coordinates in external.',
                     'SHAP attribution is associational/model-specific, not causal.',
                     'Ordinal category encoding can affect SHAP interpretation.',
                     'Highly correlated floor area and geographic variables split attributions.',
                     'Same calendar day may appear in both 80/20 split segments.',
                     'The 80/20 companion SHAP experiment is not the five-fold Stage 2 leaderboard.']}
    (out/'stage05_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    return original,team_summary,pd.concat(numeric),pd.concat(groups),pd.DataFrame(evaluation)


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--dataset',default='/mnt/data/newest_dvrs_with_team_external.parquet')
    parser.add_argument('--notebook',default='/mnt/data/XGBoost.ipynb')
    parser.add_argument('--out',default='results')
    parser.add_argument('--models',nargs='+',choices=('LightGBM','RandomForest'),default=('LightGBM','RandomForest'))
    parser.add_argument('--sample-size',type=int,default=320)
    args=parser.parse_args()
    run(args.dataset,args.notebook,args.out,tuple(args.models),args.sample_size)
