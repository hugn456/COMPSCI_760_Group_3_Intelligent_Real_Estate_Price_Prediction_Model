"""Tests use toy data and the original notebook READ-ONLY; no Council transaction rows exported."""
import sys
from pathlib import Path
import hashlib
import numpy as np
import pandas as pd
import pytest
from lightgbm import LGBMRegressor
HERE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(HERE))
sys.path.insert(0,str(HERE/'src'))
from source_xgboost_shap import original_shap_readonly,original_drop_one_readonly,NOTEBOOK_SHA
from run_stage05 import summarize_attributions,shap_validate,GROUPS,fold_80_20
NOTEBOOK=Path('/mnt/data/XGBoost.ipynb')


def test_original_notebook_sha_is_frozen():
    assert hashlib.sha256(NOTEBOOK.read_bytes()).hexdigest()==NOTEBOOK_SHA
    assert len(NOTEBOOK.read_bytes())>1_000_000


def test_original_shap_values_are_complete_and_immutable():
    before=NOTEBOOK.stat().st_mtime_ns
    values,totals=original_shap_readonly(NOTEBOOK)
    after=NOTEBOOK.stat().st_mtime_ns
    assert before==after
    assert len(values)==13
    assert totals['teammate_reported_external_share_pct']==40.1
    assert totals['coordinate_feature_mean_abs_SHAP_sum_NZD']==269228
    assert totals['other_external_feature_mean_abs_SHAP_sum_NZD']==57501
    assert abs(totals['coordinates_within_external_pct']-82.401)<0.001
    assert values.iloc[0].feature=='latitude'


def test_original_drop_one_reconstruction_preserves_signed_rmse():
    df=original_drop_one_readonly(NOTEBOOK).set_index('feature')
    assert len(df)==13
    assert df.loc['latitude','teammate_drop_one_RMSE_delta_NZD']==36700
    assert df.loc['dist_to_flood_sensitive_area_m','teammate_drop_one_RMSE_delta_NZD']==-98


def test_original_fingerprint_mismatch_is_rejected(tmp_path):
    p=tmp_path/'notebook.ipynb';p.write_text('{}')
    with pytest.raises(ValueError,match='hash has changed'):
        original_shap_readonly(p)


def test_group_partition_disjoint_and_exhaustive():
    names=[f for group in GROUPS.values() for f in group]
    assert len(names)==35 and len(set(names))==35
    assert [len(v) for v in GROUPS.values()]==[22,2,11]
    assert not set(GROUPS['Other external']).intersection({'latitude','longitude'})


def test_summary_preserves_group_shap_equations():
    rng=np.random.default_rng(9)
    frame=pd.DataFrame(rng.normal(size=(7,35)),columns=[f for group in GROUPS.values() for f in group])
    values=rng.normal(size=(7,35))
    importance,grouped=summarize_attributions('Toy',frame,values)
    assert len(importance)==35 and len(grouped)==3
    assert grouped.relative_individual_attribution_pct.sum()==pytest.approx(100)
    for name,feat in GROUPS.items():
        x=grouped[grouped.feature_group==name].iloc[0]
        cols=[frame.columns.get_loc(c) for c in feat]
        assert x.sum_individual_mean_absolute_SHAP_NZD==pytest.approx(np.abs(values[:,cols]).mean(axis=0).sum())
        assert x.mean_abs_of_signed_group_sum_NZD==pytest.approx(np.abs(values[:,cols].sum(axis=1)).mean())


def test_lightgbm_exact_additivity_on_synthetic_data():
    rng=np.random.default_rng(13)
    a=pd.DataFrame(rng.normal(size=(120,6)),columns=list('abcdef'))
    y=700000+110000*a.a-35000*a.b+8000*rng.normal(size=120)
    model=LGBMRegressor(n_estimators=16,num_leaves=8,min_child_samples=3,verbosity=-1,n_jobs=1,random_state=1)
    model.fit(a.iloc[:90],y.iloc[:90])
    x,sh,base,residual=shap_validate(model,a.iloc[90:],limit=13)
    assert len(x)==13
    assert residual<1e-6
    assert np.allclose(base+sh.sum(axis=1),model.predict(x),rtol=1e-8)


def test_fold_80_20_uses_only_train_prices_to_trim():
    from types import SimpleNamespace
    z=pd.DataFrame({'sale_price_gross':np.r_[np.linspace(100000,800000,40),np.repeat(1e9,10)]})
    tr,te,yt,ye,mtr,mte,bounds=fold_80_20(z)
    assert len(tr)==40 and len(te)==10
    assert bounds[1]<1e9 and not mte.any()


def test_only_companion_model_names_allowed():
    from run_stage05 import MODEL_PARAMS
    assert set(MODEL_PARAMS)=={'LightGBM','RandomForest'}
    assert 'XGBoost' not in MODEL_PARAMS
