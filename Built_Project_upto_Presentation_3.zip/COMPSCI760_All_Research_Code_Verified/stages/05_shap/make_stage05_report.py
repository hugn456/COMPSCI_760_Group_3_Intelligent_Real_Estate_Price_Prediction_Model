"""Generate report-ready aggregate Stage 5 SHAP graphics/report from verified outputs.

Original teammate XGBoost values are READ-ONLY. No XGBoost training.
Individual property SHAP data stay PRIVATE and never enter shared graphics as rows.
"""
from __future__ import annotations
import json
from pathlib import Path
import sys
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
THIS=Path(__file__).resolve().parent
sys.path.insert(0,str(THIS/'src'))
from source_xgboost_shap import original_drop_one_readonly
from notebook_cohort_reference import sha256,NOTEBOOK_SHA


def make(out,notebook):
    out=Path(out);out.mkdir(exist_ok=True,parents=True)
    assert sha256(notebook)==NOTEBOOK_SHA
    source=pd.read_csv(out/'team_original_xgb_external_shap.csv')
    summary=json.loads((out/'team_original_xgb_shap_derived_summary.json').read_text())
    imp=pd.read_csv(out/'companion_feature_SHAP_importance.csv')
    grp=pd.read_csv(out/'companion_group_SHAP_importance.csv')
    checks=pd.read_csv(out/'companion_model_SHAP_checks.csv')
    baseline=['Property and basic attributes','Coordinates','Other external']
    original_groups=[59.9,summary['coordinate_pct_of_all_features_approx'],summary['other_external_pct_of_all_features_approx']]
    grouped={'Original XGBoost\n(teammate source)':original_groups}
    for model in checks.model:
        dd=grp[grp.model==model].set_index('feature_group')
        grouped[model + ('\n(16-case exploratory)' if model=='RandomForest' else '\n(320-case companion)')]=[float(dd.loc[g,'relative_individual_attribution_pct']) for g in baseline]
    # 1. Team original SHAP individual outside baseline - plot source values in NZD only.
    s=source.sort_values('reported_mean_absolute_SHAP_NZD',ascending=True)
    fig,ax=plt.subplots(figsize=(10,6))
    c=['tab:orange' if c in ('latitude','longitude') else 'tab:blue' for c in s.feature]
    ax.barh(s.feature,s.reported_mean_absolute_SHAP_NZD,color=c)
    ax.set_xlabel('Mean absolute TreeSHAP attribution (NZD)')
    ax.set_title('Original teammate XGBoost: external-feature SHAP (existing notebook output)')
    ax.grid(axis='x',alpha=.2)
    fig.tight_layout();fig.savefig(out/'fig01_team_original_external_SHAP.png',dpi=180);plt.close(fig)
    # 2. Source original XGB group composition and independent models side by side
    fig,ax=plt.subplots(figsize=(10,4.2))
    labels=list(grouped);left=np.zeros(len(labels))
    for gi,gname in enumerate(baseline):
        vals=np.array([grouped[k][gi] for k in labels])
        ax.barh(labels,vals,left=left,label=gname)
        for k,(x,l) in enumerate(zip(vals,left)):
            if x>=8:ax.text(l+x/2,k,f'{x:.1f}%',ha='center',va='center',fontsize=9,color='white')
        left+=vals
    ax.set_xlim(0,100);ax.set_xlabel('Percentage of total mean absolute feature SHAP')
    ax.set_title('Attribution by feature group (different fitted models; not a causal comparison)')
    ax.legend(loc='upper center',bbox_to_anchor=(.5,-.2),ncol=3,frameon=False,fontsize=9)
    fig.tight_layout();fig.savefig(out/'fig02_model_group_SHAP_shares.png',dpi=180,bbox_inches='tight');plt.close(fig)
    # 3. LightGBM most important individual variables (fresh independent model)
    sub=imp[imp.model=='LightGBM'].sort_values('mean_absolute_shap_nzd',ascending=False).head(15).iloc[::-1]
    fig,ax=plt.subplots(figsize=(9.5,6))
    ax.barh(sub.feature,sub.mean_absolute_shap_nzd)
    ax.set_xlabel('Mean absolute TreeSHAP attribution (NZD)')
    ax.set_title('Independent LightGBM companion: top-15 feature SHAP (320 held-out cases)')
    ax.grid(axis='x',alpha=.2)
    fig.tight_layout();fig.savefig(out/'fig03_companion_lightgbm_top_features.png',dpi=180);plt.close(fig)
    # 4. Notebook SHAP vs loss on feature removal, two different measures.
    drop=original_drop_one_readonly(notebook)
    matched=source.merge(drop,on='feature',validate='one_to_one').sort_values('reported_mean_absolute_SHAP_NZD',ascending=True)
    matched.to_csv(out/'team_original_shap_vs_drop_one.csv',index=False)
    fig,axes=plt.subplots(1,2,figsize=(12,6),sharey=True)
    axes[0].barh(matched.feature,matched.reported_mean_absolute_SHAP_NZD)
    axes[0].set_title('Original model SHAP importance')
    axes[0].set_xlabel('Mean |SHAP| (NZD attribution)')
    axes[1].barh(matched.feature,matched.teammate_drop_one_RMSE_delta_NZD)
    axes[1].axvline(0,color='black',lw=.8)
    axes[1].set_title('Original drop-one refit sensitivity')
    axes[1].set_xlabel('Change in held-out RMSE (NZD)')
    fig.suptitle('Existing XGBoost notebook outputs: attribution and refit error are NOT the same thing')
    fig.tight_layout();fig.savefig(out/'fig04_team_original_shap_vs_drop_one.png',dpi=180);plt.close(fig)
    # 5. sampled signed SHAP group-aggregate distribution: only anonymous quantiles exposed
    rows=[]
    for model in checks.model:
        private=out.parent/'PRIVATE'/f'{model}_sample_shap_PRIVATE.csv.gz'
        if not private.exists():continue
        x=pd.read_csv(private)
        for group,features in [('Property and basic attributes',list(x.columns[:22])),
                               ('Coordinates',['latitude','longitude']),
                               ('Other external',[c for c in x if c not in list(x.columns[:22])+['latitude','longitude']])]:
            v=x[features].sum(axis=1)
            rows.append({'model':model,'group':group,'n':len(v),
                        'p10_signed_shap_NZD':float(v.quantile(.1)),
                        'p50_signed_shap_NZD':float(v.median()),
                        'p90_signed_shap_NZD':float(v.quantile(.9))})
    quant=pd.DataFrame(rows);quant.to_csv(out/'companion_group_signed_SHAP_quantiles.csv',index=False)
    sub=quant[quant.model=='LightGBM']
    fig,ax=plt.subplots(figsize=(9,3.5))
    places=np.arange(len(sub))
    ax.hlines(places,sub.p10_signed_shap_NZD,sub.p90_signed_shap_NZD,lw=6,alpha=.5)
    ax.scatter(sub.p50_signed_shap_NZD,places,s=65,zorder=2)
    ax.axvline(0,ls='--',color='black',lw=.8)
    ax.set_yticks(places,sub.group)
    ax.set_xlabel('Signed contribution to prediction (NZD); 10th–90th percentile and median')
    ax.set_title('Independent LightGBM: distribution of signed grouped TreeSHAP (320 samples)')
    ax.grid(axis='x',alpha=.2)
    fig.tight_layout();fig.savefig(out/'fig05_lightgbm_group_signed_SHAP.png',dpi=180);plt.close(fig)
    # 6. empirical sampling variation on 320 held-out LightGBM explanations; not model uncertainty
    sample=pd.read_csv(out.parent/'PRIVATE'/'LightGBM_sample_shap_PRIVATE.csv.gz')
    numeric=np.abs(sample.to_numpy(dtype=float));rng=np.random.default_rng(760)
    group_indices={"Property and basic attributes":[sample.columns.get_loc(c) for c in sample.columns[:22]],
                   "Coordinates":[sample.columns.get_loc(c) for c in ['latitude','longitude']],
                   "Other external":[sample.columns.get_loc(c) for c in sample.columns if c not in list(sample.columns[:22])+['latitude','longitude']]}
    arr=np.column_stack([numeric[:,inds].sum(axis=1) for inds in group_indices.values()])
    parts=[]
    for rep in range(500):
        take=rng.choice(len(arr),len(arr),replace=True)
        v=arr[take].sum(axis=0); parts.append(v/v.sum()*100)
    parts=np.asarray(parts)
    ci=pd.DataFrame({'model':'LightGBM', 'feature_group':list(group_indices),
                     'point_pct':100*arr.sum(axis=0)/arr.sum(),
                     'boot_p025_pct':np.quantile(parts,.025,axis=0),
                     'boot_p975_pct':np.quantile(parts,.975,axis=0),
                     'scope':'bootstrap of 320 sampled explanations only; does not quantify underlying model selection uncertainty'})
    ci.to_csv(out/'lightgbm_sample_group_share_bootstrap.csv',index=False)
    return source,summary,imp,grp,checks,ci


def report(out,notebook):
    original,team,imp,grp,checks,ci=make(out,notebook)
    out=Path(out)
    lgb=grp[grp.model=='LightGBM'].set_index('feature_group')
    rf=grp[grp.model=='RandomForest'].set_index('feature_group')
    lcheck=checks.set_index('model').loc['LightGBM'];rcheck=checks.set_index('model').loc['RandomForest']
    formatted=lambda k: f"{float(lgb.loc[k,'relative_individual_attribution_pct']):.1f}%"
    source_rank=original.head(7)
    source_lines='\n'.join(f"| `{row.feature}` | {row.reported_mean_absolute_SHAP_NZD:,.0f} |" for row in source_rank.itertuples())
    content=f'''# Stage 5 — Explainable AI (SHAP): Source-Backed XGBoost and Independent Companion Analyses

## Executive summary

The group's original XGBoost notebook is **unchanged**. We reused only its **already saved SHAP and drop-one outputs** from cells 75 and 78, then added independently trained LightGBM and Random Forest SHAP as complementary evidence. We did **not** retrain, alter, export, or substitute a different XGBoost model. No original-XGBoost OOF export or fuller subgroup audit is required for this stage.

**Principal finding:** The original XGBoost notebook reports that **40.1%** of the full model's sum of individual mean-absolute-SHAP contributions belongs to its 13 'external' features. Among those 13, latitude and longitude alone account for **{team['coordinates_within_external_pct']:.1f}% of external-feature attribution**, based on the feature values printed in the notebook. The other 11 external variables collectively account for **{team['other_external_within_external_pct']:.1f}%** of external-feature attribution. Their approximate shares of *total* attribution are **{team['coordinate_pct_of_all_features_approx']:.1f}%** and **{team['other_external_pct_of_all_features_approx']:.1f}%**, respectively; the baseline 22 'property' columns account for the remaining reported **59.9%**. These percentages reflect SHAP model attribution—not price effects or improvements in forecasting accuracy.

## Research focus and integration

The Stage 5 investigation supplements **RQ1** and **RQ2** by asking: which features does the fitted model rely upon, how can contributions be decomposed between structural/property, coordinates, and non-coordinate contextual features, and do independent model families show a similar pattern? The team XGBoost remains the project's primary model. The additional companion models here are neither new team XGBoost candidates nor substitutes for the original SHAP implementation.

## 1. Existing ORIGINAL XGBoost results — teammate notebook, cell 75

| Reported external feature | Original mean |SHAP| (NZD) |
|---|---:|
{source_lines}

Of all 13 external features, the coordinate sum is **NZ${team['coordinate_feature_mean_abs_SHAP_sum_NZD']:,.0f}**, whereas the other 11 sum to **NZ${team['other_external_feature_mean_abs_SHAP_sum_NZD']:,.0f}**. These are sums of feature-level mean absolute SHAP magnitudes, **not** predictions or measured reductions in RMSE. These values and the 40.1% share come from notebook saved outputs; the 82.4/17.6 split is **our arithmetic decomposition** of those unchanged outputs.

**Clarification:** the teammate's `zoning` feature belongs to their 22-column baseline. Our chart labels that baseline 'property and basic attributes' to avoid claiming that it contains no geographic information.

Figure 1 shows the notebook's original external-feature SHAP magnitudes. Figure 2 compares the original source-derived attribution shares with independent companion-model results.

## 2. Independent companion SHAP — same shared dataset, separate model fits

The companion experiment applies the teammate's six data-selection rules (59,798 transactions), follows the original notebook's chronological 80/20 split and training-quantile price trimming, and uses its same 35 augmented predictors and train-fitted categorical encoding / missing-value handling. It fits **LightGBM** and **Random Forest**, not XGBoost. These are **separate new 80/20 fits** for explaining those two models. The reported evaluation errors here are **not** interchangeable with Stage 2's pooled 5-fold leaderboard metrics.

| Independent companion model | Train after trimming | Test after trimming | Explained test cases | Test MAE (NZD) | TreeSHAP reconstruction max discrepancy |
|---|---:|---:|---:|---:|---:|
| LightGBM | {int(lcheck.n_train_after_price_trim):,} | {int(lcheck.n_test_after_price_trim):,} | {int(lcheck.n_explained)} | {lcheck.MAE:,.0f} | ${lcheck.additivity_max_absolute_error_nzd:.3g} |
| Random Forest | {int(rcheck.n_train_after_price_trim):,} | {int(rcheck.n_test_after_price_trim):,} | {int(rcheck.n_explained)} | {rcheck.MAE:,.0f} | ${rcheck.additivity_max_absolute_error_nzd:.3g} |

| Feature group | Original XGBoost* | LightGBM companion | Random Forest companion† |
|---|---:|---:|---:|
| Property + baseline location | 59.9% | {formatted('Property and basic attributes')} | {float(rf.loc['Property and basic attributes','relative_individual_attribution_pct']):.1f}% |
| Latitude + longitude | {team['coordinate_pct_of_all_features_approx']:.1f}% | {formatted('Coordinates')} | {float(rf.loc['Coordinates','relative_individual_attribution_pct']):.1f}% |
| Other 11 external attributes | {team['other_external_pct_of_all_features_approx']:.1f}% | {formatted('Other external')} | {float(rf.loc['Other external','relative_individual_attribution_pct']):.1f}% |

*Original XGBoost figures come from its notebook, including a rounded 40.1% group share; comparison percentages are approximate. †Random Forest uses **only 16 explained properties** because exact TreeSHAP calculation is expensive; consider its proportions exploratory and unstable.*

The independent LightGBM companion gives a broadly similar picture: baseline attributes **{formatted('Property and basic attributes')}**, geographic coordinates **{formatted('Coordinates')}**, and other external factors **{formatted('Other external')}** of individual mean-absolute-SHAP attribution. For LightGBM, bootstrapping its 320 sampled SHAP rows gives the intervals in `lightgbm_sample_group_share_bootstrap.csv`. Those intervals describe **sampling variation in the explanation sample**, not uncertainty about causal effects or whether XGBoost is superior.

## 3. Local explanations and additive consistency

For a fixed tree-model prediction of sale price, TreeSHAP expresses the output as an expected prediction plus the contributions of each of the 35 input features:

\\[\\widehat{{P}}(x)=\\phi_0+\\sum_{{j=1}}^{{35}}\\phi_j(x).\\]

A positive \\(\\phi_j(x)\\) pushes the predicted price **above the model's reference prediction**, and a negative term pushes it below. Features such as floor area and latitude cannot be interpreted as causal price changes from these values. The independent LightGBM and RF SHAP values each pass the numerical additivity test, with the maximum discrepancy reported in the table above. Anonymized *summary* distributions of signed group contributions are shown in Figure 5. Exact individual explanations are kept in a local `PRIVATE/` folder and **not packaged**, given property-level Council data restrictions.

## 4. SHAP does not measure predictive added value

The original teammate XGBoost notebook additionally runs an external-feature **drop-one-refit** study (cell 78). These are different quantities:

- **SHAP:** how much the current *fitted* model's predictions are attributed to a feature over the explanation sample (NZD).
- **Drop-one refit:** the change in held-out RMSE after retraining **a different model without that feature** (NZD).

The original notebook's saved values provide an illustrative contrast. `latitude` has mean |SHAP| **NZ$157,993** and its drop-one removal raises RMSE **NZ$36,700**. `dist_to_flood_sensitive_area_m` has mean |SHAP| **NZ$16,927**, while removing it and refitting **reduces** RMSE by **NZ$98** in that experiment. These are both valid *model-specific* results, not evidence that flood exposure causally increases sale prices. Figure 4 reports the comparison without altering the original notebook.

## 5. Limitations and defensible conclusion

The original XGBoost notebook is an observational SHAP attribution study of **one fitted model on a sampled held-out set**; no causal claim follows. Latitude and longitude proxy many unobserved neighbourhood characteristics. Correlated property size measures may split attribution. Its original baseline includes zoning. The companion SHAP studies use independently trained estimators and different test-sample counts, so the close percentages are a qualitative consistency check, not a formal statistically matched cross-model comparison. The 80/20 split can share a calendar date at its boundary, test sales were price-screened using true sale prices, and historical GIS vintages remain unconfirmed. Random Forest's 16 explanation cases are insufficient for strong population-level generalisation.

**Conclusion for the group report:** The team's existing XGBoost explanations show that geography, especially exact location coordinates, dominates the attribution assigned to its contextual feature group. This is consistent with its own feature-removal accuracy experiments and reinforced descriptively by our independent LightGBM SHAP results. The remaining external variables have smaller aggregate SHAP attribution and do not by themselves establish additional predictive gains. Our Stage 5 work contributes a clearer breakdown, numerical audit, and independent cross-model explanation **without changing your teammate's XGBoost implementation or reported results**.

## Figures and reproducibility

- `fig01_team_original_external_SHAP.png` — the 13 originally reported XGBoost external SHAP feature magnitudes.
- `fig02_model_group_SHAP_shares.png` — approximate SHAP attribution percentages by feature grouping (original vs companion).
- `fig03_companion_lightgbm_top_features.png` — top 15 independent LightGBM SHAP features.
- `fig04_team_original_shap_vs_drop_one.png` — original XGBoost notebook SHAP and drop-one sensitivities, kept conceptually separate.
- `fig05_lightgbm_group_signed_SHAP.png` — independently modelled LightGBM group SHAP quantiles, anonymized.

The scripts use immutable source SHA-256 checks and save only group-aggregated outputs in the shareable folder. We do not copy the XGBoost notebook into our ZIP because it contains teammate work and may include private property records.
'''
    (out/'STAGE05_RESEARCH_REPORT.md').write_text(content)
    print('Report created',out/'STAGE05_RESEARCH_REPORT.md')
    return content

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--out',default='results');p.add_argument('--notebook',default='/mnt/data/XGBoost.ipynb');args=p.parse_args()
    report(args.out,args.notebook)
