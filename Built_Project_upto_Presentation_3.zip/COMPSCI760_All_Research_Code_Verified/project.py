"""One consistent command interface for the six-stage COMPSCI 760 project."""
from __future__ import annotations
import argparse
import hashlib
import json
import subprocess
import sys
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent
STAGES = {
    1: '01_data_audit', 2: '02_property_prediction',
    3: '03_time_series', 4: '04_fairness',
    5: '05_shap', 6: '06_hedonic_robustness'
}

def digest(path):
    h = hashlib.sha256()
    with open(path, 'rb') as file:
        for buf in iter(lambda: file.read(2**20), b''):
            h.update(buf)
    return h.hexdigest()

def verify_sources(dataset, notebook):
    source = json.loads((ROOT / 'source_manifest.json').read_text())
    for label, path, meta in (
        ('dataset', dataset, source['dataset']),
        ('notebook', notebook, source['original_xgboost_notebook'])
    ):
        if path is None:
            raise ValueError(f'{label} path required for this command')
        path = Path(path)
        if not path.is_file():
            raise FileNotFoundError(path)
        if digest(path) != meta['sha256']:
            raise ValueError(f'{label} differs from the verified shared input: {path}')
    print('Verified source dataset and notebook SHA-256 fingerprints.')

def stage_path(number):
    return ROOT / 'stages' / STAGES[number]

def invoke(command, cwd, env=None):
    print('Running:', ' '.join(map(str,command)), flush=True)
    subprocess.run(command, cwd=cwd, env=env, check=True)

def check(dataset=None, notebook=None):
    if dataset is not None or notebook is not None:
        verify_sources(dataset, notebook)
    results = []
    for number in STAGES:
        directory = stage_path(number)
        tests = 'tests' if (directory/'tests').is_dir() else 'test_audit.py'
        cmd = [sys.executable, '-m', 'pytest', '-q', tests]
        env = os.environ.copy()
        env['PYTHONDONTWRITEBYTECODE'] = '1'
        # Current package paths are added so shared imports resolve from any cwd.
        env['PYTHONPATH'] = str(ROOT) + os.pathsep + env.get('PYTHONPATH','')
        print(f'\nStage {number}:', flush=True)
        invoke(cmd, directory, env=env)
        results.append(number)
    print(f'\nAll {len(results)} stages passed their automated checks.')

def run_stage(args):
    verify_sources(args.dataset, args.notebook)
    stage = stage_path(args.stage)
    dest = ROOT / 'local_runs' / f'stage{args.stage:02d}'
    dest.mkdir(parents=True, exist_ok=True)
    common = ["--dataset", str(Path(args.dataset).resolve()),
              "--notebook", str(Path(args.notebook).resolve())]
    py = sys.executable
    if args.stage == 1:
        command = [py, 'audit.py', *common, '--out', str(dest)]
    elif args.stage == 2:
        command = [py, 'scripts/run_rf_and_baselines.py', *common, '--out', str(dest)]
        if args.extended:
            env = os.environ.copy()
            env['COMPSCI760_DATASET'] = str(Path(args.dataset).resolve())
            env['COMPSCI760_NOTEBOOK'] = str(Path(args.notebook).resolve())
            # Rerun two distinct experiments. Predictions stay private.
            invoke(command, stage)
            invoke([py, 'run_additional_benchmarks.py', '--out', str(dest / 'extended')], stage, env=env)
            print(f'Outputs saved under {dest.relative_to(ROOT)}; published results remain intact.')
            return
    elif args.stage == 3:
        command = [py, 'run_stage03.py', *common, '--out', str(dest)]
    elif args.stage == 4:
        rf = args.rf_oof or ROOT / 'local_runs' / 'stage02' / 'PRIVATE' / 'companion_oof_predictions.csv.gz'
        lgbm = args.lgbm_oof or ROOT / 'local_runs' / 'stage02' / 'extended' / 'PRIVATE' / 'extended_predictions.csv.gz'
        if not Path(rf).is_file() or not Path(lgbm).is_file():
            raise ValueError('Stage 4 needs private RF and LightGBM predictions; run Stage 2 --extended first, or pass --rf-oof and --lgbm-oof')
        command = [py, 'run_stage04.py', *common, '--source', 'companion',
                   '--rf-oof', str(Path(rf).resolve()),
                   '--lgbm-oof', str(Path(lgbm).resolve()),
                   '--out', str(dest)]
    elif args.stage == 5:
        command = [py, 'run_stage05.py', *common, '--out', str(dest), '--sample-size', '320']
    elif args.stage == 6:
        lgbm = args.lgbm_oof or ROOT / 'local_runs' / 'stage02' / 'extended' / 'PRIVATE' / 'extended_predictions.csv.gz'
        if not Path(lgbm).is_file():
            raise ValueError('Stage 6 needs private LightGBM predictions; run Stage 2 --extended first, or pass --lgbm-oof')
        command = [py, 'run_stage06.py', *common,
                   '--companion-predictions', str(Path(lgbm).resolve()),
                   '--out', str(dest)]
    invoke(command, stage)
    print(f'Outputs saved under {dest.relative_to(ROOT)}; published results remain intact.')

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    sub=parser.add_subparsers(dest='action',required=True)
    check_parser=sub.add_parser('check',help='Run unit and aggregate consistency tests')
    check_parser.add_argument('--dataset',type=Path)
    check_parser.add_argument('--notebook',type=Path)
    run_parser=sub.add_parser('run',help='Rerun an experiment with original inputs')
    run_parser.add_argument('stage',type=int,choices=range(1,7),metavar='STAGE')
    run_parser.add_argument('--dataset',required=True,type=Path)
    run_parser.add_argument('--notebook',required=True,type=Path)
    run_parser.add_argument('--extended',action='store_true',help='For Stage 2, also fit the five additional benchmark configurations')
    run_parser.add_argument('--rf-oof',type=Path)
    run_parser.add_argument('--lgbm-oof',type=Path)
    args=parser.parse_args()
    try:
        if args.action=='check':check(args.dataset,args.notebook)
        else:run_stage(args)
    except (ValueError,FileNotFoundError,subprocess.CalledProcessError) as error:
        parser.exit(1, f'Error: {error}\n')

if __name__=='__main__':
    main()
